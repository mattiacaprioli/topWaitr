// Aura — Screen: Turno in corso (live shift mode)
// Phases: checkin → active → checkout → done

const ScreenTurno = ({ shift, onClose, onOpenQR }) => {
  const s = shift || { venue: "Trattoria da Gino", role: "Chef de Rang", time: "19:00–00:00", est: "€ 150", day: "GIO 13" };
  const compenso = s.est || "€ 150";

  const [phase, setPhase] = React.useState("checkin"); // checkin | active | checkout | done
  const [geo, setGeo] = React.useState("locating");    // locating | ready
  const [elapsed, setElapsed] = React.useState(0);      // seconds since check-in
  const [tables, setTables] = React.useState([
    { n: "T1", seats: 4, status: "served" },
    { n: "T2", seats: 2, status: "active" },
    { n: "T3", seats: 6, status: "active" },
    { n: "T4", seats: 2, status: "free" },
    { n: "T5", seats: 4, status: "free" },
    { n: "T8", seats: 8, status: "active" },
  ]);
  const [paused, setPaused] = React.useState(false);

  // Geolocation simulation on checkin
  React.useEffect(() => {
    if (phase === "checkin" && geo === "locating") {
      const t = setTimeout(() => setGeo("ready"), 1800);
      return () => clearTimeout(t);
    }
  }, [phase, geo]);

  // Live timer while active
  React.useEffect(() => {
    if (phase === "active" && !paused) {
      const t = setInterval(() => setElapsed(e => e + 1), 1000);
      return () => clearInterval(t);
    }
  }, [phase, paused]);

  const fmt = (sec) => {
    const h = String(Math.floor(sec / 3600)).padStart(2, "0");
    const m = String(Math.floor((sec % 3600) / 60)).padStart(2, "0");
    const ss = String(sec % 60).padStart(2, "0");
    return `${h}:${m}:${ss}`;
  };

  const cycleTable = (i) => {
    setTables(ts => ts.map((t, j) => {
      if (j !== i) return t;
      const next = t.status === "free" ? "active" : t.status === "active" ? "served" : "free";
      return { ...t, status: next };
    }));
  };

  const served = tables.filter(t => t.status === "served").length;
  const activeT = tables.filter(t => t.status === "active").length;

  // ── CHECK-IN ──────────────────────────────────────────────
  if (phase === "checkin") {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)", display: "flex", flexDirection: "column", minHeight: "100%" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 22px" }}>
          <button onClick={onClose} style={iconBtn}><Icon name="close" size={18} color="var(--t-2)" /></button>
          <div>
            <div className="mono" style={{ color: "var(--gold)" }}>CHECK-IN TURNO</div>
            <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>{s.venue}</div>
          </div>
        </div>

        {/* Shift detail card */}
        <div className="card" style={{ padding: 18, marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ fontSize: 15.5, fontWeight: 600 }}>{s.role}</div>
              <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 3 }}>Oggi · {s.time}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 20, color: "var(--gold)" }}>{compenso}</div>
              <div className="mono" style={{ marginTop: 2 }}>compenso garantito</div>
            </div>
          </div>
        </div>

        {/* Geo status */}
        <div className="card" style={{
          padding: 18, marginBottom: 16, position: "relative", overflow: "hidden",
          borderColor: geo === "ready" ? "oklch(0.80 0.140 150 / 0.4)" : "var(--hair)",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{
              width: 48, height: 48, borderRadius: 14, flexShrink: 0,
              background: geo === "ready" ? "oklch(0.80 0.140 150 / 0.10)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${geo === "ready" ? "oklch(0.80 0.140 150 / 0.4)" : "var(--hair-2)"}`,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              {geo === "locating"
                ? <div className="spin" style={{ width: 20, height: 20, borderRadius: 99, border: "2px solid rgba(255,200,90,0.2)", borderTopColor: "var(--gold)" }}/>
                : <Icon name="pin" size={22} color="var(--pos)"/>}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14.5, fontWeight: 600 }}>
                {geo === "locating" ? "Localizzazione in corso…" : "Sei al locale"}
              </div>
              <div style={{ fontSize: 12, color: geo === "ready" ? "var(--pos)" : "var(--t-3)", marginTop: 3 }}>
                {geo === "locating" ? "Verifica della posizione GPS" : "A 12 m da Trattoria da Gino · confermato"}
              </div>
            </div>
            {geo === "ready" && <Icon name="check" size={20} color="var(--pos)" strokeWidth={2.2}/>}
          </div>
        </div>

        <div className="card" style={{ padding: 14, marginBottom: 16, display: "flex", gap: 12, alignItems: "flex-start" }}>
          <Icon name="shield2" size={18} color="var(--gold)" style={{ marginTop: 2 }}/>
          <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.5 }}>
            Il check-in geolocalizzato certifica la tua presenza. Risolve ogni dubbio su <strong style={{ color: "var(--t-1)" }}>presenza e orari</strong> e sblocca il pagamento a fine turno.
          </div>
        </div>

        <div style={{ flex: 1 }} />

        <button onClick={() => setPhase("active")} disabled={geo !== "ready"}
          className={geo === "ready" ? "btn-gold" : "btn-ghost"}
          style={{ width: "100%", padding: 16, fontSize: 15.5, opacity: geo === "ready" ? 1 : 0.5 }}>
          {geo === "ready" ? "Inizia il turno" : "In attesa della posizione…"}
        </button>
      </div>
    );
  }

  // ── ACTIVE ────────────────────────────────────────────────
  if (phase === "active") {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)", display: "flex", flexDirection: "column", minHeight: "100%" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 0 18px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span className="warn-pulse" style={{ width: 9, height: 9, borderRadius: 99, background: "var(--pos)" }}/>
            <span className="mono" style={{ color: "var(--pos)" }}>IN SERVIZIO</span>
          </div>
          <div className="mono">{s.venue}</div>
        </div>

        {/* Timer hero */}
        <div className="card" style={{ padding: "24px 22px 20px", marginBottom: 14, position: "relative", overflow: "hidden", textAlign: "center" }}>
          <div style={{
            position: "absolute", inset: 0, pointerEvents: "none",
            background: "radial-gradient(ellipse at 50% 0%, var(--gold-glow), transparent 60%)",
          }}/>
          <div style={{ position: "relative" }}>
            <div className="mono" style={{ marginBottom: 12 }}>Tempo di servizio</div>
            <div className="gold-shimmer numeric" style={{
              fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 52, lineHeight: 1, letterSpacing: "-0.02em",
            }}>{fmt(elapsed)}</div>
            <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 12 }}>
              {paused ? "In pausa" : "Check-in alle 19:02"} · {s.role}
            </div>
          </div>
        </div>

        {/* Live stats */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 18 }}>
          <StatCell value={String(served)} sub="serviti"/>
          <StatCell value={String(activeT)} sub="attivi"/>
          <StatCell value={compenso} sub="compenso"/>
        </div>

        {/* Tables */}
        <div className="mono" style={{ marginBottom: 10 }}>I tuoi tavoli · tocca per aggiornare</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 18 }}>
          {tables.map((t, i) => {
            const map = {
              free: { bd: "var(--hair-2)", bg: "transparent", tx: "var(--t-3)", lbl: "Libero" },
              active: { bd: "var(--gold)", bg: "rgba(255,200,90,0.07)", tx: "var(--gold)", lbl: "In corso" },
              served: { bd: "oklch(0.80 0.140 150 / 0.4)", bg: "oklch(0.80 0.140 150 / 0.06)", tx: "var(--pos)", lbl: "Servito" },
            }[t.status];
            return (
              <button key={i} onClick={() => cycleTable(i)} style={{
                padding: "12px 8px", borderRadius: 14, cursor: "pointer",
                border: `1px solid ${map.bd}`, background: map.bg,
                display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
                fontFamily: "var(--f-ui)", transition: "all .15s ease",
              }}>
                <span className="numeric" style={{ fontWeight: 700, fontSize: 16, color: "var(--t-1)" }}>{t.n}</span>
                <span style={{ fontSize: 10, color: "var(--t-4)" }}>{t.seats} cop.</span>
                <span className="mono" style={{ color: map.tx, fontSize: 8 }}>{map.lbl}</span>
              </button>
            );
          })}
        </div>

        {/* Quick actions */}
        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          <button onClick={() => { setPaused(p => !p); showToast(paused ? "Servizio ripreso" : "Servizio in pausa", paused ? "check" : "clock"); }}
            className="btn-ghost" style={{ flex: 1, padding: 13, fontSize: 13 }}>
            {paused ? "Riprendi" : "Pausa"}
          </button>
          <button onClick={() => showToast("Sala avvisata", "chat")} className="btn-ghost" style={{ flex: 1, padding: 13, fontSize: 13 }}>
            Avvisa sala
          </button>
          <button onClick={() => showToast("SOS inviato al manager", "alert")} style={{
            flex: 1, padding: 13, fontSize: 13, borderRadius: 999, cursor: "pointer",
            background: "oklch(0.78 0.140 50 / 0.10)", border: "1px solid oklch(0.78 0.140 50 / 0.4)",
            color: "var(--warn)", fontFamily: "var(--f-ui)", fontWeight: 600,
          }}>SOS</button>
        </div>

        <div style={{ flex: 1 }} />

        <button onClick={() => setPhase("checkout")} className="btn-gold" style={{ width: "100%", padding: 16, fontSize: 15.5 }}>
          Termina turno
        </button>
      </div>
    );
  }

  // ── CHECKOUT ──────────────────────────────────────────────
  if (phase === "checkout") {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)", display: "flex", flexDirection: "column", minHeight: "100%" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 22px" }}>
          <button onClick={() => setPhase("active")} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
          <div>
            <div className="mono" style={{ color: "var(--gold)" }}>CHECK-OUT</div>
            <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Riepilogo turno</div>
          </div>
        </div>

        <div className="card" style={{ padding: 18, marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 16, paddingBottom: 16, borderBottom: "1px solid var(--hair)" }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(135deg, oklch(0.30 0.04 60), oklch(0.20 0.03 50))", border: "1px solid var(--hair-2)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon name="clock" size={22} color="var(--gold)"/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 600 }}>{s.venue}</div>
              <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{s.role} · oggi</div>
            </div>
          </div>
          <Row label="Durata servizio" value={fmt(elapsed)} />
          <Row label="Tavoli serviti" value={`${served} · ${activeT} ancora attivi`} />
          <Row label="Check-in" value="19:02 · geolocalizzato" />
          <Row label="Compenso" value={compenso} gold last />
        </div>

        <div className="card" style={{ padding: 14, marginBottom: 16, display: "flex", gap: 12, alignItems: "flex-start" }}>
          <Icon name="euro" size={18} color="var(--gold)" style={{ marginTop: 2 }}/>
          <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.5 }}>
            Confermando il check-out, il compenso viene <strong style={{ color: "var(--t-1)" }}>bloccato e garantito</strong> sul tuo wallet. Accredito entro 48h.
          </div>
        </div>

        <div style={{ flex: 1 }} />

        <button onClick={() => setPhase("done")} className="btn-gold" style={{ width: "100%", padding: 16, fontSize: 15.5 }}>
          Conferma e termina turno
        </button>
      </div>
    );
  }

  // ── DONE ──────────────────────────────────────────────────
  return (
    <div className="screen-enter" style={{
      padding: "8px 24px 40px", color: "var(--t-1)", height: "100%",
      display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center",
    }}>
      <div style={{
        width: 110, height: 110, borderRadius: 999, marginBottom: 24,
        background: "radial-gradient(circle, oklch(0.80 0.140 150 / 0.25), transparent 70%)",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <div style={{
          width: 80, height: 80, borderRadius: 999,
          background: "linear-gradient(180deg, oklch(0.82 0.150 150), oklch(0.62 0.150 150))",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 0 0 8px oklch(0.80 0.140 150 / 0.15)",
        }}>
          <Icon name="check" size={42} color="#06210e" strokeWidth={2.5}/>
        </div>
      </div>
      <div className="mono text-pos" style={{ marginBottom: 10 }}>TURNO COMPLETATO</div>
      <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.02em", marginBottom: 8 }}>
        {compenso} sbloccati
      </div>
      <div style={{ fontSize: 13.5, color: "var(--t-3)", lineHeight: 1.55, maxWidth: 290, marginBottom: 24 }}>
        Compenso aggiunto al wallet · disponibile entro 48h. Hai lavorato {fmt(elapsed)}.
      </div>

      {/* Review prompt */}
      <div className="card" style={{ width: "100%", maxWidth: 330, padding: 16, marginBottom: 16, textAlign: "left" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: "rgba(255,200,90,0.10)", border: "1px solid var(--gold)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="qr" size={18} color="var(--gold)"/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 600 }}>Fatti recensire</div>
            <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>Mostra il QR ai clienti prima che vadano via</div>
          </div>
        </div>
        <button onClick={() => { onClose(); onOpenQR && onOpenQR(); }} className="btn-ghost" style={{ width: "100%", padding: 12, fontSize: 13 }}>
          Apri il mio QR
        </button>
      </div>

      <button onClick={onClose} className="btn-gold" style={{ width: "100%", maxWidth: 330, padding: 16, fontSize: 15.5 }}>
        Torna alla home
      </button>
    </div>
  );
};

Object.assign(window, { ScreenTurno });
