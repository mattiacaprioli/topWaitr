// Aura — Onboarding flow (dual: Cameriere / Ristoratore)
// Self-contained. Exports OnboardingFlow({ onComplete }).

const OnboardingFlow = ({ onComplete }) => {
  const [role, setRole] = React.useState(null); // 'waiter' | 'manager'
  const [page, setPage] = React.useState(0);
  const [showLogin, setShowLogin] = React.useState(false);
  const [data, setData] = React.useState({
    name: "", city: "Milano", mainRole: "Chef de Rang",
    venue: "", venueType: "Trattoria", covers: 40,
    idStatus: "empty", selfieStatus: "empty", pivaStatus: "empty",
    iban: "", ibanLinked: false,
    skills: new Set(["VELOCE", "CORTESE"]),
    certs: { ais: "empty", haccp: "empty" },
  });

  const upd = (patch) => setData(d => ({ ...d, ...patch }));

  const waiterPages = ["welcome", "role", "dati", "identita", "wallet", "competenze", "done"];
  const managerPages = ["welcome", "role", "locale", "piva", "team", "done"];
  const pages = role === "manager" ? managerPages : waiterPages;
  const current = pages[page];

  // Form pages (exclude welcome/role/done) drive the progress bar
  const formStart = 2;
  const formPages = pages.slice(formStart, pages.length - 1);
  const formIdx = page - formStart;
  const progress = current === "welcome" || current === "role"
    ? 0
    : current === "done" ? 100 : ((formIdx + 1) / (formPages.length + 1)) * 100;

  const next = () => setPage(p => Math.min(pages.length - 1, p + 1));
  const back = () => setPage(p => Math.max(0, p - 1));

  const pickRole = (r) => { setRole(r); setPage(2); };

  const mockUpload = (key, store = "data") => {
    if (store === "certs") {
      setData(d => ({ ...d, certs: { ...d.certs, [key]: "uploading" } }));
      setTimeout(() => setData(d => ({ ...d, certs: { ...d.certs, [key]: "verified" } })), 1100);
    } else {
      upd({ [key]: "uploading" });
      setTimeout(() => upd({ [key]: "uploaded" }), 1100);
    }
  };

  const finish = () => onComplete && onComplete(role || "waiter", true);
  const doLogin = (loginRole) => onComplete && onComplete(loginRole, false);

  if (showLogin) {
    return <OB_Login onBack={() => setShowLogin(false)} onLogin={doLogin} />;
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", color: "var(--t-1)", position: "relative" }}>
      {/* Top bar: back + progress + skip */}
      {current !== "welcome" && current !== "done" && (
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 20px 14px" }}>
          <button onClick={current === "role" ? () => setPage(0) : back} style={iconBtn}>
            <Icon name="chevL" size={20} color="var(--t-2)"/>
          </button>
          <div style={{ flex: 1, height: 4, borderRadius: 99, background: "rgba(255,255,255,0.07)", overflow: "hidden" }}>
            <div style={{
              height: "100%", width: `${progress}%`, borderRadius: 99,
              background: "linear-gradient(90deg, var(--gold-2), var(--gold))",
              boxShadow: "0 0 10px var(--gold-glow)", transition: "width .35s cubic-bezier(0.2,0.8,0.2,1)",
            }}/>
          </div>
          <button onClick={finish} className="mono" style={{
            background: "transparent", border: 0, cursor: "pointer",
            color: "var(--t-3)", fontSize: 9.5, letterSpacing: "0.14em", textTransform: "uppercase",
          }}>Salta</button>
        </div>
      )}

      <div className="scroll" style={{ flex: 1, overflowY: "auto" }} key={current}>
        {current === "welcome" && <OB_Welcome onStart={() => setPage(1)} onSkip={finish} onLogin={() => setShowLogin(true)}/>}
        {current === "role" && <OB_Role onPick={pickRole}/>}

        {/* WAITER PATH */}
        {current === "dati" && <OB_Dati data={data} upd={upd} onNext={next}/>}
        {current === "identita" && <OB_Identita data={data} mockUpload={mockUpload} onNext={next}/>}
        {current === "wallet" && <OB_Wallet data={data} upd={upd} onNext={next}/>}
        {current === "competenze" && <OB_Competenze data={data} upd={upd} mockUpload={mockUpload} onNext={next}/>}

        {/* MANAGER PATH */}
        {current === "locale" && <OB_Locale data={data} upd={upd} onNext={next}/>}
        {current === "piva" && <OB_Piva data={data} mockUpload={mockUpload} onNext={next}/>}
        {current === "team" && <OB_Team onNext={next}/>}

        {current === "done" && <OB_Done role={role} data={data} onFinish={finish}/>}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// WELCOME
// ─────────────────────────────────────────────────────────────
const OB_Welcome = ({ onStart, onSkip, onLogin }) => (
  <div className="screen-enter" style={{
    height: "100%", display: "flex", flexDirection: "column",
    justifyContent: "center", alignItems: "center", textAlign: "center",
    padding: "0 32px",
  }}>
    <div style={{
      width: 92, height: 92, borderRadius: 26, marginBottom: 30,
      background: "linear-gradient(160deg, oklch(0.30 0.04 70), oklch(0.18 0.02 60))",
      border: "1px solid var(--hair-2)",
      display: "flex", alignItems: "center", justifyContent: "center",
      boxShadow: "0 20px 50px rgba(0,0,0,0.5), 0 0 40px var(--gold-glow)",
    }}>
      <Icon name="logo" size={52} color="var(--gold)"/>
    </div>
    <div className="mono" style={{ marginBottom: 14, color: "var(--gold)" }}>BENVENUTO IN AURA</div>
    <div className="serif" style={{ fontSize: 34, lineHeight: 1.08, letterSpacing: "-0.025em", marginBottom: 16 }}>
      La reputazione<br/>diventa il tuo<br/><em style={{ fontStyle: "italic", color: "var(--gold)" }}>capitale.</em>
    </div>
    <div style={{ fontSize: 14, color: "var(--t-2)", lineHeight: 1.55, maxWidth: 300, marginBottom: 40 }}>
      Recensioni verificate via scontrino, badge di eccellenza e pagamenti sicuri per chi vive di sala e cucina.
    </div>
    <button onClick={onStart} className="btn-gold" style={{ width: "100%", maxWidth: 320, padding: 16, fontSize: 15.5 }}>
      Inizia
    </button>
    <button onClick={onLogin} style={{
      background: "transparent", border: 0, cursor: "pointer", marginTop: 16,
      color: "var(--t-3)", fontSize: 13, fontFamily: "var(--f-ui)",
    }}>Ho già un account · <span style={{ color: "var(--gold)" }}>Accedi</span></button>
  </div>
);

// ─────────────────────────────────────────────
// LOGIN (existing account)
// ─────────────────────────────────────────────
const OB_Login = ({ onBack, onLogin }) => {
  const [email, setEmail] = React.useState("marco.rossi@aura.app");
  const [pw, setPw] = React.useState("");
  const [loginRole, setLoginRole] = React.useState("waiter");
  const valid = email.includes("@") && pw.length >= 4;
  return (
    <div className="screen-enter" style={{ height: "100%", display: "flex", flexDirection: "column", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 20px 14px" }}>
        <button onClick={onBack} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)"/></button>
        <div className="mono">Accedi</div>
      </div>
      <div className="scroll" style={{ flex: 1, overflowY: "auto", padding: "12px 24px 40px", display: "flex", flexDirection: "column" }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{
            width: 72, height: 72, borderRadius: 20, margin: "0 auto 18px",
            background: "linear-gradient(160deg, oklch(0.30 0.04 70), oklch(0.18 0.02 60))",
            border: "1px solid var(--hair-2)", display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 16px 40px rgba(0,0,0,0.5), 0 0 30px var(--gold-glow)",
          }}>
            <Icon name="logo" size={40} color="var(--gold)"/>
          </div>
          <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.02em" }}>Bentornato</div>
          <div style={{ fontSize: 13, color: "var(--t-3)", marginTop: 6 }}>Accedi al tuo account Aura</div>
        </div>

        <OB_Field label="Email" type="email" placeholder="nome@email.com" value={email} onChange={e => setEmail(e.target.value)}/>
        <div style={{ marginBottom: 16 }}>
          <div className="mono" style={{ marginBottom: 8 }}>Password</div>
          <input type="password" placeholder="••••••••" value={pw} onChange={e => setPw(e.target.value)} style={{
            width: "100%", boxSizing: "border-box", background: "var(--bg-1)", border: "1px solid var(--hair)",
            borderRadius: 14, padding: "13px 16px", color: "var(--t-1)", fontSize: 14.5, fontFamily: "var(--f-ui)", outline: "none",
          }}/>
        </div>
        <div style={{ textAlign: "right", marginBottom: 22 }}>
          <button onClick={() => showToast("Email di recupero inviata", "send")} style={{ background: "transparent", border: 0, cursor: "pointer", color: "var(--gold)", fontSize: 12.5, fontFamily: "var(--f-ui)" }}>Password dimenticata?</button>
        </div>

        <div className="mono" style={{ marginBottom: 8 }}>Accedi come</div>
        <div style={{ display: "flex", gap: 4, padding: 4, background: "rgba(255,255,255,0.04)", borderRadius: 12, border: "1px solid var(--hair)", marginBottom: 24 }}>
          {[["waiter", "Cameriere"], ["manager", "Ristoratore"]].map(([id, lbl]) => (
            <button key={id} onClick={() => setLoginRole(id)} style={{
              flex: 1, padding: "10px 8px",
              background: loginRole === id ? "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))" : "transparent",
              color: loginRole === id ? "#1a1206" : "var(--t-2)",
              border: 0, borderRadius: 9, fontSize: 12.5, fontWeight: 600, fontFamily: "var(--f-ui)", cursor: "pointer",
            }}>{lbl}</button>
          ))}
        </div>

        <div style={{ flex: 1 }} />
        <button onClick={() => valid && onLogin(loginRole)} disabled={!valid}
          className={valid ? "btn-gold" : "btn-ghost"}
          style={{ width: "100%", padding: 16, fontSize: 15.5, opacity: valid ? 1 : 0.5 }}>
          Entra
        </button>
        <div className="mono" style={{ textAlign: "center", marginTop: 14, color: "var(--t-4)" }}>Demo · qualsiasi password di 4+ caratteri</div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// ROLE PICKER
// ─────────────────────────────────────────────────────────────
const OB_Role = ({ onPick }) => (
  <div className="screen-enter" style={{ padding: "8px 24px 40px" }}>
    <div className="serif" style={{ fontSize: 28, letterSpacing: "-0.02em", marginBottom: 8 }}>Come usi Aura?</div>
    <div style={{ fontSize: 13.5, color: "var(--t-3)", marginBottom: 28 }}>Potrai cambiare in qualsiasi momento dalle impostazioni.</div>

    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {[
        { id: "waiter", icon: "user", title: "Sono un professionista", sub: "Cameriere, sommelier, chef de rang, runner. Costruisci reputazione e trova turni.", chips: ["RECENSIONI", "BADGE", "WALLET"] },
        { id: "manager", icon: "users", title: "Gestisco un locale", sub: "Ristoratore o manager di sala. Trova talenti verificati e gestisci lo staff.", chips: ["TALENTI", "TURNI", "CHIAMATA EXTRA"] },
      ].map(o => (
        <button key={o.id} onClick={() => onPick(o.id)} className="card tap" style={{
          textAlign: "left", padding: 20, cursor: "pointer", color: "var(--t-1)",
          display: "flex", flexDirection: "column", gap: 14,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{
              width: 50, height: 50, borderRadius: 14, flexShrink: 0,
              background: "linear-gradient(160deg, oklch(0.30 0.04 70), oklch(0.18 0.02 60))",
              border: "1px solid var(--hair-2)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <Icon name={o.icon} size={24} color="var(--gold)"/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.01em" }}>{o.title}</div>
            </div>
            <Icon name="chevR" size={18} color="var(--t-3)"/>
          </div>
          <div style={{ fontSize: 12.5, color: "var(--t-3)", lineHeight: 1.5 }}>{o.sub}</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {o.chips.map(c => <Pill key={c} small>{c}</Pill>)}
          </div>
        </button>
      ))}
    </div>
  </div>
);

// ─────────────────────────────────────────────────────────────
// Shared step scaffold
// ─────────────────────────────────────────────────────────────
const OB_Step = ({ eyebrow, title, sub, children, cta = "Continua", ctaDisabled, onNext, footnote }) => (
  <div className="screen-enter" style={{ padding: "8px 24px 40px", display: "flex", flexDirection: "column", minHeight: "100%" }}>
    {eyebrow && <div className="mono" style={{ marginBottom: 10, color: "var(--gold)" }}>{eyebrow}</div>}
    <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.02em", marginBottom: 8 }}>{title}</div>
    {sub && <div style={{ fontSize: 13.5, color: "var(--t-3)", lineHeight: 1.5, marginBottom: 24 }}>{sub}</div>}
    <div style={{ flex: 1 }}>{children}</div>
    <button onClick={onNext} disabled={ctaDisabled}
      className={ctaDisabled ? "btn-ghost" : "btn-gold"}
      style={{ width: "100%", padding: 16, fontSize: 15, marginTop: 24, opacity: ctaDisabled ? 0.5 : 1 }}>
      {cta}
    </button>
    {footnote && <div className="mono" style={{ textAlign: "center", marginTop: 12, color: "var(--t-4)" }}>{footnote}</div>}
  </div>
);

const OB_Field = ({ label, ...props }) => (
  <div style={{ marginBottom: 16 }}>
    <div className="mono" style={{ marginBottom: 8 }}>{label}</div>
    <input {...props} style={{
      width: "100%", boxSizing: "border-box",
      background: "var(--bg-1)", border: "1px solid var(--hair)", borderRadius: 14,
      padding: "13px 16px", color: "var(--t-1)", fontSize: 14.5, fontFamily: "var(--f-ui)",
      outline: "none",
    }}/>
  </div>
);

// ─────────────────────────────────────────────────────────────
// WAITER — Dati
// ─────────────────────────────────────────────────────────────
const OB_Dati = ({ data, upd, onNext }) => {
  const roles = ["Chef de Rang", "Cameriere", "Sommelier", "Bartender", "Runner", "Hostess", "Maître"];
  return (
    <OB_Step
      eyebrow="Passo 1 · Il tuo profilo"
      title="Chi sei?"
      sub="Queste informazioni appariranno sul tuo profilo pubblico."
      cta="Continua"
      ctaDisabled={!data.name.trim()}
      onNext={onNext}>
      <OB_Field label="Nome e cognome" placeholder="Es. Marco Rossi"
        value={data.name} onChange={e => upd({ name: e.target.value })}/>
      <OB_Field label="Città" placeholder="Milano"
        value={data.city} onChange={e => upd({ city: e.target.value })}/>
      <div className="mono" style={{ marginBottom: 8 }}>Ruolo principale</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
        {roles.map(r => (
          <Pill key={r} small active={data.mainRole === r} gold={data.mainRole === r} onClick={() => upd({ mainRole: r })}>{r}</Pill>
        ))}
      </div>
    </OB_Step>
  );
};

// ─────────────────────────────────────────────────────────────
// WAITER — Identità
// ─────────────────────────────────────────────────────────────
const OB_Identita = ({ data, mockUpload, onNext }) => {
  const done = data.idStatus !== "empty" && data.selfieStatus !== "empty";
  return (
    <OB_Step
      eyebrow="Passo 2 · Verifica identità"
      title="Confermiamo che sei tu"
      sub="La verifica è ciò che rende le tue recensioni affidabili. Niente profili falsi su Aura."
      cta={done ? "Continua" : "Continua"}
      ctaDisabled={!done}
      onNext={onNext}
      footnote="Dati cifrati · Conformi GDPR">
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 18 }}>
        <UploadSlot label="Documento d'identità" hint="Carta d'identità o patente · fronte/retro"
          status={data.idStatus === "uploaded" ? "verified" : data.idStatus}
          filename="documento.jpg"
          onClick={() => data.idStatus === "empty" && mockUpload("idStatus")}/>
        <UploadSlot label="Selfie di verifica" hint="Un breve scatto per confermare il volto"
          status={data.selfieStatus === "uploaded" ? "verified" : data.selfieStatus}
          filename="selfie.jpg"
          onClick={() => data.selfieStatus === "empty" && mockUpload("selfieStatus")}/>
      </div>
      <div className="card" style={{ padding: 14, display: "flex", gap: 12, alignItems: "flex-start" }}>
        <Icon name="shield2" size={18} color="var(--gold)" style={{ marginTop: 2 }}/>
        <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.5 }}>
          Verifica gestita da partner certificato. Aura <strong style={{ color: "var(--t-1)" }}>non conserva</strong> il tuo documento dopo l'approvazione.
        </div>
      </div>
    </OB_Step>
  );
};

// ─────────────────────────────────────────────────────────────
// WAITER — Wallet
// ─────────────────────────────────────────────────────────────
const OB_Wallet = ({ data, upd, onNext }) => (
  <OB_Step
    eyebrow="Passo 3 · Pagamenti"
    title="Collega il tuo IBAN"
    sub="Ricevi i compensi dei turni direttamente sul tuo conto, gestiti in sicurezza da Stripe."
    cta={data.ibanLinked ? "Continua" : "Salta per ora"}
    onNext={onNext}
    footnote="Powered by Stripe · Aura non tocca i tuoi soldi">
    <OB_Field label="IBAN" placeholder="IT60 X000 0000 0000 0000 0000"
      value={data.iban}
      onChange={e => upd({ iban: e.target.value, ibanLinked: e.target.value.length > 8 })}/>
    {data.ibanLinked && (
      <div className="card fade-in" style={{ padding: 14, display: "flex", gap: 12, alignItems: "center", marginBottom: 16 }}>
        <div style={{
          width: 34, height: 34, borderRadius: 9,
          background: "oklch(0.80 0.140 150 / 0.10)", border: "1px solid oklch(0.80 0.140 150 / 0.40)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Icon name="check" size={16} color="var(--pos)" strokeWidth={2.2}/>
        </div>
        <div style={{ fontSize: 12.5, color: "var(--t-2)" }}>IBAN pronto per la verifica Stripe</div>
      </div>
    )}
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {[
        ["Pagamenti entro 48h dal turno", "clock"],
        ["Trasferimenti gratuiti sul piano Pro", "euro"],
        ["Storico e ricevute scaricabili", "doc"],
      ].map(([t, ic]) => (
        <div key={t} style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Icon name={ic} size={16} color="var(--gold)"/>
          <span style={{ fontSize: 13, color: "var(--t-2)" }}>{t}</span>
        </div>
      ))}
    </div>
  </OB_Step>
);

// ─────────────────────────────────────────────────────────────
// WAITER — Competenze
// ─────────────────────────────────────────────────────────────
const OB_Competenze = ({ data, upd, mockUpload, onNext }) => {
  const allSkills = ["VELOCE", "CORTESE", "GENTILE", "VINO", "COCKTAIL", "MULTI", "EVENTI"];
  const toggle = (s) => {
    const n = new Set(data.skills);
    if (n.has(s)) n.delete(s); else n.add(s);
    upd({ skills: n });
  };
  return (
    <OB_Step
      eyebrow="Passo 4 · Competenze"
      title="Cosa sai fare meglio?"
      sub="Seleziona le tue aree. I badge si confermeranno con le recensioni verificate o caricando un attestato."
      cta="Crea il mio profilo"
      onNext={onNext}>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
        {allSkills.map(s => (
          <Pill key={s} active={data.skills.has(s)} gold={data.skills.has(s)} onClick={() => toggle(s)}>{s}</Pill>
        ))}
      </div>
      <div className="mono" style={{ marginBottom: 12 }}>Hai certificazioni? · facoltativo</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <UploadSlot label="Attestato AIS Sommelier" hint="Sblocca subito il badge VINO"
          status={data.certs.ais} filename="attestato_AIS.pdf"
          onClick={() => data.certs.ais === "empty" && mockUpload("ais", "certs")}/>
        <UploadSlot label="Certificato HACCP" hint="Richiesto da molti locali"
          status={data.certs.haccp} filename="haccp.pdf"
          onClick={() => data.certs.haccp === "empty" && mockUpload("haccp", "certs")}/>
      </div>
    </OB_Step>
  );
};

// ─────────────────────────────────────────────────────────────
// MANAGER — Locale
// ─────────────────────────────────────────────────────────────
const OB_Locale = ({ data, upd, onNext }) => {
  const types = ["Trattoria", "Ristorante", "Osteria", "Bar", "Hotel", "Catering", "Bistrot"];
  return (
    <OB_Step
      eyebrow="Passo 1 · Il tuo locale"
      title="Parlaci del locale"
      sub="Queste informazioni aiutano i talenti a capire dove lavoreranno."
      cta="Continua"
      ctaDisabled={!data.venue.trim()}
      onNext={onNext}>
      <OB_Field label="Nome del locale" placeholder="Es. Trattoria da Gino"
        value={data.venue} onChange={e => upd({ venue: e.target.value })}/>
      <OB_Field label="Città" placeholder="Milano"
        value={data.city} onChange={e => upd({ city: e.target.value })}/>
      <div className="mono" style={{ marginBottom: 8 }}>Tipo di locale</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 20 }}>
        {types.map(t => (
          <Pill key={t} small active={data.venueType === t} gold={data.venueType === t} onClick={() => upd({ venueType: t })}>{t}</Pill>
        ))}
      </div>
      <div className="mono" style={{ marginBottom: 10 }}>Coperti medi a servizio · {data.covers}</div>
      <div className="card" style={{ padding: 16 }}>
        <input type="range" min={10} max={150} step={5} value={data.covers}
          onChange={e => upd({ covers: +e.target.value })}
          style={{ width: "100%", accentColor: "oklch(0.81 0.115 82)" }}/>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
          <span className="mono">10</span><span className="mono">150+</span>
        </div>
      </div>
    </OB_Step>
  );
};

// ─────────────────────────────────────────────────────────────
// MANAGER — P.IVA / verifica attività
// ─────────────────────────────────────────────────────────────
const OB_Piva = ({ data, mockUpload, onNext }) => (
  <OB_Step
    eyebrow="Passo 2 · Verifica attività"
    title="Verifichiamo il locale"
    sub="Solo locali verificati possono contattare i talenti. Protegge entrambe le parti."
    cta="Continua"
    ctaDisabled={data.pivaStatus === "empty"}
    onNext={onNext}
    footnote="Verifica entro 24h lavorative">
    <OB_Field label="Partita IVA" placeholder="IT 0000 0000 000"/>
    <div className="mono" style={{ marginBottom: 8, marginTop: 4 }}>Visura o documento attività</div>
    <UploadSlot label="Carica documento" hint="Visura camerale o licenza · PDF"
      status={data.pivaStatus} filename="visura_camerale.pdf"
      onClick={() => data.pivaStatus === "empty" && mockUpload("pivaStatus")}/>
    <div className="card" style={{ padding: 14, display: "flex", gap: 12, alignItems: "flex-start", marginTop: 16 }}>
      <Icon name="shield2" size={18} color="var(--gold)" style={{ marginTop: 2 }}/>
      <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.5 }}>
        Il badge <strong style={{ color: "var(--t-1)" }}>Locale Verificato</strong> aumenta del 60% le risposte dei talenti alle tue richieste.
      </div>
    </div>
  </OB_Step>
);

// ─────────────────────────────────────────────────────────────
// MANAGER — Team / invita
// ─────────────────────────────────────────────────────────────
const OB_Team = ({ onNext }) => {
  const [invited, setInvited] = React.useState(new Set());
  const staff = [
    { init: "MR", name: "Marco Rossi", role: "Chef de Rang", tone: 0 },
    { init: "EC", name: "Elisa Conte", role: "Sommelier", tone: 4 },
    { init: "LT", name: "Luca Trapani", role: "Cameriere", tone: 2 },
  ];
  const toggle = (i) => {
    const n = new Set(invited);
    if (n.has(i)) n.delete(i); else n.add(i);
    setInvited(n);
  };
  return (
    <OB_Step
      eyebrow="Passo 3 · Il tuo team"
      title="Invita chi già lavora con te"
      sub="Collega lo staff esistente per gestire turni e presenze fin da subito. Puoi farlo anche dopo."
      cta={invited.size > 0 ? `Invita ${invited.size} e continua` : "Salta per ora"}
      onNext={onNext}>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {staff.map((s, i) => (
          <div key={i} onClick={() => toggle(i)} className="card tap" style={{
            padding: 14, display: "flex", alignItems: "center", gap: 12,
            borderColor: invited.has(i) ? "var(--gold)" : undefined,
          }}>
            <Avatar initials={s.init} size={42} tone={s.tone}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600 }}>{s.name}</div>
              <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{s.role}</div>
            </div>
            <div style={{
              width: 24, height: 24, borderRadius: 999,
              border: `1.5px solid ${invited.has(i) ? "var(--gold)" : "var(--hair-2)"}`,
              background: invited.has(i) ? "var(--gold)" : "transparent",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              {invited.has(i) && <Icon name="check" size={14} color="#1a1206" strokeWidth={2.6}/>}
            </div>
          </div>
        ))}
      </div>
      <button onClick={() => showToast("Invito inviato", "send")} style={{
        width: "100%", marginTop: 12, padding: 13,
        background: "transparent", border: "1px dashed var(--hair-2)", borderRadius: 14,
        color: "var(--t-2)", fontSize: 13, fontFamily: "var(--f-ui)", cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
      }}>
        <Icon name="plus" size={16} color="var(--t-2)"/> Invita via email o telefono
      </button>
    </OB_Step>
  );
};

// ─────────────────────────────────────────────────────────────
// DONE
// ─────────────────────────────────────────────────────────────
const OB_Done = ({ role, data, onFinish }) => {
  const isManager = role === "manager";
  const name = isManager ? (data.venue || "Trattoria da Gino") : (data.name || "Marco Rossi");
  return (
    <div className="screen-enter" style={{
      height: "100%", display: "flex", flexDirection: "column",
      justifyContent: "center", alignItems: "center", textAlign: "center", padding: "0 28px",
    }}>
      <div style={{
        width: 110, height: 110, borderRadius: 999, marginBottom: 26,
        background: "radial-gradient(circle, var(--gold-glow), transparent 70%)",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <div className="gold-pulse" style={{
          width: 80, height: 80, borderRadius: 999,
          background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Icon name="check" size={42} color="#1a1206" strokeWidth={2.4}/>
        </div>
      </div>
      <div className="mono" style={{ marginBottom: 10, color: "var(--gold)" }}>
        {isManager ? "LOCALE REGISTRATO" : "PROFILO CREATO"}
      </div>
      <div className="serif" style={{ fontSize: 28, letterSpacing: "-0.02em", marginBottom: 12 }}>
        Tutto pronto, {name.split(" ")[0]}.
      </div>
      <div style={{ fontSize: 13.5, color: "var(--t-3)", lineHeight: 1.55, maxWidth: 290, marginBottom: 28 }}>
        {isManager
          ? "Verifica attività in corso. Intanto puoi già esplorare il mercato talenti."
          : "Verifica identità in corso (entro 24h). Inizia subito a costruire la tua Aura."}
      </div>

      {/* Next steps */}
      <div className="card" style={{ width: "100%", maxWidth: 330, padding: 6, marginBottom: 24, overflow: "hidden" }}>
        {(isManager
          ? [["Pubblica il tuo primo turno", "calendar"], ["Esplora i talenti in zona", "search"], ["Completa la verifica P.IVA", "shield2"]]
          : [["Mostra il QR al primo cliente", "qr"], ["Carica altre certificazioni", "doc"], ["Completa il piano Pro", "spark"]]
        ).map(([t, ic], i, arr) => (
          <div key={t} style={{
            display: "flex", alignItems: "center", gap: 12, padding: "12px 14px",
            borderBottom: i === arr.length - 1 ? "none" : "1px solid var(--hair)",
          }}>
            <Icon name={ic} size={17} color="var(--gold)"/>
            <span style={{ flex: 1, textAlign: "left", fontSize: 13.5, color: "var(--t-1)" }}>{t}</span>
            <Icon name="chevR" size={15} color="var(--t-4)"/>
          </div>
        ))}
      </div>

      <button onClick={onFinish} className="btn-gold" style={{ width: "100%", maxWidth: 330, padding: 16, fontSize: 15.5 }}>
        Entra in Aura
      </button>
    </div>
  );
};

Object.assign(window, { OnboardingFlow });
