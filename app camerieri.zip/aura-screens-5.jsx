// Aura — Screens part 5: lato Ristoratore (Pubblica turno, Annunci, Candidature)

// ─────────────────────────────────────────────────────────────
// SCREEN — PUBBLICA TURNO
// ─────────────────────────────────────────────────────────────
const ScreenPubblicaTurno = ({ onClose, onPublished }) => {
  const [role, setRole] = React.useState("Cameriere");
  const [day, setDay] = React.useState("Sab 15 nov");
  const [from, setFrom] = React.useState("19:00");
  const [to, setTo] = React.useState("00:30");
  const [pay, setPay] = React.useState(165);
  const [badges, setBadges] = React.useState(new Set(["VELOCE", "CORTESE"]));
  const [note, setNote] = React.useState("");
  const [phase, setPhase] = React.useState("form"); // form | done

  const roles = ["Cameriere", "Chef de Rang", "Sommelier", "Runner", "Hostess", "Bartender"];
  const days = ["Ven 14 nov", "Sab 15 nov", "Dom 16 nov", "Lun 17 nov", "Mar 18 nov"];
  const toggleBadge = (b) => {
    const n = new Set(badges);
    if (n.has(b)) n.delete(b); else n.add(b);
    setBadges(n);
  };

  // Pseudo reach estimate
  const reach = Math.max(6, 40 - badges.size * 4 - (role === "Sommelier" ? 10 : 0));

  // Service fee — Aura take rate (the core monetizable event)
  const FEE_RATE = 0.10;
  const fee = Math.round(pay * FEE_RATE);
  const total = pay + fee;

  // Chiamo il mio staff (0% commissione) vs cerco un extra su Aura (marketplace)
  const [mode, setMode] = React.useState("extra"); // extra | staff
  const [assignTo, setAssignTo] = React.useState(null);
  const allStaff = (window.AURA && window.AURA.staff) || [];
  const myStaff = allStaff.filter(s => s.type === "fisso" || s.type === "chiamata");

  const TopHeader = (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 18px" }}>
      <button onClick={onClose} style={iconBtn}><Icon name="close" size={18} color="var(--t-2)" /></button>
      <div>
        <div className="mono" style={{ color: "var(--gold)" }}>NUOVO TURNO</div>
        <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Copri un turno</div>
      </div>
    </div>
  );

  const ModeToggle = (
    <div style={{ display: "flex", gap: 4, padding: 4, background: "rgba(255,255,255,0.04)", borderRadius: 14, marginBottom: 18, border: "1px solid var(--hair)" }}>
      {[
        { id: "staff", label: "Chiamo il mio staff", tag: "0%" },
        { id: "extra", label: "Cerco un extra", tag: "10%" },
      ].map(m => {
        const on = mode === m.id;
        return (
          <button key={m.id} onClick={() => setMode(m.id)} style={{
            flex: 1, padding: "9px 6px", borderRadius: 10, border: 0, cursor: "pointer",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
            background: on ? "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))" : "transparent",
            color: on ? "#1a1206" : "var(--t-3)", fontFamily: "var(--f-ui)", transition: "all .15s ease"
          }}>
            <span style={{ fontSize: 12.5, fontWeight: 600 }}>{m.label}</span>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 8, letterSpacing: "0.08em", opacity: 0.82 }}>COMMISSIONE {m.tag}</span>
          </button>
        );
      })}
    </div>
  );

  if (phase === "done") {
    const isStaff = mode === "staff";
    const aChiamata = isStaff && assignTo && assignTo.type === "chiamata";
    return (
      <div className="screen-enter" style={{
        padding: "8px 24px 40px", color: "var(--t-1)", height: "100%",
        display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center",
      }}>
        <div style={{
          width: 110, height: 110, borderRadius: 999, marginBottom: 24,
          background: "radial-gradient(circle, var(--gold-glow), transparent 70%)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <div className="gold-pulse" style={{
            width: 80, height: 80, borderRadius: 999,
            background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Icon name={isStaff ? "check" : "broadcast"} size={36} color="#1a1206" strokeWidth={2}/>
          </div>
        </div>
        <div className="mono" style={{ marginBottom: 10, color: "var(--gold)" }}>{isStaff ? "TURNO ASSEGNATO" : "ANNUNCIO PUBBLICATO"}</div>
        <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.02em", marginBottom: 12 }}>
          {isStaff ? (assignTo ? assignTo.name : role) : `${role} · ${day}`}
        </div>
        <div style={{ fontSize: 13.5, color: "var(--t-3)", lineHeight: 1.55, maxWidth: 300, marginBottom: 28 }}>
          {isStaff ? (
            aChiamata ? (
              <>Turno di {day} assegnato. <span style={{ color: "var(--gold)" }}>Comunicazione preventiva inviata</span> all'Ispettorato del Lavoro. Nessuna commissione Aura.</>
            ) : (
              <>Turno di {day} assegnato a <span style={{ color: "var(--t-1)" }}>{assignTo ? assignTo.name.split(" ")[0] : ""}</span>. Gestito in busta paga — <span style={{ color: "var(--gold)" }}>nessuna commissione</span>.</>
            )
          ) : (
            <>Visibile a <span style={{ color: "var(--gold)" }}>{reach} talenti</span> in zona con i badge richiesti. Riceverai una notifica a ogni candidatura.</>
          )}
        </div>
        <button onClick={isStaff ? onClose : onPublished} className="btn-gold" style={{ width: "100%", maxWidth: 330, padding: 16, fontSize: 15.5 }}>
          {isStaff ? "Torna alla dashboard" : "Vedi i miei annunci"}
        </button>
        {!isStaff &&
        <button onClick={onClose} style={{ background: "transparent", border: 0, cursor: "pointer", marginTop: 14, color: "var(--t-3)", fontSize: 13, fontFamily: "var(--f-ui)" }}>
          Torna alla dashboard
        </button>
        }
      </div>
    );
  }

  if (mode === "staff") {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
        {TopHeader}
        {ModeToggle}

        <div className="card" style={{ padding: "14px 16px", marginBottom: 22, display: "flex", gap: 11, background: "linear-gradient(135deg, oklch(0.22 0.018 75) 0%, oklch(0.17 0.012 65) 100%)", borderColor: "oklch(0.80 0.140 150 / 0.40)" }}>
          <Icon name="shield2" size={20} color="var(--pos)" />
          <div style={{ fontSize: 12, color: "var(--t-2)", lineHeight: 1.5 }}>
            Stai assegnando il turno a personale <span style={{ color: "var(--t-1)" }}>già tuo</span>. Nessuna commissione Aura: il compenso passa dalla busta paga, gestita dal tuo commercialista.
          </div>
        </div>

        <div className="mono" style={{ marginBottom: 10 }}>Giorno</div>
        <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 22, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20 }}>
          {days.map(d => <Pill key={d} active={day === d} gold={day === d} onClick={() => setDay(d)}>{d}</Pill>)}
        </div>

        <div style={{ display: "flex", gap: 12, marginBottom: 22 }}>
          <div style={{ flex: 1 }}>
            <div className="mono" style={{ marginBottom: 8 }}>Dalle</div>
            <input value={from} onChange={e => setFrom(e.target.value)} style={inputStyle}/>
          </div>
          <div style={{ flex: 1 }}>
            <div className="mono" style={{ marginBottom: 8 }}>Alle</div>
            <input value={to} onChange={e => setTo(e.target.value)} style={inputStyle}/>
          </div>
        </div>

        <div className="mono" style={{ marginBottom: 10 }}>Chi chiami</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
          {myStaff.map(s => {
            const sel = assignTo && assignTo.init === s.init;
            const chiamata = s.type === "chiamata";
            return (
              <button key={s.init} onClick={() => setAssignTo(s)} style={{
                display: "flex", alignItems: "center", gap: 12, textAlign: "left", width: "100%",
                padding: "12px 14px", borderRadius: 16, cursor: "pointer",
                background: sel ? "oklch(0.81 0.115 82 / 0.08)" : "var(--bg-1)",
                border: `1.5px solid ${sel ? "var(--gold)" : "var(--hair)"}`, transition: "all .14s ease"
              }}>
                <Avatar initials={s.init} size={40} tone={s.tone} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{s.name}</div>
                  <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{s.role} · {s.hours} questo mese</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
                  <span className="mono" style={{ fontSize: 8, padding: "3px 7px", borderRadius: 999, background: chiamata ? "oklch(0.78 0.140 50 / 0.12)" : "oklch(0.80 0.140 150 / 0.12)", color: chiamata ? "var(--warn)" : "var(--pos)" }}>
                    {chiamata ? "A CHIAMATA" : "FISSO"}
                  </span>
                  <span style={{ width: 18, height: 18, borderRadius: 999, border: `1.5px solid ${sel ? "var(--gold)" : "var(--hair-2)"}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {sel && <span style={{ width: 9, height: 9, borderRadius: 999, background: "var(--gold)" }} />}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {assignTo && assignTo.type === "chiamata" &&
        <div className="card" style={{ padding: "13px 15px", marginBottom: 18, display: "flex", gap: 10, background: "oklch(0.78 0.140 50 / 0.07)", borderColor: "oklch(0.78 0.140 50 / 0.35)" }}>
          <Icon name="alert" size={18} color="var(--warn)" />
          <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.5 }}>
            Contratto a chiamata: all'assegnazione Aura invia la <span style={{ color: "var(--t-1)" }}>comunicazione preventiva</span> all'Ispettorato del Lavoro (obbligatoria, almeno il giorno prima).
          </div>
        </div>
        }

        <div className="mono" style={{ marginBottom: 10 }}>Riepilogo costi</div>
        <div className="card" style={{ padding: "6px 16px 16px", marginBottom: 20 }}>
          <Row label="Compenso al professionista" value="In busta paga" />
          <Row label="Commissione Aura" value="€ 0 · 0%" gold last />
          <div style={{ height: 1, background: "var(--hair)", margin: "2px 0 12px" }} />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 13.5, fontWeight: 600 }}>Costo aggiuntivo Aura</span>
            <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 22, letterSpacing: "-0.02em", color: "var(--pos)" }}>€ 0</span>
          </div>
          <div style={{ fontSize: 11.5, color: "var(--t-3)", lineHeight: 1.55, marginTop: 12 }}>
            Il personale interno è incluso nell'abbonamento. Aura traccia le ore e te le esporta per il commercialista.
          </div>
        </div>

        <button onClick={() => assignTo && setPhase("done")} className="btn-gold" style={{ width: "100%", padding: 16, fontSize: 15, opacity: assignTo ? 1 : 0.45 }}>
          {assignTo ? `Assegna a ${assignTo.name.split(" ")[0]}` : "Seleziona una persona"}
        </button>
        <div className="mono" style={{ textAlign: "center", marginTop: 12, color: "var(--t-4)" }}>
          Gestisci organico e ore in “Il mio staff”
        </div>
      </div>
    );
  }

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      {TopHeader}
      {ModeToggle}

      <div className="mono" style={{ marginBottom: 10 }}>Ruolo cercato</div>
      <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 22, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20 }}>
        {roles.map(r => <Pill key={r} active={role === r} gold={role === r} onClick={() => setRole(r)}>{r}</Pill>)}
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Giorno</div>
      <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 22, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20 }}>
        {days.map(d => <Pill key={d} active={day === d} gold={day === d} onClick={() => setDay(d)}>{d}</Pill>)}
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 22 }}>
        <div style={{ flex: 1 }}>
          <div className="mono" style={{ marginBottom: 8 }}>Dalle</div>
          <input value={from} onChange={e => setFrom(e.target.value)} style={inputStyle}/>
        </div>
        <div style={{ flex: 1 }}>
          <div className="mono" style={{ marginBottom: 8 }}>Alle</div>
          <input value={to} onChange={e => setTo(e.target.value)} style={inputStyle}/>
        </div>
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Compenso · € {pay}</div>
      <div className="card" style={{ padding: 16, marginBottom: 22 }}>
        <input type="range" min={80} max={400} step={5} value={pay}
          onChange={e => setPay(+e.target.value)}
          style={{ width: "100%", accentColor: "oklch(0.81 0.115 82)" }}/>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
          <span className="mono">€ 80</span>
          <span className="mono">€ 400</span>
        </div>
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Badge richiesti</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 22 }}>
        {["VELOCE", "CORTESE", "VINO", "COCKTAIL", "MULTI", "GENTILE", "EVENTI"].map(b => (
          <Pill key={b} small active={badges.has(b)} gold={badges.has(b)} onClick={() => toggleBadge(b)}>{b}</Pill>
        ))}
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Note · facoltative</div>
      <textarea value={note} onChange={e => setNote(e.target.value)}
        placeholder="Es. divisa nera, esperienza con menù degustazione…"
        rows={3} style={{ ...inputStyle, resize: "vertical", marginBottom: 16 }}/>

      {/* Reach estimate */}
      <div className="card" style={{
        padding: "14px 18px", marginBottom: 16, display: "flex", alignItems: "center", gap: 12,
        background: "linear-gradient(135deg, oklch(0.22 0.018 75) 0%, oklch(0.17 0.012 65) 100%)", borderColor: "var(--gold)",
      }}>
        <Icon name="users" size={20} color="var(--gold)"/>
        <div style={{ flex: 1, fontSize: 12.5, color: "var(--t-2)" }}>
          Stima copertura: <strong style={{ color: "var(--gold)" }}>~{reach} talenti</strong> riceveranno l'annuncio
        </div>
      </div>

      {/* Cost summary — service fee */}
      <div className="mono" style={{ marginBottom: 10 }}>Riepilogo costi</div>
      <div className="card" style={{ padding: "6px 16px 16px", marginBottom: 20 }}>
        <Row label="Compenso al professionista" value={`€ ${pay}`} />
        <Row label="Commissione di servizio · 10%" value={`€ ${fee}`} last />
        <div style={{ height: 1, background: "var(--hair)", margin: "2px 0 12px" }} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 13.5, fontWeight: 600 }}>Totale a tuo carico</span>
          <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 22, letterSpacing: "-0.02em", color: "var(--gold)" }}>€ {total}</span>
        </div>
        <div style={{ display: "flex", gap: 9, marginTop: 14, padding: "11px 13px", borderRadius: 13, background: "rgba(255,255,255,0.03)", border: "1px solid var(--hair)" }}>
          <Icon name="shield2" size={16} color="var(--pos)" style={{ flexShrink: 0, marginTop: 1 }} />
          <div style={{ fontSize: 11.5, color: "var(--t-3)", lineHeight: 1.55 }}>
            Paghi <span style={{ color: "var(--t-2)" }}>solo a turno coperto</span>. La commissione copre pagamenti sicuri, verifica identità e tutela. Sul piano <span style={{ color: "var(--gold)" }}>Business</span> scende al 6%.
          </div>
        </div>
      </div>

      <button onClick={() => setPhase("done")} className="btn-gold" style={{ width: "100%", padding: 16, fontSize: 15 }}>
        Pubblica annuncio
      </button>
      <div className="mono" style={{ textAlign: "center", marginTop: 12, color: "var(--t-4)" }}>
        Annunci illimitati sul piano Business
      </div>
    </div>
  );
};

const inputStyle = {
  width: "100%", boxSizing: "border-box",
  background: "var(--bg-1)", border: "1px solid var(--hair)", borderRadius: 14,
  padding: "13px 16px", color: "var(--t-1)", fontSize: 14.5, fontFamily: "var(--f-ui)", outline: "none",
};

// ─────────────────────────────────────────────────────────────
// SCREEN — I MIEI ANNUNCI
// ─────────────────────────────────────────────────────────────
const ScreenAnnunci = ({ onClose, onOpenCandidature, onPubblica }) => {
  const posts = [
    { id: 1, role: "Cameriere", day: "Sab 15 nov", time: "19:00–00:30", pay: "€ 165", applicants: 7, status: "open", badges: ["VELOCE", "CORTESE"] },
    { id: 2, role: "Sommelier", day: "Ven 22 nov", time: "18:00–01:00", pay: "€ 220", applicants: 3, status: "open", badges: ["VINO", "EVENTI"], event: "Evento privato" },
    { id: 3, role: "Runner", day: "Dom 16 nov", time: "12:00–16:00", pay: "€ 90", applicants: 0, status: "open", badges: ["VELOCE"] },
    { id: 4, role: "Chef de Rang", day: "Gio 13 nov", time: "19:00–00:00", pay: "€ 150", applicants: 5, status: "filled", badges: ["VINO"], assigned: "Marco Rossi" },
  ];

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 0 22px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
          <div>
            <div className="mono">Trattoria da Gino</div>
            <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>I miei annunci</div>
          </div>
        </div>
        <button onClick={onPubblica} aria-label="nuovo annuncio" style={{
          ...iconBtn, background: "var(--gold)", border: 0,
        }}><Icon name="plus" size={20} color="#1a1206"/></button>
      </div>

      <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 18, overflowX: "auto" }}>
        <Pill active small gold>ATTIVI · 3</Pill>
        <Pill small>ASSEGNATI · 1</Pill>
        <Pill small>ARCHIVIO</Pill>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {posts.map(p => (
          <div key={p.id} onClick={() => p.status === "open" && onOpenCandidature(p)}
            className={p.status === "open" ? "card tap" : "card"}
            style={{ padding: 16, opacity: p.status === "filled" ? 0.72 : 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
                  <span style={{ fontSize: 15.5, fontWeight: 600 }}>{p.role}</span>
                  {p.event && <span className="mono" style={{ fontSize: 8, padding: "2px 6px", borderRadius: 4, background: "rgba(255,200,90,0.10)", color: "var(--gold)" }}>{p.event}</span>}
                </div>
                <div style={{ fontSize: 12.5, color: "var(--t-3)" }}>{p.day} · {p.time}</div>
              </div>
              <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 17, color: "var(--gold)" }}>{p.pay}</div>
            </div>
            <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 14 }}>
              {p.badges.map(b => <Pill key={b} small active>{b}</Pill>)}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 12, borderTop: "1px solid var(--hair)" }}>
              {p.status === "open" ? (
                <>
                  <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                    {p.applicants > 0 ? (
                      <>
                        <span className="warn-pulse" style={{ width: 7, height: 7, borderRadius: 99, background: "var(--gold)" }}/>
                        <span style={{ fontSize: 13, color: "var(--t-1)", fontWeight: 500 }}>{p.applicants} candidature</span>
                      </>
                    ) : (
                      <span style={{ fontSize: 12.5, color: "var(--t-3)" }}>In attesa di candidature…</span>
                    )}
                  </div>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12, color: "var(--gold)", fontWeight: 600 }}>
                    Gestisci <Icon name="chevR" size={14} color="var(--gold)"/>
                  </span>
                </>
              ) : (
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <Icon name="check" size={15} color="var(--pos)" strokeWidth={2.2}/>
                  <span style={{ fontSize: 12.5, color: "var(--t-2)" }}>Assegnato a <strong style={{ color: "var(--t-1)" }}>{p.assigned}</strong></span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// SCREEN — CANDIDATURE (per annuncio)
// ─────────────────────────────────────────────────────────────
const ScreenCandidature = ({ post, onClose, onOpenTalent }) => {
  const p = post || { role: "Cameriere", day: "Sab 15 nov", time: "19:00–00:30", pay: "€ 165" };
  const [sort, setSort] = React.useState("match"); // match | rating | distanza
  const [assigned, setAssigned] = React.useState(null);
  const [compare, setCompare] = React.useState(new Set());

  const baseCandidates = [
    { id: 1, init: "AS", name: "Anna Silva", role: "Cameriere", rating: 4.7, km: 1.2, badges: ["VELOCE", "CORTESE", "MULTI"], match: 96, exp: "4 anni", reviews: 88, when: "12 min fa", tone: 3 },
    { id: 2, init: "DS", name: "Davide Stoppa", role: "Chef de Rang", rating: 4.8, km: 2.8, badges: ["VELOCE", "VINO"], match: 91, exp: "6 anni", reviews: 142, when: "28 min fa", tone: 1 },
    { id: 3, init: "GR", name: "Giulia Romano", role: "Cameriere", rating: 4.9, km: 3.4, badges: ["CORTESE", "GENTILE"], match: 88, exp: "5 anni", reviews: 76, when: "1 ora fa", tone: 4 },
    { id: 4, init: "PA", name: "Paolo Amato", role: "Runner", rating: 4.6, km: 0.8, badges: ["VELOCE"], match: 82, exp: "2 anni", reviews: 34, when: "2 ore fa", tone: 2 },
    { id: 5, init: "LM", name: "Lucia Marchi", role: "Cameriere", rating: 4.7, km: 5.1, badges: ["CORTESE", "EVENTI"], match: 79, exp: "3 anni", reviews: 61, when: "3 ore fa", tone: 5 },
  ];

  const candidates = [...baseCandidates].sort((a, b) =>
    sort === "rating" ? b.rating - a.rating :
    sort === "distanza" ? a.km - b.km :
    b.match - a.match
  );

  const toggleCompare = (id) => {
    const n = new Set(compare);
    if (n.has(id)) n.delete(id);
    else if (n.size < 2) n.add(id);
    else showToast("Puoi confrontare massimo 2 profili", "alert");
    setCompare(n);
  };

  const doAssign = (c) => { setAssigned(c.id); showToast(`${c.name.split(" ")[0]} confermato · avvisato con notifica`, "check"); };

  const compareList = baseCandidates.filter(c => compare.has(c.id));

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 18px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="mono" style={{ color: "var(--gold)" }}>CANDIDATURE · {candidates.length}</div>
          <div className="serif" style={{ fontSize: 20, letterSpacing: "-0.01em" }}>{p.role} · {p.day}</div>
        </div>
      </div>

      {/* Post recap */}
      <div className="card" style={{ padding: "12px 16px", marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 12.5, color: "var(--t-3)" }}>{p.time}</span>
        <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 15, color: "var(--gold)" }}>{p.pay}</span>
      </div>

      {/* Sort */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
        <span className="mono" style={{ marginRight: 2 }}>Ordina</span>
        {[["match", "Match"], ["rating", "Rating"], ["distanza", "Distanza"]].map(([id, lbl]) => (
          <Pill key={id} small active={sort === id} gold={sort === id} onClick={() => setSort(id)}>{lbl}</Pill>
        ))}
      </div>

      {/* Compare bar */}
      {compare.size > 0 && (
        <div className="card fade-in" style={{
          padding: "12px 14px", marginBottom: 16, display: "flex", alignItems: "center", gap: 10,
          borderColor: "var(--gold)",
        }}>
          <Icon name="users" size={17} color="var(--gold)"/>
          <span style={{ flex: 1, fontSize: 12.5, color: "var(--t-2)" }}>{compare.size}/2 selezionati per il confronto</span>
          {compare.size === 2 && (
            <button onClick={() => { const el = document.getElementById("cmp"); if (el) el.scrollIntoView({ behavior: "smooth" }); }}
              className="btn-gold" style={{ padding: "7px 12px", fontSize: 11 }}>Confronta</button>
          )}
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {candidates.map(c => {
          const isAssigned = assigned === c.id;
          const inCompare = compare.has(c.id);
          return (
            <div key={c.id} className="card" style={{
              padding: 14, opacity: assigned && !isAssigned ? 0.55 : 1,
              borderColor: isAssigned ? "oklch(0.80 0.140 150 / 0.5)" : inCompare ? "var(--gold)" : undefined,
            }}>
              <div onClick={() => onOpenTalent({ ...c })} className="tap" style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12, borderRadius: 12 }}>
                <Avatar initials={c.init} size={50} tone={c.tone} ring/>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ fontSize: 14.5, fontWeight: 600 }}>{c.name}</span>
                    <Verified size={12}/>
                  </div>
                  <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{c.role} · {c.km} km · {c.when}</div>
                  <div style={{ display: "flex", gap: 4, marginTop: 8, flexWrap: "wrap" }}>
                    {c.badges.map(b => <Pill key={b} small active>{b}</Pill>)}
                  </div>
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <div style={{
                    display: "inline-flex", flexDirection: "column", alignItems: "center",
                    padding: "5px 9px", borderRadius: 10,
                    background: "rgba(255,200,90,0.10)", border: "1px solid oklch(0.81 0.115 82 / 0.35)",
                  }}>
                    <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 16, color: "var(--gold)", lineHeight: 1 }}>{c.match}%</span>
                    <span className="mono" style={{ fontSize: 7.5, marginTop: 2 }}>match</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 3, justifyContent: "flex-end", marginTop: 6 }}>
                    <Icon name="star" size={11} color="var(--gold)"/>
                    <span className="numeric" style={{ fontWeight: 700, fontSize: 12 }}>{c.rating}</span>
                  </div>
                </div>
              </div>
              <div style={{ display: "flex", gap: 8, paddingTop: 12, borderTop: "1px solid var(--hair)" }}>
                {isAssigned ? (
                  <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, color: "var(--pos)", fontSize: 13, fontWeight: 600 }}>
                    <Icon name="check" size={16} color="var(--pos)" strokeWidth={2.2}/> Assegnato
                  </div>
                ) : (
                  <>
                    <button onClick={() => toggleCompare(c.id)} className="btn-ghost" style={{
                      flex: 1, padding: 11, fontSize: 12.5,
                      borderColor: inCompare ? "var(--gold)" : undefined,
                      color: inCompare ? "var(--gold)" : undefined,
                    }}>{inCompare ? "✓ Confronto" : "Confronta"}</button>
                    <button onClick={() => doAssign(c)} disabled={!!assigned} className="btn-gold" style={{ flex: 1.3, padding: 11, fontSize: 12.5, opacity: assigned ? 0.5 : 1 }}>
                      Assegna turno
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Compare panel */}
      {compareList.length === 2 && (
        <div id="cmp" className="fade-in" style={{ marginTop: 22 }}>
          <div className="mono" style={{ marginBottom: 12, color: "var(--gold)" }}>CONFRONTO DIRETTO</div>
          <div className="card" style={{ padding: 16 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
              {compareList.map(c => (
                <div key={c.id} style={{ textAlign: "center" }}>
                  <Avatar initials={c.init} size={48} tone={c.tone} ring/>
                  <div style={{ fontSize: 13.5, fontWeight: 600, marginTop: 8 }}>{c.name.split(" ")[0]}</div>
                  <div style={{ fontSize: 11, color: "var(--t-3)", marginTop: 1 }}>{c.role}</div>
                </div>
              ))}
            </div>
            {[
              ["Match", c => `${c.match}%`, c => c.match, "max"],
              ["Rating", c => `★ ${c.rating}`, c => c.rating, "max"],
              ["Distanza", c => `${c.km} km`, c => c.km, "min"],
              ["Esperienza", c => c.exp, c => parseInt(c.exp), "max"],
              ["Recensioni", c => String(c.reviews), c => c.reviews, "max"],
            ].map(([label, disp, num, dir]) => {
              const nums = compareList.map(num);
              const best = dir === "min" ? Math.min(...nums) : Math.max(...nums);
              return (
                <div key={label} style={{ paddingTop: 10, marginTop: 10, borderTop: "1px solid var(--hair)" }}>
                  <div className="mono" style={{ textAlign: "center", marginBottom: 8, color: "var(--t-4)" }}>{label}</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    {compareList.map((c, j) => {
                      const isBest = num(c) === best && nums[0] !== nums[1];
                      return (
                        <div key={c.id} style={{ textAlign: "center" }}>
                          <span style={{
                            fontSize: 14, fontWeight: 700,
                            color: isBest ? "var(--gold)" : "var(--t-2)",
                          }}>{disp(c)}{isBest && " ✓"}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
            <button onClick={() => { const c = compareList[0]; doAssign(c); }} className="btn-gold" style={{ width: "100%", padding: 13, fontSize: 13.5, marginTop: 16 }}>
              Assegna a {compareList[0].name.split(" ")[0]}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// SCREEN — IL MIO STAFF (organico, contratti, ore · 0% commissione interni)
// ─────────────────────────────────────────────────────────────
const STAFF_TYPE_META = {
  fisso:    { label: "Dipendente fisso", short: "FISSO",      color: "var(--pos)",  tint: "oklch(0.80 0.140 150 / 0.12)", comm: "0% commissione",
              note: "Paghi via busta paga (CCNL Pubblici Esercizi). Aura gestisce turni, presenze ed export ore — non emette cedolini." },
  chiamata: { label: "A chiamata",       short: "A CHIAMATA", color: "var(--warn)", tint: "oklch(0.78 0.140 50 / 0.12)",  comm: "0% commissione",
              note: "Lavoro subordinato intermittente. Serve la comunicazione preventiva all'Ispettorato prima di ogni chiamata — Aura la invia per te." },
  extra:    { label: "Extra · occasionale", short: "EXTRA",   color: "var(--gold)", tint: "oklch(0.81 0.115 82 / 0.14)",  comm: "10% sui turni",
              note: "Prestazione occasionale / P.IVA. Il turno passa dal marketplace con commissione 10%. Attenzione ai limiti di legge sull'occasionale." },
};

const ScreenStaff = ({ onClose, onPubblica }) => {
  const staff = (window.AURA && window.AURA.staff) || [];
  const [filter, setFilter] = React.useState("tutti");
  const [detail, setDetail] = React.useState(null);

  const counts = {
    tutti: staff.length,
    fisso: staff.filter(s => s.type === "fisso").length,
    chiamata: staff.filter(s => s.type === "chiamata").length,
    extra: staff.filter(s => s.type === "extra").length,
  };
  const list = filter === "tutti" ? staff : staff.filter(s => s.type === filter);
  const filters = [
    { id: "tutti", label: "Tutti" },
    { id: "fisso", label: "Fissi" },
    { id: "chiamata", label: "A chiamata" },
    { id: "extra", label: "Extra" },
  ];

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 0 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
          <div>
            <div className="mono">Trattoria da Gino</div>
            <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Il mio staff</div>
          </div>
        </div>
        <button onClick={onPubblica} aria-label="assegna turno" style={{ ...iconBtn, background: "var(--gold)", border: 0 }}>
          <Icon name="plus" size={20} color="#1a1206"/>
        </button>
      </div>

      {/* Key principle */}
      <div className="card" style={{ padding: "14px 16px", marginBottom: 18, display: "flex", gap: 11, background: "linear-gradient(135deg, oklch(0.22 0.018 75) 0%, oklch(0.17 0.012 65) 100%)", borderColor: "oklch(0.81 0.115 82 / 0.30)" }}>
        <Icon name="shield2" size={20} color="var(--gold)" />
        <div style={{ fontSize: 12, color: "var(--t-2)", lineHeight: 1.5 }}>
          Sul personale <span style={{ color: "var(--t-1)" }}>interno</span> (fissi e a chiamata) Aura non applica commissioni: è solo gestione. La commissione scatta solo sugli <span style={{ color: "var(--gold)" }}>extra</span> trovati sul mercato.
        </div>
      </div>

      {/* Filters */}
      <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 18, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20 }}>
        {filters.map(f => (
          <Pill key={f.id} small active={filter === f.id} gold={filter === f.id} onClick={() => setFilter(f.id)}>
            {f.label} · {counts[f.id]}
          </Pill>
        ))}
      </div>

      {/* Roster */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {list.map(s => {
          const m = STAFF_TYPE_META[s.type];
          return (
            <button key={s.init} onClick={() => setDetail(s)} className="card tap" style={{ padding: 14, width: "100%", textAlign: "left", color: "var(--t-1)", display: "block" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <Avatar initials={s.init} size={44} tone={s.tone} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14.5, fontWeight: 600 }}>{s.name}</div>
                  <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{s.role} · {s.contract}</div>
                </div>
                <Icon name="chevR" size={16} color="var(--t-4)" />
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--hair)" }}>
                <span className="mono" style={{ fontSize: 8.5, padding: "3px 8px", borderRadius: 999, background: m.tint, color: m.color }}>{m.short}</span>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <span style={{ fontSize: 11.5, color: "var(--t-3)" }}>{s.hours} / mese</span>
                  <span style={{ fontSize: 11.5, color: s.type === "extra" ? "var(--gold)" : "var(--pos)", fontWeight: 600 }}>{m.comm}</span>
                </div>
              </div>
              {s.warn &&
              <div style={{ display: "flex", gap: 8, marginTop: 10, padding: "9px 11px", borderRadius: 11, background: "oklch(0.78 0.140 50 / 0.08)", border: "1px solid oklch(0.78 0.140 50 / 0.30)" }}>
                <Icon name="alert" size={15} color="var(--warn)" />
                <span style={{ fontSize: 11, color: "var(--t-2)", lineHeight: 1.45 }}>
                  Lavora spesso con te ({s.shiftsMonth} turni questo mese). Valuta un <span style={{ color: "var(--t-1)" }}>contratto a chiamata</span> per evitare rischi di riqualificazione.
                </span>
              </div>
              }
            </button>
          );
        })}
      </div>

      {/* Export */}
      <button onClick={() => showToast("Ore e presenze esportate (PDF) per il commercialista", "doc")} className="card tap" style={{
        display: "flex", alignItems: "center", gap: 13, padding: 16, marginTop: 16, width: "100%", textAlign: "left", color: "var(--t-1)", cursor: "pointer"
      }}>
        <div style={{ width: 42, height: 42, borderRadius: 12, flexShrink: 0, background: "rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon name="upload" size={20} color="var(--t-2)" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Esporta ore per il commercialista</div>
          <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>Riepilogo presenze del mese · PDF / CSV</div>
        </div>
        <Icon name="chevR" size={16} color="var(--t-4)" />
      </button>

      {/* Detail sheet */}
      {detail &&
      <div onClick={() => setDetail(null)} style={{
        position: "absolute", inset: 0, zIndex: 200, background: "rgba(8,6,4,0.65)",
        backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)", display: "flex", alignItems: "flex-end"
      }}>
        <div onClick={e => e.stopPropagation()} className="modal-enter scroll" style={{
          width: "100%", background: "var(--bg-1)", borderTopLeftRadius: 28, borderTopRightRadius: 28,
          padding: "12px 22px 32px", borderTop: "1px solid var(--hair-2)", maxHeight: "86%", overflowY: "auto"
        }}>
          <div style={{ width: 38, height: 4, background: "var(--hair-2)", borderRadius: 99, margin: "0 auto 18px" }} />
          {(() => {
            const m = STAFF_TYPE_META[detail.type];
            return (
              <>
                <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
                  <Avatar initials={detail.init} size={56} ring tone={detail.tone} />
                  <div style={{ flex: 1 }}>
                    <div className="serif" style={{ fontSize: 21 }}>{detail.name}</div>
                    <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 2 }}>{detail.role}</div>
                  </div>
                  <span className="mono" style={{ fontSize: 8.5, padding: "4px 9px", borderRadius: 999, background: m.tint, color: m.color }}>{m.short}</span>
                </div>

                <div className="card-2" style={{ padding: "6px 16px", marginBottom: 14 }}>
                  <Row label="Tipo di rapporto" value={m.label} />
                  <Row label="Contratto" value={detail.contract} />
                  <Row label="Ore questo mese" value={detail.hours} />
                  <Row label="Ultimo turno" value={detail.lastShift} />
                  <Row label="Valutazione" value={`★ ${detail.rating}`} />
                  <Row label="Commissione Aura" value={m.comm} gold={detail.type !== "extra"} last />
                </div>

                <div className="card-2" style={{ padding: "13px 15px", marginBottom: 16, display: "flex", gap: 10 }}>
                  <Icon name={detail.type === "extra" ? "euro" : "shield2"} size={18} color={detail.type === "extra" ? "var(--gold)" : "var(--pos)"} />
                  <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.55 }}>{m.note}</div>
                </div>

                {detail.warn &&
                <div className="card-2" style={{ padding: "13px 15px", marginBottom: 16, display: "flex", gap: 10, background: "oklch(0.78 0.140 50 / 0.08)", borderColor: "oklch(0.78 0.140 50 / 0.30)" }}>
                  <Icon name="alert" size={18} color="var(--warn)" />
                  <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.55 }}>
                    {detail.shiftsMonth} turni questo mese: ricorre come un dipendente. Valuta di <span style={{ color: "var(--t-1)" }}>contrattualizzarlo</span> (a chiamata o determinato) per evitare la riqualificazione del rapporto.
                  </div>
                </div>
                }

                <div style={{ display: "flex", gap: 8 }}>
                  {detail.type !== "extra" ? (
                    <button onClick={() => { showToast("Ore esportate per il commercialista", "doc"); setDetail(null); }} className="btn-ghost" style={{ flex: 1, padding: 13 }}>Esporta ore</button>
                  ) : (
                    <button onClick={() => { showToast("Avvio pratica contratto a chiamata", "doc"); setDetail(null); }} className="btn-ghost" style={{ flex: 1, padding: 13 }}>Contrattualizza</button>
                  )}
                  <button onClick={() => { setDetail(null); onPubblica && onPubblica(); }} className="btn-gold" style={{ flex: 1, padding: 13 }}>Assegna turno</button>
                </div>
              </>
            );
          })()}
        </div>
      </div>
      }
    </div>
  );
};

Object.assign(window, { ScreenPubblicaTurno, ScreenAnnunci, ScreenCandidature, ScreenStaff });
