// Aura — single source of truth for the demo's canonical figures.
// Keeps money/profile numbers coherent across Dashboard, Wallet, Profilo, Notifiche.
window.AURA = {
  user: {
    name: "Marco Rossi", first: "Marco", initials: "MR",
    role: "Chef de Rang", city: "Milano",
    rating: "4,8", reviews: 142, badges: 6, badgesTotal: 12,
    skills: ["VELOCE", "CORTESE", "VINO", "MULTI", "GENTILE", "EVENTI"], // badge che Marco possiede → usati per il match
  },
  // Turni aperti sul mercato (lato cameriere: sfoglia e candidati).
  // Il primo è LO STESSO annuncio che il ristoratore pubblica → i due lati si chiudono.
  openShifts: [
    { id: "s1", venue: "Trattoria da Gino", init: "TG", tone: 0, role: "Cameriere",    day: "Sab 15 nov", date: "15", time: "19:00–00:30", pay: "165", km: "1,2", badges: ["VELOCE", "CORTESE"], urgent: true },
    { id: "s2", venue: "Hotel Manin · Eventi", init: "HM", tone: 5, role: "Maître Brunch", day: "Dom 16 nov", date: "16", time: "12:00–16:00", pay: "120", km: "2,4", badges: ["GENTILE", "EVENTI"], event: "Brunch privato" },
    { id: "s3", venue: "Osteria Bartolomeo", init: "OB", tone: 2, role: "Chef de Rang", day: "Ven 21 nov", date: "21", time: "20:00–01:00", pay: "190", km: "3,1", badges: ["VINO", "MULTI"] },
    { id: "s4", venue: "Enoteca Cortili", init: "EC", tone: 4, role: "Sommelier",     day: "Gio 20 nov", date: "20", time: "18:30–23:30", pay: "210", km: "4,6", badges: ["VINO", "EVENTI"], event: "Degustazione" },
    { id: "s5", venue: "Bistrot Verde", init: "BV", tone: 1, role: "Runner",         day: "Mer 19 nov", date: "19", time: "12:00–15:30", pay: "85",  km: "0,9", badges: ["VELOCE"] },
    { id: "s6", venue: "Rooftop Duomo", init: "RD", tone: 3, role: "Cameriere",      day: "Sab 22 nov", date: "22", time: "18:00–02:00", pay: "240", km: "1,8", badges: ["VELOCE", "COCKTAIL", "EVENTI"], event: "Serata DJ" },
  ],
  // Candidature del cameriere (Le mie candidature): pending | accepted | rejected
  applications: [
    { id: "a1", venue: "Hotel Manin · Eventi", init: "HM", tone: 5, role: "Maître Brunch", day: "Dom 16 nov", time: "12:00–16:00", pay: "120", status: "accepted", when: "Accettata 1 ora fa" },
    { id: "a2", venue: "Bistrot Verde",       init: "BV", tone: 1, role: "Runner",        day: "Mer 19 nov", time: "12:00–15:30", pay: "85",  status: "pending",  when: "Inviata 2 ore fa" },
    { id: "a3", venue: "Caffè Centrale",      init: "CC", tone: 2, role: "Cameriere",     day: "Lun 10 nov", time: "07:00–12:00", pay: "95",  status: "rejected", when: "Non selezionato" },
  ],
  // Earnings (cumulative this month)
  earnings: { month: "2.450", goal: "3.000", goalPct: 82, remaining: "550", deltaPct: 18 },
  // Wallet = current balance + the one shift awaiting payout
  wallet: {
    available: "850,00", availableShort: "850",
    pending: "185",                // matches the dashboard "saldo turno" in arrivo
    pendingVenue: "Trattoria da Gino",
    iban: "•••• 7421",
  },
  // Venue (manager side)
  venue: { name: "Trattoria da Gino", manager: "Sara", rating: "4,7", reviewsNov: 284 },
  // Organico del locale — il tipo di rapporto decide se scatta la commissione.
  // type: "fisso" (dipendente) | "chiamata" (intermittente) | "extra" (occasionale/freelance)
  staff: [
    { init: "MR", name: "Marco Rossi",    role: "Chef de Rang", tone: 0, type: "fisso",    contract: "Indeterminato",            hours: "148h", lastShift: "Ieri", rating: "4,8" },
    { init: "EC", name: "Elisa Conte",    role: "Sommelier",    tone: 4, type: "fisso",    contract: "Indeterminato",            hours: "132h", lastShift: "Oggi", rating: "4,9" },
    { init: "LT", name: "Luca Trapani",   role: "Cameriere",    tone: 2, type: "fisso",    contract: "Determinato · scad. 31/03", hours: "120h", lastShift: "Ieri", rating: "4,6" },
    { init: "GR", name: "Giulia Romano",  role: "Hostess",      tone: 5, type: "fisso",    contract: "Indeterminato",            hours: "96h",  lastShift: "Lun",  rating: "4,9" },
    { init: "FT", name: "Federico Turi",  role: "Runner",       tone: 1, type: "chiamata", contract: "Intermittente",            hours: "38h",  lastShift: "Sab",  rating: "4,5" },
    { init: "SB", name: "Sara Bianchi",   role: "Cameriere",    tone: 3, type: "chiamata", contract: "Intermittente",            hours: "24h",  lastShift: "Ven",  rating: "4,7" },
    { init: "AS", name: "Anna Silva",     role: "Cameriere",    tone: 3, type: "extra",    contract: "Occasionale · P.IVA",      hours: "31h",  lastShift: "Mer",  rating: "4,7", shiftsMonth: 6, warn: true },
  ],
};
