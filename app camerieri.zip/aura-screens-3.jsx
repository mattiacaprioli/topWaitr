// Aura — Screens part 3: Wallet, QR Pro, Contestazione, Certificazioni, Manager Dashboard

// ─────────────────────────────────────────────────────────────
// SCREEN — WALLET COMPLETO (Stripe-Connect style)
// ─────────────────────────────────────────────────────────────
const ScreenWallet = ({ onClose }) => {
  const [phase, setPhase] = React.useState("idle"); // idle | confirm | sending | done
  const [amount] = React.useState("850,00");
  const [speed, setSpeed] = React.useState("instant"); // instant | standard
  const [txDetail, setTxDetail] = React.useState(null);

  // Instant payout economics (fintech revenue engine)
  const INSTANT_RATE = 0.015;
  const amtNum = 850;
  const fmtEur = (n) => n.toLocaleString("it-IT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const instantFee = fmtEur(amtNum * INSTANT_RATE);   // 12,75
  const instantNet = fmtEur(amtNum * (1 - INSTANT_RATE)); // 837,25

  const transactions = [
    { type: "in", who: "Trattoria da Gino", note: "Turno Mar 11/11", amt: "+ € 185", t: "Oggi", role: "Chef de Rang", time: "19:00–00:00", gross: "€ 185,00", fee: "€ 0,00", net: "€ 185,00", ref: "TRX-4821", method: "Wallet Aura" },
    { type: "out", who: "Trasferimento bancario", note: "IBAN •••• 7421", amt: "− € 1.200", t: "Lun 10/11", gross: "€ 1.200,00", fee: "€ 0,00", net: "€ 1.200,00", ref: "PAY-7733", method: "SEPA · IBAN •••• 7421" },
    { type: "in", who: "Osteria Bartolomeo", note: "Turno Sab 08/11", amt: "+ € 175", t: "Sab 08/11", role: "Servizio Sala", time: "20:30–01:00", gross: "€ 175,00", fee: "€ 0,00", net: "€ 175,00", ref: "TRX-4790", method: "Wallet Aura" },
    { type: "in", who: "Hotel Manin · Eventi", note: "Brunch privato", amt: "+ € 120", t: "Ven 07/11", role: "Maître Brunch", time: "12:00–16:00", gross: "€ 120,00", fee: "€ 0,00", net: "€ 120,00", ref: "TRX-4755", method: "Wallet Aura" },
  ];

  React.useEffect(() => {
    if (phase === "sending") {
      const t = setTimeout(() => setPhase("done"), 1800);
      return () => clearTimeout(t);
    }
  }, [phase]);

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 22px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div>
          <div className="mono">Pagamenti · Stripe</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Wallet</div>
        </div>
      </div>

      {/* Hero balance */}
      <div className="card" style={{
        padding: "22px 22px 20px", marginBottom: 14, position: "relative", overflow: "hidden"
      }}>
        <div style={{
          position: "absolute", inset: 0, pointerEvents: "none",
          background: "radial-gradient(ellipse at 90% -10%, var(--gold-glow), transparent 55%)"
        }} />
        <div style={{ position: "relative" }}>
          <div className="mono" style={{ marginBottom: 8 }}>Disponibile ora · prelievo immediato</div>
          <div className="gold-shimmer numeric" style={{
            fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 54, lineHeight: 0.95, letterSpacing: "-0.035em"
          }}>€&thinsp;{amount}</div>
          <div style={{ display: "flex", gap: 8, marginTop: 14, fontSize: 12.5, color: "var(--t-3)" }}>
            <span>+€ 185 in arrivo 48h</span>
            <span>·</span>
            <span>IBAN IT60 X•••• 7421</span>
          </div>
          <button onClick={() => setPhase("confirm")} className="btn-gold"
          style={{ marginTop: 18, width: "100%", padding: 14 }}>
            Preleva sul conto
          </button>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginTop: 12 }}>
            <Icon name="lightning" size={13} color="var(--gold)" strokeWidth={2} />
            <span className="mono" style={{ color: "var(--gold)" }}>Prelievo istantaneo disponibile</span>
          </div>
        </div>
      </div>

      {/* Account status */}
      <div className="card" style={{ padding: 14, marginBottom: 14, display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{
          width: 38, height: 38, borderRadius: 10,
          background: "oklch(0.80 0.140 150 / 0.10)", border: "1px solid oklch(0.80 0.140 150 / 0.40)",
          display: "flex", alignItems: "center", justifyContent: "center"
        }}>
          <Icon name="shield2" size={18} color="var(--pos)" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13.5, fontWeight: 600 }}>Conto Stripe attivo</div>
          <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>Pagamenti gestiti da Stripe Italia · KYC completato</div>
        </div>
        <span className="mono text-pos">VERIFIED</span>
      </div>

      {/* Recent transactions */}
      <div className="mono" style={{ marginBottom: 10 }}>Movimenti recenti</div>
      <div className="card" style={{ overflow: "hidden" }}>
        {transactions.
        map((r, i, arr) =>
        <div key={i} onClick={() => setTxDetail(r)} className="tap" style={{
          display: "flex", alignItems: "center", gap: 12, padding: "13px 16px",
          borderBottom: i === arr.length - 1 ? "none" : "1px solid var(--hair)"
        }}>
            <div style={{
            width: 30, height: 30, borderRadius: 999,
            background: r.type === "in" ? "oklch(0.80 0.140 150 / 0.12)" : "rgba(255,255,255,0.05)",
            display: "flex", alignItems: "center", justifyContent: "center"
          }}>
              <Icon name="arrowUp" size={13}
            color={r.type === "in" ? "var(--pos)" : "var(--t-3)"}
            strokeWidth={2.2}
            style={{ transform: r.type === "in" ? "rotate(180deg)" : "none" }} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13.5, fontWeight: 500 }}>{r.who}</div>
              <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{r.note} · {r.t}</div>
            </div>
            <div className="numeric" style={{
            fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 14,
            color: r.type === "in" ? "var(--pos)" : "var(--t-1)"
          }}>{r.amt}</div>
            <Icon name="chevR" size={15} color="var(--t-4)" style={{ marginLeft: 2 }}/>
          </div>
        )}
      </div>

      <div className="mono" style={{ textAlign: "center", marginTop: 20, color: "var(--t-4)" }}>
        Powered by Stripe · Aura non gestisce direttamente i tuoi soldi
      </div>

      {/* Transfer flow overlay */}
      {phase !== "idle" &&
      <div onClick={() => phase !== "sending" && setPhase("idle")} style={{
        position: "absolute", inset: 0, zIndex: 300,
        background: "rgba(8,6,4,0.7)", backdropFilter: "blur(10px)", WebkitBackdropFilter: "blur(10px)",
        display: "flex", alignItems: "flex-end"
      }}>
          <div onClick={(e) => e.stopPropagation()} className="modal-enter" style={{
          width: "100%", background: "var(--bg-1)", borderTopLeftRadius: 28, borderTopRightRadius: 28,
          padding: "12px 22px 32px", borderTop: "1px solid var(--hair-2)"
        }}>
            <div style={{ width: 38, height: 4, background: "var(--hair-2)", borderRadius: 99, margin: "0 auto 22px" }} />
            {phase === "confirm" &&
          <div>
                <div className="serif" style={{ fontSize: 22, marginBottom: 6, textAlign: "center" }}>Scegli la velocità</div>
                <div style={{ fontSize: 13, color: "var(--t-3)", textAlign: "center", marginBottom: 20 }}>
                  € {amount} verso IBAN •••• 7421
                </div>

                {/* Speed selector — instant (paid) vs standard (free) */}
                <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 16 }}>
                  {[
                    { id: "instant", icon: "lightning", title: "Istantaneo", sub: "Sul conto in pochi minuti · 24/7", fee: `€ ${instantFee}` },
                    { id: "standard", icon: "clock", title: "Standard", sub: "Accredito in 1–2 giorni lavorativi", fee: "Gratis" },
                  ].map((o) => {
                    const sel = speed === o.id;
                    return (
                      <button key={o.id} onClick={() => setSpeed(o.id)} style={{
                        display: "flex", alignItems: "center", gap: 13, textAlign: "left", width: "100%",
                        padding: "13px 14px", borderRadius: 16, cursor: "pointer",
                        background: sel ? "oklch(0.81 0.115 82 / 0.08)" : "var(--bg-2)",
                        border: `1.5px solid ${sel ? "var(--gold)" : "var(--hair)"}`,
                        transition: "all .14s ease"
                      }}>
                        <div style={{
                          width: 40, height: 40, borderRadius: 11, flexShrink: 0,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          background: sel ? "var(--gold)" : "rgba(255,255,255,0.05)"
                        }}>
                          <Icon name={o.icon} size={20} color={sel ? "#1a1206" : "var(--t-2)"} strokeWidth={2} />
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 14.5, fontWeight: 600, color: "var(--t-1)" }}>{o.title}</div>
                          <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{o.sub}</div>
                        </div>
                        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
                          <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 13.5, color: o.fee === "Gratis" ? "var(--pos)" : "var(--t-1)" }}>{o.fee}</span>
                          <span style={{ width: 18, height: 18, borderRadius: 999, border: `1.5px solid ${sel ? "var(--gold)" : "var(--hair-2)"}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                            {sel && <span style={{ width: 9, height: 9, borderRadius: 999, background: "var(--gold)" }} />}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="card-2" style={{ padding: 16, marginBottom: 18 }}>
                  <Row label="Importo" value={`€ ${amount}`} />
                  <Row label="Commissione" value={speed === "instant" ? `€ ${instantFee} · 1,5%` : "Gratuita"} gold={speed === "standard"} />
                  <Row label="Riceverai" value={speed === "instant" ? `€ ${instantNet}` : `€ ${amount}`} />
                  <Row label="Arrivo previsto" value={speed === "instant" ? "Tra pochi minuti" : "Mer 12/11 entro 18:00"} last />
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => setPhase("idle")} className="btn-ghost" style={{ flex: 1, padding: 14 }}>Annulla</button>
                  <button onClick={() => setPhase("sending")} className="btn-gold" style={{ flex: 1.4, padding: 14 }}>{speed === "instant" ? "Preleva ora" : "Conferma"}</button>
                </div>
              </div>
          }
            {phase === "sending" &&
          <div style={{ textAlign: "center", padding: "30px 0 20px" }}>
                <div className="spin" style={{
              width: 64, height: 64, borderRadius: 99, margin: "0 auto 22px",
              border: "4px solid rgba(255,200,90,0.18)", borderTopColor: "var(--gold)"
            }} />
                <div className="serif" style={{ fontSize: 20, marginBottom: 6 }}>Trasferimento in corso…</div>
                <div style={{ fontSize: 13, color: "var(--t-3)" }}>Stripe sta elaborando il pagamento</div>
              </div>
          }
            {phase === "done" &&
          <div style={{ textAlign: "center", padding: "20px 0 4px" }}>
                <div style={{
              width: 80, height: 80, borderRadius: 99, margin: "0 auto 22px",
              background: "linear-gradient(180deg, oklch(0.82 0.150 150), oklch(0.62 0.150 150))",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 0 0 8px oklch(0.80 0.140 150 / 0.18)"
            }}>
                  <Icon name="check" size={42} color="#06210e" strokeWidth={2.5} />
                </div>
                <div className="mono text-pos" style={{ marginBottom: 8 }}>Prelievo riuscito</div>
                <div className="serif" style={{ fontSize: 22, marginBottom: 6, letterSpacing: "-0.01em" }}>
                  {speed === "instant" ? `€ ${instantNet} sul tuo conto` : `€ ${amount} in viaggio`}
                </div>
                <div style={{ fontSize: 12.5, color: "var(--t-3)", marginBottom: 24 }}>
                  {speed === "instant" ? "Accreditato in pochi minuti · IBAN •••• 7421" : "Accredito in 1–2 giorni · IBAN •••• 7421"}
                </div>
                <button onClick={() => setPhase("idle")} className="btn-ghost" style={{ width: "100%", padding: 14 }}>Chiudi</button>
              </div>
          }
          </div>
        </div>
      }

      {/* Transaction detail — receipt */}
      {txDetail &&
      <div onClick={() => setTxDetail(null)} style={{
        position: "absolute", inset: 0, zIndex: 320,
        background: "rgba(8,6,4,0.7)", backdropFilter: "blur(10px)", WebkitBackdropFilter: "blur(10px)",
        display: "flex", alignItems: "flex-end"
      }}>
          <div onClick={(e) => e.stopPropagation()} className="modal-enter" style={{
          width: "100%", background: "var(--bg-1)", borderTopLeftRadius: 28, borderTopRightRadius: 28,
          padding: "12px 22px 32px", borderTop: "1px solid var(--hair-2)"
        }}>
            <div style={{ width: 38, height: 4, background: "var(--hair-2)", borderRadius: 99, margin: "0 auto 18px" }} />
            <div style={{ textAlign: "center", marginBottom: 18 }}>
              <div style={{
                width: 56, height: 56, borderRadius: 999, margin: "0 auto 14px",
                background: txDetail.type === "in" ? "oklch(0.80 0.140 150 / 0.12)" : "rgba(255,255,255,0.05)",
                border: `1px solid ${txDetail.type === "in" ? "oklch(0.80 0.140 150 / 0.4)" : "var(--hair-2)"}`,
                display: "flex", alignItems: "center", justifyContent: "center"
              }}>
                <Icon name={txDetail.type === "in" ? "euro" : "wallet"} size={26} color={txDetail.type === "in" ? "var(--pos)" : "var(--t-2)"}/>
              </div>
              <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 32, letterSpacing: "-0.02em", color: txDetail.type === "in" ? "var(--pos)" : "var(--t-1)" }}>{txDetail.amt}</div>
              <div style={{ fontSize: 13.5, color: "var(--t-2)", marginTop: 4 }}>{txDetail.who}</div>
              <div className="mono" style={{ marginTop: 6 }}>{txDetail.t}</div>
            </div>

            <div className="card-2" style={{ padding: 16, marginBottom: 14 }}>
              {txDetail.type === "in" ? (
                <>
                  <Row label="Tipo" value={txDetail.role} />
                  <Row label="Orario turno" value={txDetail.time} />
                  <Row label="Lordo" value={txDetail.gross} />
                  <Row label="Commissione Aura" value="€ 0 · ricevi il 100%" gold />
                  <Row label="Netto accreditato" value={txDetail.net} last />
                </>
              ) : (
                <>
                  <Row label="Destinazione" value={txDetail.method} />
                  <Row label="Importo" value={txDetail.gross} />
                  <Row label="Commissione" value={txDetail.fee} />
                  <Row label="Stato" value="Completato" gold last />
                </>
              )}
            </div>

            <div className="card-2" style={{ padding: 16, marginBottom: 16 }}>
              <Row label="Riferimento" value={txDetail.ref} />
              <Row label="Metodo" value={txDetail.method} last />
            </div>

            <button onClick={() => showToast("Ricevuta scaricata (PDF)", "doc")} className="btn-gold" style={{ width: "100%", padding: 14, marginBottom: 10 }}>
              Scarica ricevuta
            </button>
            <button onClick={() => setTxDetail(null)} className="btn-ghost" style={{ width: "100%", padding: 13 }}>Chiudi</button>
          </div>
        </div>
      }
    </div>);

};

// ─────────────────────────────────────────────────────────────
// SCREEN — IL TUO QR PROFESSIONALE
// ─────────────────────────────────────────────────────────────
const ScreenQRPro = ({ onClose }) =>
<div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)", display: "flex", flexDirection: "column", height: "100%" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 0 18px" }}>
      <button onClick={onClose} style={iconBtn}><Icon name="close" size={18} color="var(--t-2)" /></button>
      <div className="mono">Il tuo QR</div>
      <button onClick={() => showToast("Link al QR copiato", "check")} style={iconBtn}><Icon name="send" size={18} color="var(--t-2)" /></button>
    </div>

    <div style={{ textAlign: "center", marginBottom: 20 }}>
      <div className="mono" style={{ marginBottom: 6, color: "var(--gold)" }}>RECENSIONE CERTIFICATA</div>
      <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.01em" }}>Mostra questo<br />al tuo cliente</div>
    </div>

    {/* QR card */}
    <div style={{
    margin: "0 auto", width: 280, padding: 24,
    background: "#f6f1e3", borderRadius: 28,
    boxShadow: "0 30px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,200,90,0.25), 0 0 40px var(--gold-glow)",
    position: "relative"
  }}>
      <QRCodeArt />
      <div style={{
      position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)",
      width: 56, height: 56, borderRadius: 14,
      background: "#1a1611", border: "3px solid #f6f1e3",
      display: "flex", alignItems: "center", justifyContent: "center", padding: "0px", margin: "0px"
    }}>
        <Icon name="logo" size={30} color="var(--gold)" />
      </div>
      <div style={{ textAlign: "center", marginTop: 18, paddingTop: 16, borderTop: "1px dashed rgba(26,18,6,0.18)" }}>
        <div className="serif" style={{ fontSize: 18, color: "#1a1611", letterSpacing: "-0.01em" }}>Marco Rossi</div>
        <div className="mono" style={{ color: "#5b4a2e", marginTop: 4 }}>CHEF DE RANG · MILANO</div>
      </div>
    </div>

    <div style={{
    marginTop: 24, fontSize: 13, color: "var(--t-2)", textAlign: "center", lineHeight: 1.55, maxWidth: 320, alignSelf: "center"
  }}>
      Mostra questo al cliente a fine servizio<br />per ricevere una <span style={{ color: "var(--gold)", fontWeight: 600 }}>recensione certificata</span> sul tuo profilo.
    </div>

    <div style={{ display: "flex", gap: 8, marginTop: 24 }}>
      <button onClick={() => showToast("QR salvato nella galleria", "check")} className="btn-ghost" style={{ flex: 1, fontSize: 13, padding: "0px 0px 0px 2px" }}>
        <Icon name="upload" size={14} color="var(--t-1)" style={{ marginRight: 6, verticalAlign: "-2px" }} />
        Salva
      </button>
      <button onClick={() => showToast("Link condiviso", "send")} className="btn-gold" style={{ flex: 1.3, padding: 13, fontSize: 13 }}>
        <Icon name="send" size={14} color="#1a1206" style={{ marginRight: 6, verticalAlign: "-2px" }} />
        Condividi link
      </button>
    </div>

    <div className="mono" style={{ textAlign: "center", marginTop: 18, color: "var(--t-4)" }}>
      Codice unico · aura.app/r/MR4821
    </div>
  </div>;


// Decorative QR art (not a real QR — visually convincing pattern)
const QRCodeArt = () => {
  const cells = [];
  const seed = "AURA-MARCO-ROSSI-4821-CHEF-DE-RANG";
  // Deterministic pseudo-random pattern from seed
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = h * 31 + seed.charCodeAt(i) | 0;
  const rng = () => {h = h * 1664525 + 1013904223 | 0;return (h >>> 0) / 0xffffffff;};
  const N = 23;
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      // finder patterns at 3 corners
      const inFinder =
      x < 7 && y < 7 ||
      x >= N - 7 && y < 7 ||
      x < 7 && y >= N - 7;
      // center mask reserved for logo
      const inCenter = x >= 9 && x < 14 && y >= 9 && y < 14;
      if (inCenter) continue;
      if (inFinder) {
        const lx = x < 7 ? x : x - (N - 7);
        const ly = y < 7 ? y : y - (N - 7);
        const isOuter = lx === 0 || lx === 6 || ly === 0 || ly === 6;
        const isInner = lx >= 2 && lx <= 4 && ly >= 2 && ly <= 4;
        if (isOuter || isInner) cells.push([x, y]);
      } else if (rng() > 0.52) {
        cells.push([x, y]);
      }
    }
  }
  const cs = 10;
  return (
    <svg viewBox={`0 0 ${N * cs} ${N * cs}`} width="100%" preserveAspectRatio="xMidYMid meet">
      {cells.map(([x, y], i) =>
      <rect key={i} x={x * cs + 0.5} y={y * cs + 0.5} width={cs - 1} height={cs - 1}
      rx={1.6} fill="#1a1611" />
      )}
    </svg>);

};

// ─────────────────────────────────────────────────────────────
// SCREEN — CENTRO RISOLUZIONI (contestazione recensione)
// ─────────────────────────────────────────────────────────────
const ScreenContestazione = ({ review, onClose, onSubmit }) => {
  const [reason, setReason] = React.useState("");
  const [reasonType, setReasonType] = React.useState("INGIUSTA");
  const [docs, setDocs] = React.useState({ scontrino: "empty", presenza: "empty", altro: "empty" });
  const [submitted, setSubmitted] = React.useState(false);

  const mockUpload = (key) => {
    setDocs((d) => ({ ...d, [key]: "uploading" }));
    setTimeout(() => setDocs((d) => ({ ...d, [key]: "uploaded" })), 1100);
  };

  if (submitted) {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px", color: "var(--t-1)", height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center" }}>
        <div style={{
          width: 96, height: 96, borderRadius: 999,
          background: "oklch(0.78 0.140 50 / 0.12)", border: "1px solid var(--warn)",
          display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 24
        }}>
          <Icon name="shield2" size={42} color="var(--warn)" />
        </div>
        <div className="mono text-warn" style={{ marginBottom: 10 }}>SEGNALAZIONE RICEVUTA</div>
        <div className="serif" style={{ fontSize: 24, letterSpacing: "-0.01em", marginBottom: 12, maxWidth: 290 }}>
          Il team Aura sta esaminando<br />la tua contestazione.
        </div>
        <div style={{ fontSize: 13, color: "var(--t-3)", maxWidth: 290, lineHeight: 1.55, marginBottom: 32 }}>
          Tempo medio di risposta: <span style={{ color: "var(--t-1)" }}>24-48h</span>. Ti notificheremo via messaggio. La recensione resta visibile ma marcata come <em>in contestazione</em>.
        </div>
        <button onClick={onClose} className="btn-ghost" style={{ padding: "13px 28px" }}>Torna al profilo</button>
      </div>);

  }

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 22px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div>
          <div className="mono text-warn">GDPR · DIFESA PROFESSIONALE</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Centro Risoluzioni</div>
        </div>
      </div>

      {/* Review being contested */}
      <div className="card" style={{ padding: 16, marginBottom: 18, borderColor: "oklch(0.78 0.140 50 / 0.35)" }}>
        <div className="mono text-warn" style={{ marginBottom: 8 }}>RECENSIONE OGGETTO DI CONTESTAZIONE</div>
        <div style={{ display: "flex", gap: 4, marginBottom: 8 }}>
          {Array.from({ length: 5 }).map((_, j) =>
          <Icon key={j} name="star" size={12} color={j < (review?.stars || 2) ? "var(--gold)" : "var(--t-4)"} />
          )}
          <span className="mono" style={{ marginLeft: 6 }}>{review?.who || "Anonimo"} · {review?.when || "08/11"}</span>
        </div>
        <div className="serif" style={{ fontSize: 14, lineHeight: 1.4, color: "var(--t-2)" }}>
          “{review?.txt || "Servizio pessimo, il cameriere era assente e sgarbato. Non torno più."}”
        </div>
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Motivo della contestazione</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 22 }}>
        {[
        ["INGIUSTA", "Recensione ingiusta"],
        ["DIFFAMATORIA", "Diffamatoria"],
        ["FALSA", "Cliente mai servito"],
        ["IDENTITA", "Errore di identità"]].
        map(([id, lbl]) =>
        <Pill key={id} small active={reasonType === id} gold={reasonType === id} onClick={() => setReasonType(id)}>{lbl}</Pill>
        )}
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Allega prove · facoltative ma raccomandate</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 22 }}>
        <UploadSlot
          label="Foto dello scontrino"
          hint="Dimostra che non eri tu a servire questo tavolo"
          status={docs.scontrino}
          filename="scontrino_2024-11-08.jpg"
          onClick={() => mockUpload("scontrino")} />
        <UploadSlot
          label="Prova di presenza / turno"
          hint="Foglio turni firmato o badge timbrato"
          status={docs.presenza}
          filename="turni_settimana_45.pdf"
          onClick={() => mockUpload("presenza")} />
        <UploadSlot
          label="Altri documenti"
          hint="Testimonianze, screenshot, altro"
          status={docs.altro}
          filename="testimonianza_collega.pdf"
          onClick={() => mockUpload("altro")} />
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Spiega cosa è successo</div>
      <textarea value={reason} onChange={(e) => setReason(e.target.value)}
      placeholder="Descrivi i fatti in modo oggettivo. Useremo questo testo solo internamente per la verifica."
      rows={4}
      style={{
        width: "100%", background: "var(--bg-1)", border: "1px solid var(--hair)",
        borderRadius: 14, padding: 14, color: "var(--t-1)", fontSize: 13.5,
        fontFamily: "var(--f-ui)", outline: "none", resize: "vertical",
        boxSizing: "border-box", marginBottom: 14
      }} />

      <div className="card" style={{ padding: 14, marginBottom: 16, display: "flex", alignItems: "flex-start", gap: 12 }}>
        <Icon name="shield2" size={18} color="var(--gold)" style={{ marginTop: 2 }} />
        <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.5 }}>
          La tua richiesta è tutelata <strong style={{ color: "var(--t-1)" }}>GDPR Art. 17</strong>. Aura agisce come intermediario neutro: non condividiamo le tue prove con il ristoratore senza il tuo consenso esplicito.
        </div>
      </div>

      <button onClick={() => setSubmitted(true)} className="btn-gold" style={{ width: "100%", padding: 16, fontSize: 15 }}>
        Invia contestazione
      </button>
    </div>);

};

// ─────────────────────────────────────────────────────────────
// SCREEN — CERTIFICAZIONI UFFICIALI (upload onboarding badge)
// ─────────────────────────────────────────────────────────────
const ScreenCertificazioni = ({ onClose }) => {
  const [docs, setDocs] = React.useState({
    ais: "uploaded",
    haccp: "verified",
    antincendio: "verified",
    diploma: "empty",
    inglese: "empty",
    cocktail: "empty"
  });

  const mockUpload = (key) => {
    setDocs((d) => ({ ...d, [key]: "uploading" }));
    setTimeout(() => setDocs((d) => ({ ...d, [key]: "uploaded" })), 1200);
  };

  const certs = [
  { key: "ais", title: "Attestato AIS Sommelier", grants: "VINO", filename: "attestato_AIS_2023.pdf" },
  { key: "haccp", title: "Certificato HACCP", grants: "SICUREZZA", filename: "haccp_2024.pdf" },
  { key: "antincendio", title: "Antincendio · Basso rischio", grants: "—", filename: "antincendio.pdf" },
  { key: "diploma", title: "Diploma Alberghiero", grants: "ISTRUITO", filename: "diploma.pdf" },
  { key: "inglese", title: "Inglese · B2 Cambridge", grants: "MULTI", filename: "cambridge_b2.pdf" },
  { key: "cocktail", title: "Corso Mixology · ABI", grants: "COCKTAIL", filename: "abi_cert.pdf" }];


  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 22px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div>
          <div className="mono">Profilo · Onboarding</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Certificazioni Ufficiali</div>
        </div>
      </div>

      <div className="card" style={{ padding: 16, marginBottom: 22, display: "flex", alignItems: "flex-start", gap: 12 }}>
        <Icon name="spark" size={22} color="var(--gold)" style={{ marginTop: 2 }} />
        <div style={{ fontSize: 12.5, color: "var(--t-2)", lineHeight: 1.55 }}>
          Carica i tuoi attestati per sbloccare badge anche <strong style={{ color: "var(--t-1)" }}>senza recensioni</strong>. Il team Aura verifica manualmente entro 48h.
          <div className="mono" style={{ marginTop: 8, color: "var(--gold)" }}>2 VERIFICATI · 1 IN VERIFICA · 3 DA CARICARE</div>
        </div>
      </div>

      <div className="mono" style={{ marginBottom: 12 }}>I tuoi documenti</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {certs.map((c) =>
        <div key={c.key} className="card" style={{ padding: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 3 }}>{c.title}</div>
                <div style={{ fontSize: 11.5, color: "var(--t-3)", display: "flex", alignItems: "center", gap: 5 }}>
                  Sblocca badge: <Pill small active={docs[c.key] !== "empty"}>{c.grants}</Pill>
                </div>
              </div>
              {docs[c.key] === "verified" &&
            <span className="mono text-pos" style={{
              padding: "3px 8px", borderRadius: 999, fontSize: 9,
              background: "oklch(0.80 0.140 150 / 0.10)", border: "1px solid oklch(0.80 0.140 150 / 0.40)"
            }}>VERIFICATO</span>
            }
            </div>
            <UploadSlot
            label={docs[c.key] === "empty" ? "Carica documento" : c.filename}
            status={docs[c.key]}
            filename={c.filename}
            onClick={() => docs[c.key] === "empty" && mockUpload(c.key)} />
          </div>
        )}
      </div>

      <div className="card" style={{ padding: 14, marginTop: 16, background: "linear-gradient(180deg, oklch(0.22 0.018 75) 0%, oklch(0.17 0.012 65) 100%)", borderColor: "var(--gold)" }}>
        <div className="mono" style={{ marginBottom: 6, color: "var(--gold)" }}>SUGGERIMENTO ELITE</div>
        <div style={{ fontSize: 13, color: "var(--t-1)", lineHeight: 1.5 }}>
          Con 5+ certificazioni verificate puoi accedere al piano <strong>Elite</strong> anche con meno di 20 recensioni.
        </div>
      </div>
    </div>);

};

// ─────────────────────────────────────────────────────────────
// SCREEN — MANAGER DASHBOARD
// ─────────────────────────────────────────────────────────────
const ScreenManagerDashboard = ({ onSwitchRole, onOpenSettings, onOpenCallExtra, onOpenTalent, onOpenNotifiche, onSeeAll, onPubblica, onOpenAnnunci, onOpenTurnario, onOpenCollaborazioni, onOpenStaff, fresh, onPopulate }) => {
  const MgrTopBar = (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "4px 0 18px" }}>
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
          <RoleChip role="manager" onSwitch={onSwitchRole} />
        </div>
        <div className="serif" style={{ fontSize: 22, color: "var(--t-1)", letterSpacing: "-0.01em", fontFamily: "Inter" }}>
          Ciao, Sara
        </div>
        <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 2 }}>Trattoria da Gino · Manager di sala</div>
      </div>
      <div style={{ display: "flex", gap: 10 }}>
        <button onClick={onOpenNotifiche} style={iconBtn}>
          <Icon name="bell" size={20} color="var(--t-2)" />
          {!fresh && <span style={{
            position: "absolute", top: 8, right: 8, width: 6, height: 6, borderRadius: 999,
            background: "var(--warn)", boxShadow: "0 0 6px var(--warn)"
          }} />}
        </button>
        <button onClick={onOpenSettings} style={iconBtn}>
          <Icon name="gear" size={20} color="var(--t-2)" />
        </button>
      </div>
    </div>
  );

  if (fresh) {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
        {MgrTopBar}
        <FreshBanner onPopulate={onPopulate} />

        {/* Verification pending */}
        <div className="card" style={{ padding: 16, marginBottom: 14, display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 42, height: 42, borderRadius: 12, flexShrink: 0,
            background: "rgba(255,200,90,0.08)", border: "1px solid oklch(0.81 0.115 82 / 0.3)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Icon name="shield2" size={20} color="var(--gold)"/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>Verifica P.IVA in corso</div>
            <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>Diventa Locale Verificato entro 24h</div>
          </div>
          <span className="mono gold-pulse" style={{ padding: "3px 8px", borderRadius: 999, background: "rgba(255,200,90,0.10)", border: "1px solid var(--gold)", color: "var(--gold)", fontSize: 8.5 }}>PENDING</span>
        </div>

        {/* First steps */}
        <div className="mono" style={{ marginBottom: 10, marginTop: 8 }}>Primi passi</div>
        <div className="card" style={{ overflow: "hidden", marginBottom: 22 }}>
          {[
            { ic: "plus", t: "Pubblica il primo turno", s: "Ricevi candidature dai talenti in zona", act: onPubblica },
            { ic: "search", t: "Esplora il mercato talenti", s: "Sommelier, chef de rang, runner verificati", act: onSeeAll },
            { ic: "users", t: "Invita il tuo staff", s: "Collega chi già lavora con te", act: onPopulate },
          ].map((r, i, arr) => (
            <div key={i} onClick={r.act} className="tap" style={{
              display: "flex", alignItems: "center", gap: 12, padding: "14px 16px",
              borderBottom: i === arr.length - 1 ? "none" : "1px solid var(--hair)",
            }}>
              <div style={{ width: 34, height: 34, borderRadius: 9, background: "rgba(255,200,90,0.08)", border: "1px solid oklch(0.81 0.115 82 / 0.3)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icon name={r.ic} size={17} color="var(--gold)"/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{r.t}</div>
                <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{r.s}</div>
              </div>
              <Icon name="chevR" size={16} color="var(--t-4)"/>
            </div>
          ))}
        </div>

        <EmptyState icon="doc" title="Nessun annuncio attivo"
          body="Pubblica un turno per ricevere candidature dai talenti verificati della tua zona."
          cta="Pubblica turno" onCta={onPubblica} />
      </div>
    );
  }

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      {MgrTopBar}

      {/* HERO — Servizio stasera */}
      <div className="card" style={{ padding: "20px 22px", marginBottom: 14, position: "relative", overflow: "hidden" }}>
        <div style={{
          position: "absolute", inset: 0, pointerEvents: "none",
          background: "radial-gradient(ellipse at 100% -10%, var(--gold-glow), transparent 55%)"
        }} />
        <div style={{ position: "relative" }}>
          <div className="mono" style={{ marginBottom: 12 }}>Servizio stasera · Mer 12 Nov</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <div>
              <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 44, letterSpacing: "-0.03em", lineHeight: 0.95 }}>48</div>
              <div className="mono" style={{ marginTop: 6 }}>Coperti previsti</div>
            </div>
            <div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 4 }}>
                <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 44, letterSpacing: "-0.03em", lineHeight: 0.95, color: "var(--warn)" }}>5</span>
                <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 500, fontSize: 22, color: "var(--t-3)" }}>/6</span>
              </div>
              <div className="mono text-warn" style={{ marginTop: 6 }}>Staff in turno · -1</div>
            </div>
          </div>
        </div>
      </div>

      {/* Primary actions */}
      <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
        <button onClick={onPubblica} className="btn-gold" style={{ flex: 1, padding: "13px 0", fontSize: 13.5, display: "flex", alignItems: "center", justifyContent: "center", gap: 7 }}>
          <Icon name="plus" size={16} color="#1a1206" strokeWidth={2.2}/> Pubblica turno
        </button>
        <button onClick={onOpenAnnunci} className="btn-ghost" style={{ flex: 1, padding: "13px 0", fontSize: 13.5, display: "flex", alignItems: "center", justifyContent: "center", gap: 7, position: "relative" }}>
          <Icon name="doc" size={16} color="var(--t-1)"/> I miei annunci
          <span style={{ position: "absolute", top: 8, right: 14, width: 7, height: 7, borderRadius: 99, background: "var(--gold)" }}/>
        </button>
      </div>

      {/* Il mio staff — organico & contratti (0% commissione) */}
      <button onClick={onOpenStaff} className="card tap" style={{
        display: "flex", alignItems: "center", gap: 13, padding: "14px 16px", marginBottom: 14, width: "100%", textAlign: "left", color: "var(--t-1)", cursor: "pointer"
      }}>
        <div style={{ width: 42, height: 42, borderRadius: 12, flexShrink: 0, background: "rgba(255,255,255,0.05)", border: "1px solid var(--hair)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon name="users" size={20} color="var(--t-1)" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14.5, fontWeight: 600 }}>Il mio staff</div>
          <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>Organico, contratti e ore · <span style={{ color: "var(--pos)" }}>0% commissione</span></div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 15 }}>{((window.AURA && window.AURA.staff) || []).length || 7}</span>
          <Icon name="chevR" size={16} color="var(--t-4)" />
        </div>
      </button>

      {/* CHIAMATA EXTRA — premium feature */}
      <button onClick={onOpenCallExtra} className="card gold-pulse" style={{
        display: "block", textAlign: "left", width: "100%",
        padding: "18px 20px", marginBottom: 22, cursor: "pointer",
        background: "linear-gradient(135deg, oklch(0.24 0.020 75) 0%, oklch(0.18 0.014 65) 100%)",
        borderColor: "var(--gold)", borderWidth: 1.5, color: "var(--t-1)"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 44, height: 44, borderRadius: 12,
            background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))",
            display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0
          }}>
            <Icon name="lightning" size={22} color="#1a1206" strokeWidth={2} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="mono" style={{ marginBottom: 3, color: "var(--gold)" }}>SOS · CHIAMATA EXTRA</div>
            <div style={{ fontSize: 15.5, fontWeight: 600, color: "var(--t-1)" }}>Manca 1 cameriere stasera</div>
            <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 3 }}>12 talenti VELOCE+CORTESE disponibili nel raggio di 10km</div>
          </div>
          <Icon name="chevR" size={18} color="var(--gold)" />
        </div>
      </button>

      {/* Annunci attivi — candidature live */}
      <SectionHeader
        eyebrow="Annunci attivi · 3"
        title="Candidature in arrivo"
        action={<button onClick={onOpenAnnunci} className="btn-ghost" style={{ padding: "8px 14px", fontSize: 12 }}>Tutti</button>} />
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 22 }}>
        {[
          { role: "Cameriere", day: "Sab 15 nov", time: "19:00–00:30", pay: "€ 165", applicants: 7, badges: ["VELOCE", "CORTESE"] },
          { role: "Sommelier", day: "Ven 22 nov", time: "18:00–01:00", pay: "€ 220", applicants: 3, badges: ["VINO", "EVENTI"], event: "Evento privato" },
        ].map((p, i) => (
          <div key={i} onClick={() => onOpenAnnunci()} className="card tap" style={{ padding: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <span style={{ fontSize: 14.5, fontWeight: 600 }}>{p.role}</span>
                  {p.event && <span className="mono" style={{ fontSize: 8, padding: "2px 6px", borderRadius: 4, background: "rgba(255,200,90,0.10)", color: "var(--gold)" }}>{p.event}</span>}
                </div>
                <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{p.day} · {p.time}</div>
              </div>
              <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 15, color: "var(--gold)" }}>{p.pay}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 10, borderTop: "1px solid var(--hair)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                <span className="warn-pulse" style={{ width: 7, height: 7, borderRadius: 99, background: "var(--gold)" }}/>
                <span style={{ fontSize: 13, fontWeight: 500 }}>{p.applicants} candidature</span>
              </div>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12, color: "var(--gold)", fontWeight: 600 }}>
                Gestisci <Icon name="chevR" size={14} color="var(--gold)"/>
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Performance Staff in turno */}
      <SectionHeader eyebrow="Stasera in sala · 5 persone" title="Performance staff" action={<button onClick={onOpenTurnario} className="btn-ghost" style={{ padding: "8px 14px", fontSize: 12 }}>Turnario</button>} />
      <div className="card" style={{ overflow: "hidden", marginBottom: 22 }}>
        {[
        { init: "MR", name: "Marco Rossi", role: "Chef de Rang", rating: 4.8, status: "on-shift", tonight: "Tavoli 1-8", tone: 0 },
        { init: "EC", name: "Elisa Conte", role: "Sommelier", rating: 4.9, status: "on-shift", tonight: "Vini · Cantina", tone: 4 },
        { init: "LT", name: "Luca Trapani", role: "Cameriere", rating: 4.6, status: "on-shift", tonight: "Tavoli 9-16", tone: 2 },
        { init: "GR", name: "Giulia Romano", role: "Hostess", rating: 4.9, status: "late", tonight: "Accoglienza", tone: 5 },
        { init: "FT", name: "Federico Turi", role: "Runner", rating: 4.5, status: "on-shift", tonight: "Servizio", tone: 1 }].
        map((p, i, arr) =>
        <div key={i} onClick={() => onOpenTalent({ id: i, init: p.init, name: p.name, role: p.role, rating: p.rating, badges: ["VELOCE", "CORTESE"], avail: "Stasera", tone: p.tone })}
        className="tap" style={{
          display: "flex", alignItems: "center", gap: 12, padding: "13px 16px",
          borderBottom: i === arr.length - 1 ? "none" : "1px solid var(--hair)"
        }}>
            <Avatar initials={p.init} size={42} tone={p.tone} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>{p.name}</span>
                {p.status === "late" &&
              <span className="mono text-warn" style={{ fontSize: 8.5, padding: "2px 5px", background: "oklch(0.78 0.140 50 / 0.12)", borderRadius: 4 }}>+12 MIN</span>
              }
              </div>
              <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{p.role} · {p.tonight}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 3, justifyContent: "flex-end" }}>
                <Icon name="star" size={12} color="var(--gold)" />
                <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 13 }}>{p.rating}</span>
              </div>
              <div className="mono" style={{ marginTop: 3, color: p.status === "on-shift" ? "var(--pos)" : "var(--warn)" }}>
                {p.status === "on-shift" ? "● IN TURNO" : "● RITARDO"}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Talenti in zona stasera */}
      <SectionHeader
        eyebrow="Mercato Talenti · 12 disponibili"
        title="In zona stasera"
        action={<button onClick={onSeeAll} className="btn-ghost" style={{ padding: "8px 14px", fontSize: 12 }}>Vedi tutti</button>} />
      
      <div className="scroll" style={{
        display: "flex", gap: 10, overflowX: "auto", paddingBottom: 4,
        marginLeft: -20, marginRight: -20, paddingLeft: 20, paddingRight: 20,
        marginBottom: 22
      }}>
        {[
        { init: "AS", name: "Anna Silva", role: "Cameriere", rating: 4.7, km: 1.2, badges: ["VELOCE", "CORTESE"], tone: 3 },
        { init: "DS", name: "Davide S.", role: "Chef de Rang", rating: 4.8, km: 2.8, badges: ["VELOCE", "VINO"], tone: 1 },
        { init: "PA", name: "Paolo A.", role: "Runner", rating: 4.6, km: 3.5, badges: ["VELOCE"], tone: 2 },
        { init: "LM", name: "Lucia M.", role: "Sommelier", rating: 4.9, km: 5.1, badges: ["VINO", "GENTILE"], tone: 5 }].
        map((t, i) =>
        <div key={i} onClick={() => onOpenTalent({ ...t, avail: "Stasera" })}
        className="card tap" style={{ minWidth: 175, padding: 14, flexShrink: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
              <Avatar initials={t.init} size={42} tone={t.tone} ring />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.name}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 3, marginTop: 2 }}>
                  <Icon name="star" size={10} color="var(--gold)" />
                  <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 11.5 }}>{t.rating}</span>
                </div>
              </div>
            </div>
            <div style={{ fontSize: 11, color: "var(--t-3)", marginBottom: 8 }}>{t.role} · {t.km} km</div>
            <div style={{ display: "flex", gap: 3, flexWrap: "wrap", marginBottom: 10 }}>
              {t.badges.map((b) => <Pill key={b} small active>{b}</Pill>)}
            </div>
            <button onClick={(e) => { e.stopPropagation(); showToast(`Richiesta inviata a ${t.name.split(" ")[0]}`, "send"); }} className="btn-gold" style={{ width: "100%", padding: "8px 0", fontSize: 11.5 }}>Chiama</button>
          </div>
        )}
      </div>

      {/* Mini stats locale */}
      <SectionHeader eyebrow="Locale · Novembre" title="A colpo d'occhio" />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 22 }}>
        <StatCell value="4,7" sub="rating locale" />
        <StatCell value="284" sub="recensioni nov" />
        <StatCell value="€ 4.820" sub="spesa staff" />
        <StatCell value="92%" sub="copertura turni" />
      </div>

      {/* Storico collaborazioni */}
      <button onClick={onOpenCollaborazioni} className="card tap" style={{
        display: "flex", alignItems: "center", gap: 14, padding: 16, width: "100%", textAlign: "left",
        cursor: "pointer", color: "var(--t-1)",
      }}>
        <div style={{
          width: 44, height: 44, borderRadius: 12, flexShrink: 0,
          background: "linear-gradient(160deg, oklch(0.30 0.04 70), oklch(0.18 0.02 60))",
          border: "1px solid var(--hair-2)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Icon name="users" size={22} color="var(--gold)" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="mono" style={{ color: "var(--gold)", marginBottom: 3 }}>STORICO COLLABORAZIONI</div>
          <div style={{ fontSize: 14.5, fontWeight: 600 }}>6 talenti · 25 turni svolti</div>
          <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>Richiama chi già conosce il tuo locale</div>
        </div>
        <Icon name="chevR" size={18} color="var(--gold)" />
      </button>
    </div>);

};

// ─────────────────────────────────────────────────────────────
// SCREEN — CHIAMATA EXTRA (broadcast push to nearby talents)
// ─────────────────────────────────────────────────────────────
const ScreenCallExtra = ({ onClose }) => {
  const [role, setRole] = React.useState("CAMERIERE");
  const [badges, setBadges] = React.useState(new Set(["VELOCE", "CORTESE"]));
  const [radius, setRadius] = React.useState(10);
  const [phase, setPhase] = React.useState("compose"); // compose | sending | done

  const toggleBadge = (b) => {
    const n = new Set(badges);
    if (n.has(b)) n.delete(b);else n.add(b);
    setBadges(n);
  };

  // Pseudo-realistic matching count
  const count = Math.max(2, 28 - radius - badges.size * 3 - (role === "SOMMELIER" ? 8 : role === "CHEF DE RANG" ? 5 : 0));

  React.useEffect(() => {
    if (phase === "sending") {
      const t = setTimeout(() => setPhase("done"), 1800);
      return () => clearTimeout(t);
    }
  }, [phase]);

  if (phase === "done") {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px", color: "var(--t-1)", height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center" }}>
        <div style={{
          width: 110, height: 110, borderRadius: 999,
          background: "radial-gradient(circle, var(--gold-glow), transparent 70%)",
          display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 24
        }}>
          <div className="gold-pulse" style={{
            width: 78, height: 78, borderRadius: 999,
            background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))",
            display: "flex", alignItems: "center", justifyContent: "center"
          }}>
            <Icon name="broadcast" size={36} color="#1a1206" strokeWidth={2} />
          </div>
        </div>
        <div className="mono" style={{ marginBottom: 10, color: "var(--gold)" }}>NOTIFICA INVIATA</div>
        <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.02em", marginBottom: 12, maxWidth: 290 }}>
          {count} talenti<br />stanno ricevendo l'avviso.
        </div>
        <div style={{ fontSize: 13, color: "var(--t-3)", maxWidth: 290, lineHeight: 1.5, marginBottom: 32 }}>
          Riceverai una notifica appena qualcuno accetta. Tempo di risposta medio: <span style={{ color: "var(--gold)" }}>4 minuti</span>.
        </div>
        <button onClick={onClose} className="btn-ghost" style={{ padding: "13px 28px" }}>Torna alla dashboard</button>
      </div>);

  }

  if (phase === "sending") {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px", color: "var(--t-1)", height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center" }}>
        <div className="spin" style={{
          width: 76, height: 76, borderRadius: 99, marginBottom: 24,
          border: "4px solid rgba(255,200,90,0.18)", borderTopColor: "var(--gold)"
        }} />
        <div className="mono" style={{ color: "var(--gold)", marginBottom: 8 }}>BROADCAST IN CORSO</div>
        <div className="serif" style={{ fontSize: 20, letterSpacing: "-0.01em" }}>Sto contattando i talenti…</div>
      </div>);

  }

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 22px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="close" size={18} color="var(--t-2)" /></button>
        <div>
          <div className="mono" style={{ color: "var(--gold)" }}>SOS · CHIAMATA EXTRA</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Trova un sostituto</div>
        </div>
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Ruolo cercato</div>
      <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 22, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20 }}>
        {["CAMERIERE", "CHEF DE RANG", "SOMMELIER", "RUNNER", "HOSTESS"].map((r) =>
        <Pill key={r} active={role === r} gold={role === r} onClick={() => setRole(r)}>{r}</Pill>
        )}
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Filtra per badge richiesti</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 22 }}>
        {["VELOCE", "CORTESE", "VINO", "COCKTAIL", "MULTI", "GENTILE", "EVENTI"].map((b) =>
        <Pill key={b} small active={badges.has(b)} gold={badges.has(b)} onClick={() => toggleBadge(b)}>{b}</Pill>
        )}
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Raggio di ricerca · {radius} km</div>
      <div className="card" style={{ padding: 16, marginBottom: 22 }}>
        <input type="range" min={1} max={25} value={radius} onChange={(e) => setRadius(+e.target.value)}
        style={{ width: "100%", accentColor: "oklch(0.81 0.115 82)" }} />
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
          <span className="mono">1 KM</span>
          <span className="mono">25 KM</span>
        </div>
      </div>

      {/* Match counter — big hero */}
      <div className="card" style={{
        padding: "18px 20px", marginBottom: 22, textAlign: "center",
        background: "linear-gradient(180deg, oklch(0.22 0.020 75) 0%, oklch(0.17 0.012 65) 100%)",
        borderColor: "var(--gold)", borderWidth: 1.5
      }}>
        <div className="mono" style={{ color: "var(--gold)", marginBottom: 6 }}>TALENTI CORRISPONDENTI ORA</div>
        <div className="gold-shimmer numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 48, lineHeight: 1, letterSpacing: "-0.03em" }}>{count}</div>
        <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 6 }}>disponibili stasera · entro {radius}km</div>
      </div>

      <div className="mono" style={{ marginBottom: 10 }}>Anteprima notifica push</div>
      <div className="card" style={{
        padding: 14, marginBottom: 22, display: "flex", gap: 12, alignItems: "flex-start",
        background: "var(--bg-2)"
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 9,
          background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))",
          display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0
        }}>
          <Icon name="logo" size={20} color="#1a1206" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 11.5, color: "var(--t-3)", marginBottom: 2 }}>AURA · ora</div>
          <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 3 }}>Trattoria da Gino cerca un {role.toLowerCase()}</div>
          <div style={{ fontSize: 12, color: "var(--t-2)", lineHeight: 1.4 }}>Stasera 19:00–00:00 · €&nbsp;165 · Centro Milano</div>
        </div>
      </div>

      <button onClick={() => setPhase("sending")} className="btn-gold" style={{ width: "100%", padding: 16, fontSize: 15 }}>
        Invia chiamata a {count} talenti
      </button>
      <div className="mono" style={{ textAlign: "center", marginTop: 12, color: "var(--t-4)" }}>
        Disponibile sul piano Business · 3 chiamate gratis/mese
      </div>
    </div>);

};

// ─────────────────────────────────────────────────────────────
// SCREEN — NOTIFICHE
// ─────────────────────────────────────────────────────────────
const ScreenNotifiche = ({ onClose, userRole = "waiter", onNavigate }) => {
  const waiterNotifs = [
    { id: 0, icon: "check", tone: "pos", title: "Sei stato scelto!", body: "Hotel Manin ti ha confermato · Maître Brunch Dom 16 nov", time: "ora", unread: true, target: "mie-candidature", group: "Oggi" },
    { id: 1, icon: "star", tone: "gold", title: "Nuova recensione verificata", body: "Famiglia C. ti ha dato 5 stelle · scontrino #4821", time: "ora", unread: true, target: "profilo-recensioni", group: "Oggi" },
    { id: 2, icon: "euro", tone: "pos", title: "Pagamento ricevuto", body: "€ 185 accreditati sul wallet · Trattoria da Gino", time: "2h", unread: true, target: "wallet", group: "Oggi" },
    { id: 3, icon: "chat", tone: "gold", title: "Sara M. ti ha scritto", body: "Mi serviresti per evento privato 22/11?", time: "5h", unread: true, target: "chat", group: "Oggi" },
    { id: 4, icon: "spark", tone: "gold", title: "Badge ISTRUITO in verifica", body: "Il tuo attestato è in revisione · entro 48h", time: "ieri", unread: false, target: "certificazioni", group: "Questa settimana" },
    { id: 5, icon: "calendar", tone: "default", title: "Turno confermato", body: "Ven 14 nov · Osteria Bartolomeo · 20:30", time: "ieri", unread: false, target: "chat", group: "Questa settimana" },
    { id: 6, icon: "shield2", tone: "pos", title: "Identità verificata", body: "Il tuo documento è stato approvato", time: "2g", unread: false, target: "impostazioni", group: "Precedenti" },
  ];
  const managerNotifs = [
    { id: 0, icon: "star", tone: "gold", title: "Turno completato · valuta Anna", body: "Anna Silva ha finito il turno di Sab 08 · lascia una valutazione", time: "ora", unread: true, target: "valuta", group: "Oggi" },
    { id: 1, icon: "lightning", tone: "gold", title: "Anna Silva ha accettato", body: "Risponde alla tua Chiamata Extra · arriva alle 19:00", time: "ora", unread: true, target: "chat", group: "Oggi" },
    { id: 2, icon: "users", tone: "default", title: "Giulia Romano è in ritardo", body: "Accoglienza · +12 minuti sul turno di stasera", time: "20 min", unread: true, target: "turnario", group: "Oggi" },
    { id: 3, icon: "star", tone: "gold", title: "Nuova recensione al locale", body: "Il tuo locale ha ricevuto 5 stelle", time: "3h", unread: true, target: "collaborazioni", group: "Oggi" },
    { id: 4, icon: "shield2", tone: "pos", title: "P.IVA verificata", body: "Trattoria da Gino è ora un Locale Verificato", time: "ieri", unread: false, target: "impostazioni", group: "Questa settimana" },
    { id: 5, icon: "doc", tone: "default", title: "3 nuove candidature", body: "Per il turno di sabato 15 nov", time: "ieri", unread: false, target: "annunci", group: "Questa settimana" },
  ];
  const notifs = userRole === "manager" ? managerNotifs : waiterNotifs;
  const groups = ["Oggi", "Questa settimana", "Precedenti"];
  const unreadCount = notifs.filter(n => n.unread).length;
  const toneColor = { gold: "var(--gold)", pos: "var(--pos)", default: "var(--t-2)" };
  const toneBg = {
    gold: "rgba(255,200,90,0.10)",
    pos: "oklch(0.80 0.140 150 / 0.10)",
    default: "rgba(255,255,255,0.05)",
  };

  const handle = (n) => {
    if (n.target && onNavigate) onNavigate(n.target);
    else showToast("Notifica aperta");
  };

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 0 22px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)"/></button>
          <div>
            <div className="mono">Aggiornamenti</div>
            <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Notifiche</div>
          </div>
        </div>
        <button onClick={() => showToast("Tutte segnate come lette")} className="mono" style={{
          background: "transparent", border: 0, cursor: "pointer", color: "var(--gold)",
          fontSize: 9.5, letterSpacing: "0.12em", textTransform: "uppercase",
        }}>Segna lette</button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
        {groups.map(g => {
          const items = notifs.filter(n => n.group === g);
          if (items.length === 0) return null;
          const gUnread = items.filter(n => n.unread).length;
          return (
            <div key={g}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <span className="mono">{g}</span>
                {gUnread > 0 && (
                  <span style={{
                    fontFamily: "var(--f-mono)", fontSize: 8.5, padding: "2px 7px", borderRadius: 999,
                    background: "rgba(255,200,90,0.12)", color: "var(--gold)", letterSpacing: "0.1em",
                  }}>{gUnread} NUOVE</span>
                )}
                <div style={{ flex: 1, height: 1, background: "var(--hair)" }}/>
              </div>
              <div className="card" style={{ overflow: "hidden" }}>
                {items.map((n, i) => (
                  <div key={n.id} onClick={() => handle(n)} className="tap" style={{
                    padding: 14, display: "flex", gap: 12, alignItems: "flex-start",
                    borderBottom: i === items.length - 1 ? "none" : "1px solid var(--hair)",
                    background: n.unread ? "rgba(255,200,90,0.025)" : "transparent",
                  }}>
                    <div style={{
                      width: 38, height: 38, borderRadius: 10, flexShrink: 0,
                      background: toneBg[n.tone], border: `1px solid ${n.tone === "default" ? "var(--hair)" : toneColor[n.tone]}`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}>
                      <Icon name={n.icon} size={18} color={toneColor[n.tone]}/>
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ fontSize: 14, fontWeight: 600, color: "var(--t-1)" }}>{n.title}</span>
                        {n.unread && <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--gold)", flexShrink: 0 }}/>}
                      </div>
                      <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 3, lineHeight: 1.4 }}>{n.body}</div>
                    </div>
                    <span className="mono" style={{ flexShrink: 0, color: "var(--t-4)" }}>{n.time}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

Object.assign(window, {
  ScreenWallet, ScreenQRPro, ScreenContestazione, ScreenCertificazioni,
  ScreenManagerDashboard, ScreenCallExtra, ScreenNotifiche
});