// Aura — Screens part 8: Profilo Pubblico completo + Agenda cameriere

// ─────────────────────────────────────────────────────────────
// SCREEN — PROFILO PUBBLICO (external read-only view)
// ─────────────────────────────────────────────────────────────
const ScreenProfiloPubblico = ({ talent, onClose, onProponi }) => {
  const t = talent || {};
  const name = t.name || "Marco Rossi";
  const init = t.init || t.initials || (name.split(" ").map(w => w[0]).join("").slice(0, 2));
  const role = t.role || "Chef de Rang";
  const rating = t.rating || "4,8";
  const reviews = t.reviews || 142;
  const tone = t.tone != null ? t.tone : 0;
  const badges = (t.badges && t.badges.length ? t.badges : ["VINO", "VELOCE", "CORTESE", "GENTILE", "MULTI", "COCKTAIL"]);
  const km = t.km;

  const experience = [
    { from: "2024", to: "oggi", venue: "Trattoria da Gino", role: "Chef de Rang", note: "Sala 32 coperti · cucina lombarda" },
    { from: "2022", to: "2024", venue: "Osteria Bartolomeo", role: "Cameriere di Sala", note: "180 servizi · eventi privati" },
    { from: "2020", to: "2022", venue: "Caffè Centrale", role: "Bartender", note: "Cocktail bar · stagione Lago" },
  ];
  const recensioni = [
    { who: "Anna B.", when: "10/11", stars: 5, txt: "Conoscenza vini eccellente, attento ai dettagli." },
    { who: "Tavolo 18", when: "08/11", stars: 5, txt: "Servizio rapido senza essere frettoloso." },
  ];

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 0 18px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div className="mono">Profilo pubblico</div>
        <button onClick={() => showToast("Link al profilo copiato", "check")} style={iconBtn}><Icon name="send" size={18} color="var(--t-2)" /></button>
      </div>

      {/* Hero */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", marginBottom: 20 }}>
        <Avatar initials={init} size={92} ring tone={tone} />
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 16 }}>
          <span className="serif" style={{ fontSize: 27, lineHeight: 1, letterSpacing: "-0.02em" }}>{name}</span>
          <Verified size={17} />
        </div>
        <div style={{ fontSize: 13.5, color: "var(--t-2)", marginTop: 6 }}>
          {role} · Milano{km != null ? ` · ${km} km` : ""}
        </div>
        <div style={{ display: "flex", gap: 16, marginTop: 16 }}>
          <div style={{ textAlign: "center" }}>
            <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 18, color: "var(--gold)" }}>★ {rating}</div>
            <div className="mono" style={{ marginTop: 2 }}>rating</div>
          </div>
          <div style={{ width: 1, background: "var(--hair)" }} />
          <div style={{ textAlign: "center" }}>
            <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 18 }}>{reviews}</div>
            <div className="mono" style={{ marginTop: 2 }}>recensioni</div>
          </div>
          <div style={{ width: 1, background: "var(--hair)" }} />
          <div style={{ textAlign: "center" }}>
            <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 18 }}>6a</div>
            <div className="mono" style={{ marginTop: 2 }}>esperienza</div>
          </div>
        </div>
      </div>

      {/* Action bar */}
      <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
        <button onClick={() => showToast(`Messaggio a ${name.split(" ")[0]}`, "chat")} className="btn-ghost" style={{ flex: 1, padding: 14, fontSize: 13.5 }}>Messaggio</button>
        <button onClick={() => { showToast(`Proposta turno inviata a ${name.split(" ")[0]}`, "send"); onProponi && onProponi(); }} className="btn-gold" style={{ flex: 1.4, padding: 14, fontSize: 13.5 }}>Proponi turno</button>
      </div>

      {/* Verified badge note */}
      <div className="card" style={{ padding: 14, marginBottom: 22, display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ width: 38, height: 38, borderRadius: 10, background: "oklch(0.80 0.140 150 / 0.10)", border: "1px solid oklch(0.80 0.140 150 / 0.4)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon name="shield2" size={18} color="var(--pos)" />
        </div>
        <div style={{ flex: 1, fontSize: 12, color: "var(--t-2)", lineHeight: 1.45 }}>
          Identità e documenti <strong style={{ color: "var(--t-1)" }}>verificati</strong>. Tutte le recensioni sono certificate via scontrino.
        </div>
      </div>

      {/* Badges */}
      <div className="mono" style={{ marginBottom: 12 }}>Badge di eccellenza</div>
      <div className="scroll" style={{ display: "flex", gap: 12, overflowX: "auto", paddingBottom: 4, marginBottom: 24, marginLeft: -20, marginRight: -20, padding: "4px 20px" }}>
        {badges.map(b => <Badge key={b} label={b} size={62} />)}
      </div>

      {/* Stats */}
      <div className="mono" style={{ marginBottom: 12 }}>Affidabilità</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 24 }}>
        <StatCell value="98%" sub="puntualità" />
        <StatCell value="0" sub="reclami 90gg" />
        <StatCell value="142" sub="turni svolti" />
        <StatCell value="IT·EN·FR" sub="lingue" />
      </div>

      {/* Esperienze */}
      <div className="mono" style={{ marginBottom: 12 }}>Esperienze</div>
      <div style={{ marginBottom: 24 }}>
        {experience.map((e, i) => (
          <div key={i} style={{ display: "flex", gap: 14, paddingBottom: 14, marginBottom: 14, borderBottom: i === experience.length - 1 ? "none" : "1px solid var(--hair)" }}>
            <div style={{ flexShrink: 0, width: 56 }}>
              <div className="mono numeric" style={{ color: "var(--gold)" }}>{e.from}</div>
              <div className="mono numeric" style={{ color: "var(--t-4)" }}>{e.to}</div>
            </div>
            <div style={{ flex: 1, paddingLeft: 14, borderLeft: "1px solid var(--hair-2)", position: "relative" }}>
              <div style={{ position: "absolute", left: -4, top: 5, width: 7, height: 7, borderRadius: 99, background: "var(--gold)", boxShadow: "0 0 0 3px var(--bg-0)" }} />
              <div style={{ fontSize: 14, fontWeight: 600 }}>{e.venue}</div>
              <div style={{ fontSize: 12, color: "var(--t-2)", marginTop: 2 }}>{e.role}</div>
              <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 5 }}>{e.note}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Recensioni */}
      <div className="mono" style={{ marginBottom: 12 }}>Recensioni verificate</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {recensioni.map((r, i) => (
          <div key={i} className="card" style={{ padding: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <div style={{ display: "flex", gap: 2 }}>
                {Array.from({ length: 5 }).map((_, j) => <Icon key={j} name="star" size={12} color={j < r.stars ? "var(--gold)" : "var(--t-4)"} />)}
              </div>
              <span className="mono" style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><Verified size={11} /> {r.who} · {r.when}</span>
            </div>
            <div className="serif" style={{ fontSize: 14, lineHeight: 1.4 }}>“{r.txt}”</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// SCREEN — AGENDA (waiter availability + shifts + proposals)
// ─────────────────────────────────────────────────────────────
const ScreenAgenda = ({ onClose, onOpenTurno }) => {
  const days = [
    { key: "lun", label: "LUN", date: "10" },
    { key: "mar", label: "MAR", date: "11" },
    { key: "mer", label: "MER", date: "12", today: true },
    { key: "gio", label: "GIO", date: "13" },
    { key: "ven", label: "VEN", date: "14" },
    { key: "sab", label: "SAB", date: "15" },
    { key: "dom", label: "DOM", date: "16" },
  ];
  const slots = [["P", "Pranzo"], ["C", "Cena"]];

  // availability: { "mer-C": true, ... }
  const [avail, setAvail] = React.useState({
    "mar-C": true, "mer-C": true, "gio-C": true, "ven-C": true, "ven-P": false,
    "sab-P": true, "sab-C": true, "dom-P": true,
  });
  const toggle = (k) => setAvail(a => ({ ...a, [k]: !a[k] }));
  const availCount = Object.values(avail).filter(Boolean).length;

  const proposals = [
    { id: 1, venue: "Trattoria da Gino", role: "Chef de Rang", day: "Sab 15 nov", time: "19:00–00:30", pay: "€ 165", tone: 0 },
    { id: 2, venue: "Hotel Manin · Eventi", role: "Maître Brunch", day: "Dom 16 nov", time: "12:00–16:00", pay: "€ 120", tone: 5 },
  ];
  const [resolved, setResolved] = React.useState({}); // id -> 'ok' | 'no'
  const resolve = (id, v, venue) => {
    setResolved(r => ({ ...r, [id]: v }));
    showToast(v === "ok" ? `Turno accettato · ${venue}` : "Proposta rifiutata", v === "ok" ? "check" : "close");
  };

  const confirmed = [
    { day: "GIO 13", time: "19:00–00:00", venue: "Trattoria da Gino", role: "Chef de Rang", est: "€ 150" },
    { day: "VEN 14", time: "20:30–01:00", venue: "Osteria Bartolomeo", role: "Servizio Sala", est: "€ 175" },
  ];

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 18px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div>
          <div className="mono">Settimana 10–16 Nov</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>La tua agenda</div>
        </div>
      </div>

      {/* Proposals */}
      {proposals.some(p => !resolved[p.id]) && (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <span className="mono" style={{ color: "var(--gold)" }}>Proposte ricevute</span>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 8.5, padding: "2px 7px", borderRadius: 999, background: "rgba(255,200,90,0.12)", color: "var(--gold)" }}>
              {proposals.filter(p => !resolved[p.id]).length} NUOVE
            </span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
            {proposals.filter(p => !resolved[p.id]).map(p => (
              <div key={p.id} className="card" style={{ padding: 16, borderColor: "var(--gold)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
                  <Avatar initials={p.venue.split(" ").map(w => w[0]).join("").slice(0, 2)} size={42} tone={p.tone} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14.5, fontWeight: 600 }}>{p.venue}</div>
                    <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{p.role} · {p.day} · {p.time}</div>
                  </div>
                  <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 16, color: "var(--gold)" }}>{p.pay}</span>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => resolve(p.id, "no", p.venue)} className="btn-ghost" style={{ flex: 1, padding: 11, fontSize: 12.5 }}>Rifiuta</button>
                  <button onClick={() => resolve(p.id, "ok", p.venue)} className="btn-gold" style={{ flex: 1.4, padding: 11, fontSize: 12.5 }}>Accetta turno</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Availability grid */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 }}>
        <span className="mono">Le tue disponibilità</span>
        <span className="mono" style={{ color: "var(--gold)" }}>{availCount} fasce</span>
      </div>
      <div className="card" style={{ padding: "14px 12px", marginBottom: 8 }}>
        <div style={{ display: "grid", gridTemplateColumns: "44px repeat(7, 1fr)", gap: 6, alignItems: "center" }}>
          <div />
          {days.map(d => (
            <div key={d.key} style={{ textAlign: "center" }}>
              <div className="mono" style={{ fontSize: 8, color: d.today ? "var(--gold)" : "var(--t-4)" }}>{d.label}</div>
              <div className="numeric" style={{ fontSize: 11, fontWeight: 600, marginTop: 1 }}>{d.date}</div>
            </div>
          ))}
          {slots.map(([sk, slabel]) => (
            <React.Fragment key={sk}>
              <div className="mono" style={{ fontSize: 8, color: "var(--t-3)" }}>{sk}</div>
              {days.map(d => {
                const k = `${d.key}-${sk}`;
                const on = avail[k];
                return (
                  <button key={k} onClick={() => toggle(k)} style={{
                    height: 32, borderRadius: 9, cursor: "pointer",
                    border: `1px solid ${on ? "var(--gold)" : "var(--hair-2)"}`,
                    background: on ? "rgba(255,200,90,0.12)" : "transparent",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    transition: "all .12s ease",
                  }}>
                    {on && <Icon name="check" size={13} color="var(--gold)" strokeWidth={2.4} />}
                  </button>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "center", gap: 16, marginBottom: 24 }}>
        <span className="mono" style={{ color: "var(--t-4)" }}>P · Pranzo</span>
        <span className="mono" style={{ color: "var(--t-4)" }}>C · Cena</span>
        <span className="mono" style={{ color: "var(--gold)" }}>Tocca per attivare</span>
      </div>

      {/* Confirmed shifts */}
      <div className="mono" style={{ marginBottom: 10 }}>Turni confermati · {confirmed.length}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {confirmed.map((c, i) => (
          <div key={i} onClick={() => onOpenTurno && onOpenTurno(c)} className="card tap" style={{ padding: "14px 16px", display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 50, textAlign: "center", padding: "8px 0", border: "1px solid var(--hair-2)", borderRadius: 12 }}>
              <div className="mono" style={{ fontSize: 9, color: "var(--t-3)" }}>{c.day.split(" ")[0]}</div>
              <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontSize: 17, fontWeight: 700, marginTop: 2 }}>{c.day.split(" ")[1]}</div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14.5, fontWeight: 600 }}>{c.venue}</div>
              <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{c.role} · {c.time}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontSize: 15, fontWeight: 700, color: "var(--gold)" }}>{c.est}</div>
              <div className="mono" style={{ fontSize: 8.5, color: "var(--t-3)", marginTop: 2 }}>stima</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { ScreenProfiloPubblico, ScreenAgenda });
