// Aura — Screen: Storico collaborazioni (manager ↔ talent work history)

const ScreenCollaborazioni = ({ onClose, onOpenDetail, onPubblica }) => {
  const [sort, setSort] = React.useState("recenti"); // recenti | turni | rating
  const [filter, setFilter] = React.useState("TUTTI");

  const collabs = [
    { id: 1, init: "MR", name: "Marco Rossi", role: "Chef de Rang", tone: 0, count: 8, rating: 4.9, last: "Gio 13 nov", lastRel: "2 giorni fa", spent: "€ 1.180", badges: ["VINO", "VELOCE"], fav: true, status: "ok" },
    { id: 2, init: "EC", name: "Elisa Conte", role: "Sommelier", tone: 4, count: 6, rating: 4.9, last: "Ven 14 nov", lastRel: "1 giorno fa", spent: "€ 1.320", badges: ["VINO", "EVENTI"], fav: true, status: "ok" },
    { id: 3, init: "LT", name: "Luca Trapani", role: "Cameriere", tone: 2, count: 5, rating: 4.6, last: "Sab 8 nov", lastRel: "1 settimana fa", spent: "€ 720", badges: ["VELOCE"], status: "ok" },
    { id: 4, init: "GR", name: "Giulia Romano", role: "Hostess", tone: 5, count: 3, rating: 4.8, last: "Dom 2 nov", lastRel: "2 settimane fa", spent: "€ 360", badges: ["CORTESE"], status: "ok" },
    { id: 5, init: "FT", name: "Federico Turi", role: "Runner", tone: 1, count: 2, rating: 4.5, last: "Sab 25 ott", lastRel: "3 settimane fa", spent: "€ 180", badges: ["VELOCE"], status: "lapsed" },
    { id: 6, init: "AS", name: "Anna Silva", role: "Cameriere", tone: 3, count: 1, rating: 4.7, last: "Ven 17 ott", lastRel: "1 mese fa", spent: "€ 95", badges: ["MULTI"], status: "lapsed" },
  ];

  const filtered = collabs.filter(c =>
    filter === "TUTTI" ? true : filter === "PREFERITI" ? c.fav : filter === "DA RICHIAMARE" ? c.status === "lapsed" : true
  );
  const sorted = [...filtered].sort((a, b) =>
    sort === "turni" ? b.count - a.count :
    sort === "rating" ? b.rating - a.rating :
    b.count - a.count // proxy for recency in this mock
  );

  // header aggregate
  const totalTurni = collabs.reduce((s, c) => s + c.count, 0);
  const recurring = collabs.filter(c => c.count >= 3).length;

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 18px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div>
          <div className="mono">Trattoria da Gino</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Collaborazioni</div>
        </div>
      </div>

      {/* Aggregate strip */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 20 }}>
        <StatCell value={String(collabs.length)} sub="talenti" />
        <StatCell value={String(totalTurni)} sub="turni totali" />
        <StatCell value={String(recurring)} sub="ricorrenti" />
      </div>

      {/* Filter */}
      <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 14, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20 }}>
        {["TUTTI", "PREFERITI", "DA RICHIAMARE"].map(f => (
          <Pill key={f} small active={filter === f} gold={filter === f} onClick={() => setFilter(f)}>{f}</Pill>
        ))}
      </div>

      {/* Sort */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
        <span className="mono" style={{ marginRight: 2 }}>Ordina</span>
        {[["recenti", "Recenti"], ["turni", "Più turni"], ["rating", "Rating"]].map(([id, lbl]) => (
          <Pill key={id} small active={sort === id} gold={sort === id} onClick={() => setSort(id)}>{lbl}</Pill>
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {sorted.map(c => (
          <div key={c.id} onClick={() => onOpenDetail(c)} className="card tap" style={{ padding: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <Avatar initials={c.init} size={50} tone={c.tone} ring={c.fav} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ fontSize: 14.5, fontWeight: 600 }}>{c.name}</span>
                  <Verified size={12} />
                  {c.fav && <Icon name="star" size={12} color="var(--gold)" />}
                </div>
                <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{c.role} · ultimo turno {c.lastRel}</div>
                <div style={{ display: "flex", gap: 4, marginTop: 8, flexWrap: "wrap" }}>
                  {c.badges.map(b => <Pill key={b} small active>{b}</Pill>)}
                </div>
              </div>
              <div style={{ textAlign: "right", flexShrink: 0 }}>
                <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 22, color: "var(--gold)", lineHeight: 1 }}>{c.count}</div>
                <div className="mono" style={{ marginTop: 2 }}>turni</div>
              </div>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--hair)" }}>
              <div style={{ display: "flex", gap: 14 }}>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12, color: "var(--t-2)" }}>
                  <Icon name="star" size={12} color="var(--gold)" /> {c.rating}
                </span>
                <span style={{ fontSize: 12, color: "var(--t-3)" }}>{c.spent} totali</span>
              </div>
              {c.status === "lapsed" ? (
                <button onClick={(e) => { e.stopPropagation(); showToast(`Richiamo inviato a ${c.name.split(" ")[0]}`, "send"); }}
                  className="btn-gold" style={{ padding: "7px 14px", fontSize: 11.5 }}>Richiama</button>
              ) : (
                <button onClick={(e) => { e.stopPropagation(); showToast(`Proposta turno inviata a ${c.name.split(" ")[0]}`, "send"); }}
                  className="btn-ghost" style={{ padding: "7px 14px", fontSize: 11.5 }}>Proponi turno</button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// Detail — single collaboration history
// ─────────────────────────────────────────────────────────────
const ScreenCollaboraDetail = ({ collab, onClose, onOpenTalent }) => {
  const c = collab || { init: "MR", name: "Marco Rossi", role: "Chef de Rang", tone: 0, count: 8, rating: 4.9, spent: "€ 1.180", badges: ["VINO", "VELOCE"] };

  const history = [
    { day: "Gio 13 nov", role: "Chef de Rang", time: "19:00–00:00", pay: "€ 150", rating: 5, note: "Servizio impeccabile, gestita la sala al completo." },
    { day: "Sab 8 nov", role: "Chef de Rang", time: "19:00–01:00", pay: "€ 175", rating: 5, note: "Evento privato 40 coperti." },
    { day: "Ven 1 nov", role: "Servizio Sala", time: "20:00–00:30", pay: "€ 160", rating: 4, note: "Tutto ok, leggero ritardo iniziale." },
    { day: "Sab 26 ott", role: "Chef de Rang", time: "19:00–00:00", pay: "€ 150", rating: 5, note: "Cliente abituale ha chiesto di lui." },
    { day: "Dom 20 ott", role: "Maître Brunch", time: "12:00–16:00", pay: "€ 120", rating: 5, note: "Brunch della domenica." },
  ];

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 22px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div>
          <div className="mono">Storico</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Collaborazione</div>
        </div>
      </div>

      {/* Person header */}
      <div className="card" style={{ padding: 18, marginBottom: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <Avatar initials={c.init} size={60} tone={c.tone} ring />
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span className="serif" style={{ fontSize: 20 }}>{c.name}</span>
              <Verified size={14} />
            </div>
            <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 2 }}>{c.role}</div>
            <div style={{ display: "flex", gap: 4, marginTop: 8, flexWrap: "wrap" }}>
              {c.badges.map(b => <Pill key={b} small active>{b}</Pill>)}
            </div>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: 16 }}>
          <div className="card-2" style={{ padding: "12px 10px", textAlign: "center" }}>
            <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 20, color: "var(--gold)" }}>{c.count}</div>
            <div className="mono" style={{ marginTop: 3 }}>turni</div>
          </div>
          <div className="card-2" style={{ padding: "12px 10px", textAlign: "center" }}>
            <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 20, color: "var(--t-1)" }}>★ {c.rating}</div>
            <div className="mono" style={{ marginTop: 3 }}>media</div>
          </div>
          <div className="card-2" style={{ padding: "12px 10px", textAlign: "center" }}>
            <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 20, color: "var(--t-1)" }}>{c.spent}</div>
            <div className="mono" style={{ marginTop: 3 }}>totale</div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div style={{ display: "flex", gap: 8, marginBottom: 22 }}>
        <button onClick={() => onOpenTalent({ id: c.id, init: c.init, name: c.name, role: c.role, rating: c.rating, badges: c.badges, avail: "Storico", tone: c.tone })}
          className="btn-ghost" style={{ flex: 1, padding: 13, fontSize: 13 }}>Profilo</button>
        <button onClick={() => showToast(`Proposta turno inviata a ${c.name.split(" ")[0]}`, "send")}
          className="btn-gold" style={{ flex: 1.3, padding: 13, fontSize: 13 }}>Proponi turno</button>
      </div>

      {/* Timeline */}
      <div className="mono" style={{ marginBottom: 12 }}>Cronologia turni · {history.length}</div>
      <div style={{ display: "flex", flexDirection: "column" }}>
        {history.map((h, i) => (
          <div key={i} style={{ display: "flex", gap: 14, paddingBottom: i === history.length - 1 ? 0 : 16 }}>
            {/* rail */}
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
              <div style={{ width: 9, height: 9, borderRadius: 99, background: "var(--gold)", boxShadow: "0 0 0 3px var(--bg-0)", marginTop: 4 }} />
              {i !== history.length - 1 && <div style={{ flex: 1, width: 1, background: "var(--hair-2)", marginTop: 4 }} />}
            </div>
            {/* card */}
            <div className="card" style={{ flex: 1, padding: 14, marginBottom: 0 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 600 }}>{h.day}</div>
                  <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{h.role} · {h.time}</div>
                </div>
                <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 14, color: "var(--gold)" }}>{h.pay}</span>
              </div>
              <div style={{ display: "flex", gap: 2, marginBottom: 8 }}>
                {Array.from({ length: 5 }).map((_, j) => (
                  <Icon key={j} name="star" size={11} color={j < h.rating ? "var(--gold)" : "var(--t-4)"} />
                ))}
              </div>
              <div style={{ fontSize: 12, color: "var(--t-2)", lineHeight: 1.45 }}>“{h.note}”</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { ScreenCollaborazioni, ScreenCollaboraDetail });
