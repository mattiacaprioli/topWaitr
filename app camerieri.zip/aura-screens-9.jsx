// Aura — Screen: lato cameriere del mercato (Trova turni + Le mie candidature)
// Chiude il loop a due lati: il cameriere sfoglia i turni aperti e si candida →
// il ristoratore lo vede in "Candidature" → assegna → atterra nell'agenda.

// Match: quante badge richieste possiede il professionista
const shiftMatch = (shift) => {
  const skills = (window.AURA && window.AURA.user && window.AURA.user.skills) || [];
  const req = shift.badges || [];
  const have = req.filter(b => skills.includes(b)).length;
  return { pct: req.length ? Math.round((have / req.length) * 100) : 100, have, total: req.length, skills };
};

// ─────────────────────────────────────────────────────────────
// SCREEN — TROVA TURNI (waiter browses & applies to open shifts)
// ─────────────────────────────────────────────────────────────
const ScreenTrovaTurni = ({ appliedIds, onApply, onOpenMie, pendingCount = 0 }) => {
  const all = (window.AURA && window.AURA.openShifts) || [];
  const city = (window.AURA && window.AURA.user && window.AURA.user.city) || "Milano";
  const applied = appliedIds || new Set();

  const [role, setRole] = React.useState("Tutti");
  const [sort, setSort] = React.useState("match"); // match | vicini | pagati
  const [sheet, setSheet] = React.useState(null);   // shift in confirm sheet

  const roles = ["Tutti", ...Array.from(new Set(all.map(s => s.role)))];
  let list = all.filter(s => role === "Tutti" || s.role === role);
  list = [...list].sort((a, b) =>
    sort === "vicini" ? parseFloat(a.km.replace(",", ".")) - parseFloat(b.km.replace(",", ".")) :
    sort === "pagati" ? (+b.pay) - (+a.pay) :
    shiftMatch(b).pct - shiftMatch(a).pct
  );

  const doApply = (s) => { onApply && onApply(s); setSheet(null); showToast(`Candidatura inviata · ${s.venue}`, "check"); };

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", padding: "4px 0 16px" }}>
        <div>
          <div className="mono" style={{ color: "var(--gold)" }}>{city} · {all.length} turni aperti</div>
          <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.01em" }}>Trova turni</div>
        </div>
        <button onClick={onOpenMie} aria-label="le mie candidature" style={{ ...iconBtn, position: "relative" }}>
          <Icon name="doc" size={19} color="var(--t-1)" />
          {pendingCount > 0 &&
          <span style={{ position: "absolute", top: -3, right: -3, minWidth: 17, height: 17, padding: "0 4px", borderRadius: 999, background: "var(--gold)", color: "#1a1206", fontFamily: "var(--f-mono)", fontSize: 9, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{pendingCount}</span>
          }
        </button>
      </div>

      {/* Role filter */}
      <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 12, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20 }}>
        {roles.map(r => <Pill key={r} small active={role === r} gold={role === r} onClick={() => setRole(r)}>{r}</Pill>)}
      </div>

      {/* Sort */}
      <div style={{ display: "flex", gap: 4, padding: 4, background: "rgba(255,255,255,0.04)", borderRadius: 12, marginBottom: 20, border: "1px solid var(--hair)" }}>
        {[["match", "Migliore match"], ["vicini", "Più vicini"], ["pagati", "Più pagati"]].map(([id, lbl]) => (
          <button key={id} onClick={() => setSort(id)} style={{
            flex: 1, padding: "9px 6px", borderRadius: 9, border: 0, cursor: "pointer",
            background: sort === id ? "rgba(255,255,255,0.10)" : "transparent",
            color: sort === id ? "var(--t-1)" : "var(--t-3)",
            fontFamily: "var(--f-ui)", fontSize: 12, fontWeight: 600, transition: "all .15s ease",
          }}>{lbl}</button>
        ))}
      </div>

      {/* Shift cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {list.map(s => {
          const m = shiftMatch(s);
          const isApplied = applied.has(s.id);
          return (
            <div key={s.id} className="card" style={{ padding: 16, borderColor: s.urgent ? "var(--gold)" : "var(--hair)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 13 }}>
                <Avatar initials={s.init} size={44} tone={s.tone} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                    <span style={{ fontSize: 15, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.venue}</span>
                    {s.urgent && <span className="mono" style={{ fontSize: 7.5, padding: "2px 6px", borderRadius: 999, background: "oklch(0.78 0.140 50 / 0.16)", color: "var(--warn)", flexShrink: 0 }}>URGENTE</span>}
                  </div>
                  <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 2 }}>{s.role} · {s.km} km da te</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 18, color: "var(--gold)" }}>€ {s.pay}</div>
                  <div className="mono" style={{ fontSize: 8, color: "var(--pos)", marginTop: 1 }}>NETTO · 100%</div>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 13, fontSize: 12.5, color: "var(--t-2)" }}>
                <Icon name="calendar" size={14} color="var(--t-3)" />
                <span>{s.day} · {s.time}</span>
                {s.event && <span className="mono" style={{ fontSize: 8, padding: "2px 6px", borderRadius: 4, background: "rgba(255,200,90,0.10)", color: "var(--gold)" }}>{s.event}</span>}
              </div>

              {/* Required badges, matched highlighted */}
              <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
                {s.badges.map(b => {
                  const has = m.skills.includes(b);
                  return (
                    <span key={b} className="mono" style={{
                      fontSize: 8.5, padding: "3px 8px", borderRadius: 999,
                      display: "inline-flex", alignItems: "center", gap: 4,
                      background: has ? "oklch(0.81 0.115 82 / 0.14)" : "rgba(255,255,255,0.04)",
                      color: has ? "var(--gold)" : "var(--t-4)",
                      border: `1px solid ${has ? "oklch(0.81 0.115 82 / 0.3)" : "var(--hair)"}`,
                    }}>
                      {has && <Icon name="check" size={9} color="var(--gold)" strokeWidth={2.6} />}{b}
                    </span>
                  );
                })}
                <span style={{ marginLeft: "auto", fontSize: 11.5, fontWeight: 600, color: m.pct === 100 ? "var(--pos)" : "var(--t-2)" }}>
                  {m.pct}% match
                </span>
              </div>

              {isApplied ? (
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: "12px 0", borderRadius: 999, background: "oklch(0.80 0.140 150 / 0.10)", border: "1px solid oklch(0.80 0.140 150 / 0.35)" }}>
                  <Icon name="check" size={16} color="var(--pos)" strokeWidth={2.4} />
                  <span style={{ fontSize: 13, fontWeight: 600, color: "var(--pos)" }}>Candidatura inviata</span>
                </div>
              ) : (
                <button onClick={() => setSheet(s)} className="btn-gold" style={{ width: "100%", padding: 13, fontSize: 14 }}>Candidati</button>
              )}
            </div>
          );
        })}
      </div>

      {/* Confirm apply sheet */}
      {sheet &&
      <div onClick={() => setSheet(null)} style={{ position: "absolute", inset: 0, zIndex: 200, background: "rgba(8,6,4,0.65)", backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)", display: "flex", alignItems: "flex-end" }}>
        <div onClick={e => e.stopPropagation()} className="modal-enter" style={{ width: "100%", background: "var(--bg-1)", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: "12px 22px 32px", borderTop: "1px solid var(--hair-2)" }}>
          <div style={{ width: 38, height: 4, background: "var(--hair-2)", borderRadius: 99, margin: "0 auto 18px" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 13, marginBottom: 18 }}>
            <Avatar initials={sheet.init} size={50} ring tone={sheet.tone} />
            <div style={{ flex: 1 }}>
              <div className="serif" style={{ fontSize: 20 }}>{sheet.venue}</div>
              <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 2 }}>{sheet.role} · {sheet.km} km</div>
            </div>
          </div>
          <div className="card-2" style={{ padding: "6px 16px", marginBottom: 14 }}>
            <Row label="Quando" value={`${sheet.day} · ${sheet.time}`} />
            <Row label="Compenso" value={`€ ${sheet.pay}`} gold />
            <Row label="Trattenuta Aura" value="Nessuna · ricevi tutto" />
            <Row label="Match con il tuo profilo" value={`${shiftMatch(sheet).pct}%`} last />
          </div>
          <div className="card-2" style={{ padding: "12px 14px", marginBottom: 16, display: "flex", gap: 10 }}>
            <Icon name="shield2" size={17} color="var(--pos)" />
            <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.5 }}>
              Candidandoti condividi il tuo <span style={{ color: "var(--t-1)" }}>profilo verificato</span> (recensioni e badge). Il compenso viene garantito sul wallet a turno completato.
            </div>
          </div>
          <button onClick={() => doApply(sheet)} className="btn-gold" style={{ width: "100%", padding: 15, fontSize: 15 }}>Conferma candidatura</button>
          <button onClick={() => setSheet(null)} style={{ width: "100%", background: "transparent", border: 0, cursor: "pointer", marginTop: 10, color: "var(--t-3)", fontSize: 13, fontFamily: "var(--f-ui)", padding: 6 }}>Annulla</button>
        </div>
      </div>
      }
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// SCREEN — LE MIE CANDIDATURE (waiter's applications)
// ─────────────────────────────────────────────────────────────
const STATUS_META = {
  pending:  { label: "In attesa", color: "var(--warn)", tint: "oklch(0.78 0.140 50 / 0.12)", icon: "clock" },
  accepted: { label: "Accettata", color: "var(--pos)",  tint: "oklch(0.80 0.140 150 / 0.12)", icon: "check" },
  rejected: { label: "Non selezionato", color: "var(--t-4)", tint: "rgba(255,255,255,0.05)", icon: "close" },
};

const ScreenMieCandidature = ({ onClose, extraApps = [], onOpenAgenda }) => {
  const base = (window.AURA && window.AURA.applications) || [];
  const apps = [...extraApps, ...base];
  const [filter, setFilter] = React.useState("tutte");

  const counts = {
    tutte: apps.length,
    pending: apps.filter(a => a.status === "pending").length,
    accepted: apps.filter(a => a.status === "accepted").length,
  };
  const list = filter === "tutte" ? apps : apps.filter(a => a.status === filter);
  const filters = [["tutte", "Tutte"], ["pending", "In attesa"], ["accepted", "Accettate"]];

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 20px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div>
          <div className="mono">{counts.pending} in attesa · {counts.accepted} accettate</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Le mie candidature</div>
        </div>
      </div>

      <div className="scroll" style={{ display: "flex", gap: 8, marginBottom: 18, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20 }}>
        {filters.map(([id, lbl]) => (
          <Pill key={id} small active={filter === id} gold={filter === id} onClick={() => setFilter(id)}>{lbl} · {counts[id]}</Pill>
        ))}
      </div>

      {list.length === 0 ? (
        <div style={{ textAlign: "center", padding: "60px 20px", color: "var(--t-4)" }}>
          <Icon name="doc" size={34} color="var(--t-4)" />
          <div style={{ fontSize: 13.5, marginTop: 14 }}>Nessuna candidatura qui</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {list.map(a => {
            const m = STATUS_META[a.status];
            return (
              <div key={a.id} className="card" style={{ padding: 16, opacity: a.status === "rejected" ? 0.6 : 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
                  <Avatar initials={a.init} size={42} tone={a.tone} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14.5, fontWeight: 600 }}>{a.venue}</div>
                    <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{a.role} · {a.day} · {a.time}</div>
                  </div>
                  <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 16, color: "var(--gold)" }}>€ {a.pay}</span>
                </div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 12, borderTop: "1px solid var(--hair)" }}>
                  <span className="mono" style={{ fontSize: 9, padding: "4px 9px", borderRadius: 999, background: m.tint, color: m.color, display: "inline-flex", alignItems: "center", gap: 5 }}>
                    <Icon name={m.icon} size={11} color={m.color} strokeWidth={2.2} />{m.label}
                  </span>
                  {a.status === "accepted" ? (
                    <button onClick={onOpenAgenda} style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12, color: "var(--gold)", fontWeight: 600, background: "transparent", border: 0, cursor: "pointer" }}>
                      Vedi in agenda <Icon name="chevR" size={14} color="var(--gold)" />
                    </button>
                  ) : (
                    <span style={{ fontSize: 11.5, color: "var(--t-3)" }}>{a.when}</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// SCREEN — VALUTA IL PROFESSIONISTA (venue → waiter review after a shift)
// Chiude la reputazione a due fonti: clienti (scontrino) + locali (turno).
// ─────────────────────────────────────────────────────────────
const ScreenValutaCameriere = ({ target, onClose }) => {
  const w = target || { init: "AS", name: "Anna Silva", role: "Cameriere", tone: 3, venue: "Trattoria da Gino", day: "Sab 08 nov", time: "19:00–00:30" };
  const [stars, setStars] = React.useState(0);
  const [hover, setHover] = React.useState(0);
  const [picked, setPicked] = React.useState(new Set());
  const [note, setNote] = React.useState("");
  const [done, setDone] = React.useState(false);

  const meritBadges = ["VELOCE", "CORTESE", "PUNTUALE", "VINO", "MULTI", "GENTILE", "EVENTI", "COCKTAIL"];
  const ratingLabels = ["", "Insufficiente", "Sotto le attese", "Nella media", "Ottimo turno", "Eccellente"];
  const toggleBadge = (b) => {
    const n = new Set(picked);
    n.has(b) ? n.delete(b) : n.add(b);
    setPicked(n);
  };
  const submit = () => {
    if (!stars) { showToast("Assegna almeno una valutazione", "alert"); return; }
    setDone(true);
    showToast(`Valutazione inviata · ${w.name.split(" ")[0]} è stato avvisato`, "check");
  };

  if (done) {
    return (
      <div className="screen-enter" style={{ padding: "8px 24px 40px", color: "var(--t-1)", height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center" }}>
        <div style={{ width: 110, height: 110, borderRadius: 999, marginBottom: 24, background: "radial-gradient(circle, var(--gold-glow), transparent 70%)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div className="gold-pulse" style={{ width: 80, height: 80, borderRadius: 999, background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="star" size={36} color="#1a1206" strokeWidth={2}/>
          </div>
        </div>
        <div className="mono" style={{ marginBottom: 10, color: "var(--gold)" }}>VALUTAZIONE VERIFICATA</div>
        <div className="serif" style={{ fontSize: 24, letterSpacing: "-0.02em", marginBottom: 12 }}>{stars}★ a {w.name}</div>
        <div style={{ fontSize: 13.5, color: "var(--t-3)", lineHeight: 1.55, maxWidth: 290, marginBottom: 28 }}>
          La tua valutazione è legata al turno reale di {w.day} e contribuisce alla <span style={{ color: "var(--gold)" }}>reputazione verificata</span> di {w.name.split(" ")[0]}.
        </div>
        <button onClick={onClose} className="btn-gold" style={{ width: "100%", maxWidth: 330, padding: 16, fontSize: 15.5 }}>Fatto</button>
      </div>
    );
  }

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 18px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="close" size={18} color="var(--t-2)" /></button>
        <div>
          <div className="mono" style={{ color: "var(--gold)" }}>TURNO COMPLETATO</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Valuta il professionista</div>
        </div>
      </div>

      {/* Who + shift */}
      <div className="card" style={{ padding: 16, marginBottom: 18, display: "flex", alignItems: "center", gap: 13 }}>
        <Avatar initials={w.init} size={48} ring tone={w.tone} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 15.5, fontWeight: 600 }}>{w.name}</div>
          <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{w.role} · {w.venue}</div>
          <div className="mono" style={{ marginTop: 4 }}>{w.day} · {w.time}</div>
        </div>
      </div>

      {/* Stars */}
      <div className="mono" style={{ marginBottom: 10 }}>La tua valutazione</div>
      <div className="card" style={{ padding: "18px 16px", marginBottom: 18, textAlign: "center" }}>
        <div style={{ display: "flex", justifyContent: "center", gap: 8, marginBottom: 10 }}>
          {[1, 2, 3, 4, 5].map(n => (
            <button key={n} onClick={() => setStars(n)} onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(0)}
              style={{ background: "transparent", border: 0, cursor: "pointer", padding: 2, lineHeight: 0 }}>
              <Icon name="star" size={34} color={(hover || stars) >= n ? "var(--gold)" : "var(--t-4)"} strokeWidth={1.6} />
            </button>
          ))}
        </div>
        <div style={{ fontSize: 13, fontWeight: 600, color: stars ? "var(--gold)" : "var(--t-4)", minHeight: 18 }}>
          {ratingLabels[hover || stars] || "Tocca le stelle"}
        </div>
      </div>

      {/* Merit badges */}
      <div className="mono" style={{ marginBottom: 10 }}>Riconosci i punti di forza · facoltativo</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 18 }}>
        {meritBadges.map(b => (
          <Pill key={b} small active={picked.has(b)} gold={picked.has(b)} onClick={() => toggleBadge(b)}>{b}</Pill>
        ))}
      </div>

      {/* Note */}
      <div className="mono" style={{ marginBottom: 10 }}>Nota privata al profilo · facoltativa</div>
      <textarea value={note} onChange={e => setNote(e.target.value)} rows={3}
        placeholder="Es. ottimo con i tavoli in evento, riconvocabile."
        style={{ ...inputStyle, resize: "vertical", marginBottom: 16 }} />

      {/* Trust note */}
      <div className="card-2" style={{ padding: "12px 14px", marginBottom: 18, display: "flex", gap: 10 }}>
        <Icon name="shield2" size={17} color="var(--pos)" />
        <div style={{ fontSize: 11.5, color: "var(--t-2)", lineHeight: 1.5 }}>
          Valutazione <span style={{ color: "var(--t-1)" }}>verificata dal turno</span>: vale solo perché {w.name.split(" ")[0]} ha davvero lavorato da te. Niente recensioni anonime.
        </div>
      </div>

      <button onClick={submit} className="btn-gold" style={{ width: "100%", padding: 16, fontSize: 15, opacity: stars ? 1 : 0.5 }}>
        Invia valutazione
      </button>
    </div>
  );
};

Object.assign(window, { ScreenTrovaTurni, ScreenMieCandidature, ScreenValutaCameriere, shiftMatch });
