// Aura — Screens part 1: Dashboard, Profilo, Messaggi

// ─────────────────────────────────────────────────────────────
// SCREEN 1 — DASHBOARD
// ─────────────────────────────────────────────────────────────
const ScreenDashboard = ({ onOpenReview, onOpenSettings, onSwitchRole, onOpenWallet, onOpenQR, onOpenNotifiche, onOpenTurno, onOpenAgenda, onOpenTurni, fresh, onPopulate }) => {
  const goal = 3000;
  const earned = 2450;
  const pct = Math.min(100, earned / goal * 100);

  const TopBar = (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "4px 0 18px" }}>
      <div>
        <div style={{ marginBottom: 6 }}>
          <RoleChip role="waiter" onSwitch={onSwitchRole} />
        </div>
        <div className="serif" style={{ fontSize: 22, color: "var(--t-1)", letterSpacing: "-0.01em", fontFamily: "Inter" }}>
          Ciao, Marco
        </div>
        <div className="mono" style={{ marginTop: 4 }}>Mer 12 Nov · Chef de Rang</div>
      </div>
      <div style={{ display: "flex", gap: 10 }}>
        <button onClick={onOpenNotifiche} aria-label="notifiche" style={iconBtn}>
          <Icon name="bell" size={20} color="var(--t-2)" />
          {!fresh && <span style={{
            position: "absolute", top: 8, right: 8, width: 6, height: 6, borderRadius: 999,
            background: "var(--gold)", boxShadow: "0 0 6px var(--gold-glow)"
          }} />}
        </button>
        <button onClick={onOpenSettings} aria-label="impostazioni" style={iconBtn}>
          <Icon name="gear" size={20} color="var(--t-2)" />
        </button>
      </div>
    </div>
  );

  if (fresh) {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
        {TopBar}
        <FreshBanner onPopulate={onPopulate} />

        {/* Empty earnings */}
        <div className="card" style={{ padding: "22px 22px 20px", marginBottom: 14 }}>
          <div className="mono" style={{ marginBottom: 8 }}>Guadagno · Novembre</div>
          <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontSize: 60, fontWeight: 600, lineHeight: 0.95, letterSpacing: "-0.035em", color: "var(--t-4)" }}>€&thinsp;0</div>
          <div style={{ fontSize: 13, color: "var(--t-3)", marginTop: 12, lineHeight: 1.5 }}>
            Il tuo primo turno comparirà qui. Completa un servizio per iniziare a guadagnare.
          </div>
        </div>

        {/* First steps */}
        <div className="mono" style={{ marginBottom: 10, marginTop: 8 }}>Primi passi</div>
        <div className="card" style={{ overflow: "hidden", marginBottom: 22 }}>
          {[
            { ic: "qr", t: "Mostra il tuo QR", s: "Fatti recensire dal primo cliente", act: onOpenQR },
            { ic: "search", t: "Trova un turno", s: "Esplora i locali in zona", act: onPopulate },
            { ic: "doc", t: "Carica le certificazioni", s: "Sblocca i primi badge", act: onOpenSettings },
          ].map((r, i, arr) => (
            <div key={i} onClick={r.act} className="tap" style={{
              display: "flex", alignItems: "center", gap: 12, padding: "14px 16px",
              borderBottom: i === arr.length - 1 ? "none" : "1px solid var(--hair)",
            }}>
              <div style={{ width: 34, height: 34, borderRadius: 9, background: "rgba(255,200,90,0.08)", border: "1px solid oklch(0.81 0.115 82 / 0.3)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icon name={r.ic} size={17} color="var(--gold)"/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{r.t}</div>
                <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{r.s}</div>
              </div>
              <Icon name="chevR" size={16} color="var(--t-4)"/>
            </div>
          ))}
        </div>

        <EmptyState icon="star" title="Nessuna recensione ancora"
          body="Mostra il QR ai tuoi clienti a fine servizio: ogni recensione verificata fa crescere la tua Aura."
          cta="Apri il mio QR" onCta={onOpenQR} />
      </div>
    );
  }

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      {/* top bar */}
      {TopBar}

      {/* HERO — guadagno mese */}
      <div className="card" style={{ padding: "22px 22px 20px", marginBottom: 14, position: "relative", overflow: "hidden" }}>
        <div style={{
          position: "absolute", inset: 0, pointerEvents: "none",
          background: "radial-gradient(ellipse at 80% -10%, var(--gold-glow), transparent 55%)"
        }} />
        <div style={{ position: "relative" }}>
          <div className="mono" style={{ marginBottom: 8 }}>Guadagno · Novembre</div>
          <div className="gold-shimmer numeric" style={{
            fontFamily: "var(--f-ui)", fontSize: 60, fontWeight: 600, lineHeight: 0.95, letterSpacing: "-0.035em"
          }}>
            €&thinsp;2.450
          </div>
          <div style={{
            display: "flex", alignItems: "center", gap: 8, marginTop: 12, color: "var(--t-2)", fontSize: 13.5
          }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "var(--pos)", fontWeight: 600 }}>
              <Icon name="arrowUp" size={13} strokeWidth={2.2} /> 18%
            </span>
            <span>vs Ottobre · obiettivo €&thinsp;3.000</span>
          </div>

          {/* progress */}
          <div style={{ marginTop: 18 }}>
            <div style={{
              height: 6, borderRadius: 999, background: "rgba(255,255,255,0.06)", overflow: "hidden"
            }}>
              <div style={{
                height: "100%", width: `${pct}%`,
                background: "linear-gradient(90deg, var(--gold-2), var(--gold))",
                borderRadius: 999,
                boxShadow: "0 0 12px var(--gold-glow)"
              }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
              <span className="mono">{Math.round(pct)}% Obiettivo</span>
              <span className="mono" style={{ color: "var(--t-2)" }}>+ €&thinsp;550 mancano</span>
            </div>
          </div>
        </div>
      </div>

      {/* Wallet quick-view */}
      <div style={{ marginBottom: 14 }}>
        <WalletCard onTransfer={onOpenWallet} onOpen={onOpenWallet} />
      </div>

      {/* Turno di oggi — live entry */}
      <button onClick={() => onOpenTurno({ day: "OGGI", time: "19:00–00:00", venue: "Trattoria da Gino", role: "Chef de Rang", est: "€ 150" })}
        className="card gold-pulse" style={{
        display: "block", textAlign: "left", width: "100%", cursor: "pointer", color: "var(--t-1)",
        padding: "16px 18px", marginBottom: 14,
        background: "linear-gradient(135deg, oklch(0.24 0.020 75) 0%, oklch(0.18 0.014 65) 100%)",
        borderColor: "var(--gold)", borderWidth: 1.5,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 44, height: 44, borderRadius: 12, flexShrink: 0,
            background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Icon name="clock" size={22} color="#1a1206"/>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="mono" style={{ color: "var(--gold)", marginBottom: 3 }}>TURNO DI OGGI · 19:00</div>
            <div style={{ fontSize: 15, fontWeight: 600 }}>Trattoria da Gino</div>
            <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>Chef de Rang · check-in disponibile</div>
          </div>
          <Icon name="chevR" size={18} color="var(--gold)"/>
        </div>
      </button>

      {/* Next payout */}
      <div onClick={onOpenWallet} className="card tap" style={{ padding: "16px 18px", marginBottom: 14, display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{
          width: 42, height: 42, borderRadius: 12,
          background: "linear-gradient(135deg, oklch(0.30 0.04 60), oklch(0.20 0.03 50))",
          display: "flex", alignItems: "center", justifyContent: "center",
          border: "1px solid var(--hair-2)"
        }}>
          <Icon name="euro" size={20} color="var(--gold)" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 15, fontWeight: 600 }}>Saldo turno · €&thinsp;185</span>
            <span style={{
              fontFamily: "var(--f-mono)", fontSize: 9, padding: "2px 6px", borderRadius: 4,
              background: "rgba(255,200,90,0.10)", color: "var(--gold)", letterSpacing: "0.12em"
            }}>IN ARRIVO</span>
          </div>
          <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 3 }}>
            Trattoria da Gino · entro 48h
          </div>
        </div>
        <Icon name="chevR" size={18} color="var(--t-3)" />
      </div>

      {/* Turni aperti vicini — entry al mercato */}
      {(() => {
        const open = (window.AURA && window.AURA.openShifts) || [];
        if (!open.length) return null;
        const nearest = [...open].sort((a, b) => parseFloat(a.km.replace(",", ".")) - parseFloat(b.km.replace(",", ".")))[0];
        return (
          <button onClick={onOpenTurni} className="card tap" style={{
            display: "flex", alignItems: "center", gap: 14, padding: "16px 18px", marginBottom: 22, width: "100%", textAlign: "left", color: "var(--t-1)", cursor: "pointer",
            background: "linear-gradient(135deg, oklch(0.22 0.018 75) 0%, oklch(0.17 0.012 65) 100%)", borderColor: "oklch(0.81 0.115 82 / 0.30)",
          }}>
            <div style={{ width: 42, height: 42, borderRadius: 12, flexShrink: 0, background: "rgba(255,200,90,0.08)", border: "1px solid oklch(0.81 0.115 82 / 0.3)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon name="search" size={20} color="var(--gold)" />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{ fontSize: 15, fontWeight: 600 }}>{open.length} turni aperti vicini</span>
              </div>
              <div style={{ fontSize: 12.5, color: "var(--t-3)", marginTop: 3 }}>Il più vicino a {nearest.km} km · {nearest.role} · € {nearest.pay}</div>
            </div>
            <Icon name="chevR" size={18} color="var(--gold)" />
          </button>
        );
      })()}

      {/* Stat strip */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 22 }}>
        <StatCell value="4,8" sub="★ rating" tabular />
        <StatCell value="142" sub="servizi" />
        <StatCell value="6" sub="badge" />
      </div>

      {/* Living reviews — incoming */}
      <SectionHeader
        eyebrow="Recensioni · 3 nuove"
        title="Cosa dicono di te"
        action={<button onClick={onOpenReview} className="btn-ghost" style={{ padding: "8px 14px", fontSize: 12 }}>Anteprima cliente</button>} />
      
      <div className="card" style={{ padding: 18, marginBottom: 24 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 12 }}>
          {Array.from({ length: 5 }).map((_, i) =>
          <Icon key={i} name="star" size={16} color={i < 5 ? "var(--gold)" : "var(--t-4)"} />
          )}
          <span className="mono" style={{ marginLeft: 4 }}>scontrino #4821</span>
        </div>
        <div className="serif" style={{ fontSize: 17, lineHeight: 1.4, letterSpacing: "-0.005em" }}>
          “Marco ci ha consigliato il vino perfetto per la cena di anniversario. Servizio impeccabile, tempi giusti.”
        </div>
        <div style={{
          display: "flex", justifyContent: "space-between", alignItems: "center",
          marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--hair)"
        }}>
          <span className="mono" style={{ color: "var(--t-3)" }}>Famiglia C. · Mar 11/11</span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5, color: "var(--gold)", fontSize: 11 }}>
            <Verified size={13} /> Recensione verificata
          </span>
        </div>
      </div>

      {/* Prossimi turni */}
      <SectionHeader eyebrow="Agenda" title="Prossimi turni" action={<button onClick={onOpenAgenda} className="btn-ghost" style={{ padding: "8px 14px", fontSize: 12 }}>Agenda</button>} />
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
        <ShiftCard day="GIO 13" time="19:00–00:00" venue="Trattoria da Gino" role="Chef de Rang" est="€ 150" onClick={() => onOpenTurno({ day: "GIO 13", time: "19:00–00:00", venue: "Trattoria da Gino", role: "Chef de Rang", est: "€ 150" })} />
        <ShiftCard day="VEN 14" time="20:30–01:00" venue="Osteria Bartolomeo" role="Servizio Sala" est="€ 175" hot onClick={() => onOpenTurno({ day: "VEN 14", time: "20:30–01:00", venue: "Osteria Bartolomeo", role: "Servizio Sala", est: "€ 175" })} />
        <ShiftCard day="DOM 16" time="12:00–16:00" venue="Hotel Manin · Brunch" role="Maître Brunch" est="€ 120" onClick={() => onOpenTurno({ day: "DOM 16", time: "12:00–16:00", venue: "Hotel Manin · Brunch", role: "Maître Brunch", est: "€ 120" })} />
      </div>
    </div>);

};

const iconBtn = {
  width: 40, height: 40, borderRadius: 999,
  background: "rgba(255,255,255,0.04)",
  border: "1px solid var(--hair)",
  display: "flex", alignItems: "center", justifyContent: "center",
  cursor: "pointer", position: "relative"
};

const StatCell = ({ value, sub, tabular }) =>
<div className="card-2" style={{ padding: "14px 14px 12px" }}>
    <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontSize: 24, fontWeight: 600, lineHeight: 1, letterSpacing: "-0.02em", color: "var(--t-1)" }}>
      {value}
    </div>
    <div className="mono" style={{ marginTop: 6 }}>{sub}</div>
  </div>;


const ShiftCard = ({ day, time, venue, role, est, hot, onClick }) =>
<div onClick={onClick} className="card tap" style={{ padding: "14px 16px", display: "flex", alignItems: "center", gap: 14 }}>
    <div style={{
    width: 50, textAlign: "center", padding: "8px 0",
    border: `1px solid ${hot ? "var(--gold)" : "var(--hair-2)"}`, borderRadius: 12,
    background: hot ? "rgba(255,200,90,0.06)" : "transparent"
  }}>
      <div className="mono" style={{ fontSize: 9, color: hot ? "var(--gold)" : "var(--t-3)" }}>
        {day.split(" ")[0]}
      </div>
      <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontSize: 17, fontWeight: 700, marginTop: 2, color: "var(--t-1)", letterSpacing: "-0.01em" }}>
        {day.split(" ")[1]}
      </div>
    </div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 14.5, fontWeight: 600, color: "var(--t-1)" }}>{venue}</div>
      <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>
        {role} · {time}
      </div>
    </div>
    <div style={{ textAlign: "right" }}>
      <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontSize: 15, fontWeight: 700, color: "var(--gold)", letterSpacing: "-0.01em" }}>{est}</div>
      <div className="mono" style={{ fontSize: 8.5, color: "var(--t-3)", marginTop: 2 }}>stima</div>
    </div>
  </div>;


// ─────────────────────────────────────────────────────────────
// SCREEN 2 — PROFILO PRO (Living Resume)
// ─────────────────────────────────────────────────────────────
const ScreenProfilo = ({ onOpenSettings, onOpenContest, onOpenCertificazioni, fresh, onPopulate, onOpenQR }) => {
  const [tab, setTab] = React.useState("esperienze");

  if (fresh) {
    return (
      <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 0 18px" }}>
          <div className="mono">Profilo · Pubblico</div>
          <button onClick={onOpenSettings} style={iconBtn}>
            <Icon name="gear" size={20} color="var(--t-2)" />
          </button>
        </div>

        <FreshBanner onPopulate={onPopulate} />

        {/* Hero — new */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", marginBottom: 22 }}>
          <Avatar initials="MR" size={96} ring tone={0} />
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 16 }}>
            <span className="serif" style={{ fontSize: 28, lineHeight: 1, letterSpacing: "-0.02em" }}>Marco Rossi</span>
          </div>
          <div style={{ fontSize: 13.5, color: "var(--t-2)", marginTop: 6 }}>Chef de Rang · Milano</div>
          <div style={{ display: "flex", gap: 6, marginTop: 10, alignItems: "center" }}>
            <span className="mono" style={{ padding: "4px 10px", borderRadius: 999, background: "rgba(255,200,90,0.10)", border: "1px solid oklch(0.81 0.115 82 / 0.3)", color: "var(--gold)" }}>VERIFICA IN CORSO</span>
          </div>
        </div>

        {/* Badges all locked */}
        <div className="mono" style={{ marginBottom: 12 }}>Badge di eccellenza · 0 / 12</div>
        <div className="scroll" style={{ display: "flex", gap: 12, overflowX: "auto", paddingBottom: 4, marginBottom: 22, marginLeft: -20, marginRight: -20, padding: "4px 20px" }}>
          {["GENTILE", "VELOCE", "VINO", "COCKTAIL", "CORTESE", "MULTI"].map(b => (
            <Badge key={b} label={b} size={64} active={false} />
          ))}
        </div>

        <EmptyState icon="shield2" title="Costruisci la tua Aura"
          body="Non hai ancora recensioni o badge. Carica le certificazioni per sbloccare i primi badge subito, oppure fatti recensire dai clienti."
          cta="Carica certificazioni" onCta={onOpenCertificazioni} />

        <div style={{ marginTop: 12 }}>
          <button onClick={onOpenQR} className="btn-ghost" style={{ width: "100%", padding: 14, fontSize: 14 }}>
            Mostra il mio QR ai clienti
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      {/* top bar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 0 18px" }}>
        <div className="mono">Profilo · Pubblico</div>
        <button onClick={onOpenSettings} style={iconBtn}>
          <Icon name="gear" size={20} color="var(--t-2)" />
        </button>
      </div>

      {/* Hero */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", marginBottom: 22 }}>
        <Avatar initials="MR" size={96} ring tone={0} />
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 16 }}>
          <span className="serif" style={{ fontSize: 28, lineHeight: 1, letterSpacing: "-0.02em" }}>Marco Rossi</span>
          <Verified size={18} />
        </div>
        <div style={{ fontSize: 13.5, color: "var(--t-2)", marginTop: 6 }}>
          Chef de Rang · Milano
        </div>
        <div style={{ display: "flex", gap: 6, marginTop: 10, alignItems: "center" }}>
          <Icon name="star" size={13} color="var(--gold)" />
          <span className="numeric" style={{ fontSize: 13, fontWeight: 600 }}>4,8</span>
          <span style={{ color: "var(--t-4)" }}>·</span>
          <span style={{ fontSize: 12.5, color: "var(--t-3)" }}>142 recensioni verificate</span>
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 18 }}>
          <button onClick={() => showToast("Link al profilo copiato", "check")} className="btn-gold" style={{ padding: "11px 22px", fontSize: 13.5 }}>Condividi profilo</button>
          <button onClick={() => showToast("Apertura editor profilo\u2026", "user")} className="btn-ghost" style={{ padding: "11px 18px", fontSize: 13.5 }}>Modifica</button>
        </div>
      </div>

      {/* Badge row */}
      <div className="mono" style={{ marginBottom: 12 }}>Badge di eccellenza · 6 / 12</div>
      <div className="scroll" style={{
        display: "flex", gap: 12, overflowX: "auto", paddingBottom: 4, marginBottom: 26,
        marginLeft: -20, marginRight: -20, padding: "4px 20px"
      }}>
        <Badge label="GENTILE" size={64} />
        <Badge label="VELOCE" size={64} />
        <Badge label="VINO" size={64} />
        <Badge label="COCKTAIL" size={64} />
        <Badge label="CORTESE" size={64} />
        <Badge label="MULTI" size={64} />
        <Badge label="ISTRUITO" size={64} status="pending" />
        <Badge label="EVENTI" size={64} active={false} />
        <Badge label="VIP" size={64} active={false} />
      </div>

      {/* Tabs */}
      <div style={{
        display: "flex", gap: 4, padding: 4, background: "rgba(255,255,255,0.04)",
        borderRadius: 14, marginBottom: 18, border: "1px solid var(--hair)"
      }}>
        {[
        { id: "esperienze", label: "Esperienze" },
        { id: "recensioni", label: "Recensioni" },
        { id: "stats", label: "Statistiche" }].
        map((t) =>
        <button key={t.id} onClick={() => setTab(t.id)} style={{
          flex: 1, padding: "9px 8px", background: tab === t.id ? "rgba(255,255,255,0.08)" : "transparent",
          color: tab === t.id ? "var(--t-1)" : "var(--t-3)",
          border: 0, borderRadius: 10, fontSize: 12.5, fontWeight: 500,
          fontFamily: "var(--f-ui)", cursor: "pointer", transition: "all .15s ease"
        }}>{t.label}</button>
        )}
      </div>

      {/* Tab content */}
      {tab === "esperienze" && <ExperienceList onOpenCertificazioni={onOpenCertificazioni} />}
      {tab === "recensioni" && <ReviewList onOpenContest={onOpenContest} />}
      {tab === "stats" && <StatsView />}

      {/* Lingue + Specializzazioni */}
      <div className="mono" style={{ marginTop: 22, marginBottom: 10 }}>Competenze</div>
      <div className="card" style={{ padding: 16 }}>
        <Row label="Lingue parlate" value="IT · EN · FR · ES (base)" />
        <Row label="Specializzazioni" value="Vini naturali, Cocktail classici" />
        <Row label="Esperienza" value="6 anni · Sala alta cucina" />
        <Row label="Documenti" value="HACCP · Antincendio · Verificati" last gold />
      </div>
    </div>);

};

const Row = ({ label, value, last, gold }) =>
<div style={{
  display: "flex", justifyContent: "space-between", alignItems: "center",
  padding: "12px 0", borderBottom: last ? "none" : "1px solid var(--hair)"
}}>
    <span style={{ color: "var(--t-3)", fontSize: 13 }}>{label}</span>
    <span style={{ color: gold ? "var(--gold)" : "var(--t-1)", fontSize: 13, fontWeight: 500, textAlign: "right" }}>{value}</span>
  </div>;


const ExperienceList = ({ onOpenCertificazioni }) =>
<div>
    {/* Certificazioni Ufficiali — entry point */}
    <button onClick={onOpenCertificazioni} className="card tap" style={{
    display: "flex", alignItems: "center", gap: 14, padding: 16, marginBottom: 18, width: "100%",
    background: "linear-gradient(135deg, oklch(0.22 0.020 75) 0%, oklch(0.17 0.012 65) 100%)",
    borderColor: "var(--gold)", borderWidth: 1, cursor: "pointer", textAlign: "left"
  }}>
      <div style={{
      width: 44, height: 44, borderRadius: 12, flexShrink: 0,
      background: "rgba(255,200,90,0.10)", border: "1px solid var(--gold)",
      display: "flex", alignItems: "center", justifyContent: "center"
    }}>
        <Icon name="shield2" size={20} color="var(--gold)" />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="mono" style={{ color: "var(--gold)", marginBottom: 3 }}>CERTIFICAZIONI UFFICIALI</div>
        <div style={{ fontSize: 14, fontWeight: 600, color: "var(--t-1)" }}>2 verificate · 1 in verifica · 3 da caricare</div>
        <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>Carica attestati per sbloccare badge senza recensioni</div>
      </div>
      <Icon name="chevR" size={18} color="var(--gold)" />
    </button>
    <div className="mono" style={{ marginBottom: 12 }}>Esperienze lavorative</div>
    {[
  { from: "2024", to: "oggi", venue: "Trattoria da Gino", role: "Chef de Rang", note: "Sala 32 coperti · cucina lombarda" },
  { from: "2022", to: "2024", venue: "Osteria Bartolomeo", role: "Cameriere di Sala", note: "180 servizi · evento privato Salone" },
  { from: "2020", to: "2022", venue: "Caffè Centrale", role: "Bartender", note: "Cocktail bar · stagione estiva Lago" }].
  map((e, i) =>
  <div key={i} style={{ display: "flex", gap: 14, paddingBottom: 16, marginBottom: 16, borderBottom: "1px solid var(--hair)" }}>
        <div style={{ flexShrink: 0, width: 60, paddingTop: 2 }}>
          <div className="mono numeric" style={{ color: "var(--gold)" }}>{e.from}</div>
          <div className="mono numeric" style={{ color: "var(--t-4)" }}>{e.to}</div>
        </div>
        <div style={{ flex: 1, paddingLeft: 14, borderLeft: "1px solid var(--hair-2)", position: "relative" }}>
          <div style={{
        position: "absolute", left: -4, top: 5, width: 7, height: 7, borderRadius: 99,
        background: "var(--gold)", boxShadow: "0 0 0 3px var(--bg-0)"
      }} />
          <div style={{ fontSize: 14.5, fontWeight: 600 }}>{e.venue}</div>
          <div style={{ fontSize: 12.5, color: "var(--t-2)", marginTop: 2 }}>{e.role}</div>
          <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 6 }}>{e.note}</div>
        </div>
      </div>
  )}
  </div>;


const ReviewList = ({ onOpenContest }) => {
  const reviews = [
  { id: 1, who: "Anna B.", when: "10/11", stars: 5, txt: "Conoscenza vini eccellente. Ha ricordato il nome del bambino dopo 2 ore.", chips: ["VINO", "GENTILE"], state: "idle" },
  { id: 2, who: "Tavolo 18", when: "08/11", stars: 5, txt: "Servizio rapido senza essere frettoloso. Tornerò.", chips: ["VELOCE", "CORTESE"], state: "idle" },
  { id: 3, who: "Anonimo", when: "07/11", stars: 1, txt: "Servizio pessimo, il cameriere era assente e sgarbato. Non torno più.", chips: [], state: "pending" },
  { id: 4, who: "G. e M.", when: "05/11", stars: 4, txt: "Bravo, anche se la pausa tra primo e secondo è stata lunga.", chips: ["GENTILE"], state: "idle" }];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {reviews.map((r) =>
      <div key={r.id} className="card" style={{
        padding: 16,
        borderColor: r.state === "pending" ? "oklch(0.78 0.140 50 / 0.40)" : undefined,
        background: r.state === "pending" ? "oklch(0.78 0.140 50 / 0.04)" : undefined
      }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <div style={{ display: "flex", gap: 2 }}>
              {Array.from({ length: 5 }).map((_, j) =>
            <Icon key={j} name="star" size={12} color={j < r.stars ? "var(--gold)" : "var(--t-4)"} />
            )}
            </div>
            <span className="mono">{r.who} · {r.when}</span>
          </div>
          <div className="serif" style={{ fontSize: 14.5, lineHeight: 1.4, color: r.state === "pending" ? "var(--t-2)" : "var(--t-1)" }}>“{r.txt}”</div>
          <div style={{ display: "flex", gap: 6, marginTop: 12, alignItems: "center", justifyContent: "space-between", flexWrap: "wrap" }}>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {r.chips.map((c) => <Pill key={c} small active>{c}</Pill>)}
            </div>
            <ContestBadge state={r.state} onClick={() => onOpenContest && onOpenContest(r)} />
          </div>
        </div>
      )}
    </div>);

};

const StatsView = () =>
<div>
    <div className="card" style={{ padding: 18, marginBottom: 10 }}>
      <div className="mono" style={{ marginBottom: 12 }}>Andamento rating · 12 mesi</div>
      <Sparkline values={[4.3, 4.4, 4.5, 4.5, 4.6, 4.6, 4.7, 4.6, 4.7, 4.8, 4.8, 4.8]} />
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
        <span className="mono">Dic</span><span className="mono">Nov</span>
      </div>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
      <StatCell value="98%" sub="puntualità" />
      <StatCell value="2,4 min" sub="tempo medio risp" />
      <StatCell value="€ 24,5" sub="mancia media" />
      <StatCell value="0" sub="reclami 90gg" />
    </div>
  </div>;


const Sparkline = ({ values }) => {
  const max = Math.max(...values),min = Math.min(...values);
  const w = 320,h = 60;
  const pts = values.map((v, i) => {
    const x = i / (values.length - 1) * w;
    const y = h - (v - min) / (max - min || 1) * (h - 6) - 3;
    return [x, y];
  });
  const d = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0]},${p[1]}`).join(" ");
  const area = d + ` L${w},${h} L0,${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" height={h} preserveAspectRatio="none">
      <defs>
        <linearGradient id="gs" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="var(--gold)" stopOpacity="0.35" />
          <stop offset="100%" stopColor="var(--gold)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#gs)" />
      <path d={d} fill="none" stroke="var(--gold)" strokeWidth="1.5" strokeLinecap="round" />
      {pts.map((p, i) => i === pts.length - 1 &&
      <circle key={i} cx={p[0]} cy={p[1]} r="3.5" fill="var(--gold)" />
      )}
    </svg>);

};

// ─────────────────────────────────────────────────────────────
// SCREEN 3 — MESSAGGI
// ─────────────────────────────────────────────────────────────
const ScreenMessaggi = ({ onOpenChat }) => {
  const [q, setQ] = React.useState("");
  const [filter, setFilter] = React.useState("TUTTI");

  const allConvos = [
  { id: 1, name: "Trattoria da Gino · Coord. turni", preview: "Sara: confermi sabato 19:00? Coperti previsti 48.", time: "21:04", unread: 2, group: true, pinned: true, initials: "TG", tone: 0, cat: "TURNI" },
  { id: 2, name: "Sara M. · Sommelier Hub", preview: "Mi serviresti per evento privato 22/11 — cosa ne dici?", time: "20:11", unread: 1, initials: "SM", tone: 4, cat: "COLLEGHI" },
  { id: 3, name: "Evento Privato · 22 nov", preview: "Manager: brief alle 18, divisa nera. Conferma 3 di 5.", time: "18:42", unread: 0, group: true, initials: "EP", tone: 1, cat: "EVENTI" },
  { id: 4, name: "Osteria Bartolomeo · HR", preview: "Hai inviato 3 documenti — verifica completata.", time: "ier", unread: 0, verified: true, initials: "OB", tone: 3, cat: "LOCALI" },
  { id: 5, name: "Luca T. · Chef de Rang", preview: "Mi sostituisci venerdì? Pago io la cena.", time: "ier", unread: 0, initials: "LT", tone: 2, cat: "COLLEGHI" },
  { id: 6, name: "Hotel Manin · Eventi", preview: "Ti contattiamo per la stagione natalizia.", time: "Lun", unread: 0, initials: "HM", tone: 5, cat: "EVENTI" }];

  const convos = allConvos.filter((c) =>
  (filter === "TUTTI" || c.cat === filter) && (
  c.name.toLowerCase().includes(q.toLowerCase()) || c.preview.toLowerCase().includes(q.toLowerCase())));

  const pinned = convos.filter((c) => c.pinned);
  const rest = convos.filter((c) => !c.pinned);

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 0 18px" }}>
        <div>
          <div className="mono" style={{ marginBottom: 2 }}>3 NON LETTI</div>
          <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.02em" }}>Messaggi</div>
        </div>
        <button onClick={() => showToast("Nuova conversazione", "chat")} style={iconBtn}><Icon name="plus" size={20} color="var(--t-2)" /></button>
      </div>

      {/* Search */}
      <div style={{
        background: "var(--bg-1)", border: "1px solid var(--hair)", borderRadius: 14,
        display: "flex", alignItems: "center", gap: 10, padding: "11px 14px", marginBottom: 14
      }}>
        <Icon name="search" size={17} color="var(--t-3)" />
        <input value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="Cerca conversazioni, locali, persone…"
        style={{
          flex: 1, background: "transparent", border: 0, outline: "none",
          color: "var(--t-1)", fontSize: 14, fontFamily: "var(--f-ui)"
        }} />
      </div>

      {/* Quick filter */}
      <div style={{ display: "flex", gap: 8, marginBottom: 18, overflowX: "auto" }} className="scroll">
        {["TUTTI", "TURNI", "EVENTI", "LOCALI", "COLLEGHI"].map((f) =>
        <Pill key={f} small active={filter === f} gold={filter === f} onClick={() => setFilter(f)}>{f}</Pill>
        )}
      </div>

      {pinned.length > 0 &&
      <>
          <div className="mono" style={{ marginBottom: 10 }}>In evidenza</div>
          <div className="card" style={{ marginBottom: 18, overflow: "hidden" }}>
            {pinned.map((c, i) => <ConvoRow key={c.id} c={c} last={i === pinned.length - 1} onClick={() => onOpenChat(c)} />)}
          </div>
        </>
      }

      <div className="mono" style={{ marginBottom: 10 }}>Recenti</div>
      <div className="card" style={{ overflow: "hidden" }}>
        {rest.length === 0 ?
        <div style={{ padding: "28px 16px", textAlign: "center" }}>
          <div className="mono" style={{ color: "var(--t-4)" }}>Nessuna conversazione in « {filter} »</div>
        </div> :
        rest.map((c, i) => <ConvoRow key={c.id} c={c} last={i === rest.length - 1} onClick={() => onOpenChat(c)} />)}
      </div>
    </div>);

};

const ConvoRow = ({ c, last, onClick }) =>
<div onClick={onClick} className="tap" style={{
  display: "flex", alignItems: "center", gap: 12, padding: "13px 16px",
  borderBottom: last ? "none" : "1px solid var(--hair)"
}}>
    <Avatar initials={c.initials} size={44} tone={c.tone} />
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 5, minWidth: 0 }}>
          <span style={{
          fontSize: 14, fontWeight: c.unread ? 600 : 500,
          color: c.unread ? "var(--t-1)" : "var(--t-2)",
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap"
        }}>{c.name}</span>
          {c.verified && <Verified size={12} />}
        </div>
        <span style={{ fontSize: 11, color: c.unread ? "var(--gold)" : "var(--t-4)", flexShrink: 0, fontWeight: c.unread ? 600 : 400 }}>{c.time}</span>
      </div>
      <div style={{
      fontSize: 12.5, color: c.unread ? "var(--t-2)" : "var(--t-4)",
      marginTop: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap"
    }}>
        {c.preview}
      </div>
    </div>
    {c.unread > 0 &&
  <div style={{
    width: 20, height: 20, borderRadius: 999, background: "var(--gold)",
    color: "#1a1206", fontSize: 11, fontWeight: 700,
    display: "flex", alignItems: "center", justifyContent: "center"
  }}>{c.unread}</div>
  }
  </div>;


Object.assign(window, {
  ScreenDashboard, ScreenProfilo, ScreenMessaggi, iconBtn
});