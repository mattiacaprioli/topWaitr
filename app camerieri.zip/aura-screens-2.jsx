// Aura — Screens part 2: Mercato Talenti, Piani Pro, Impostazioni, Recensione QR

// ─────────────────────────────────────────────────────────────
// SCREEN 4 — MERCATO TALENTI
// ─────────────────────────────────────────────────────────────
const ScreenMercato = ({ onOpenTalent }) => {
  const [role, setRole] = React.useState("SOMMELIER");
  const [city, setCity] = React.useState("Milano");
  const [view, setView] = React.useState("mappa"); // mappa | lista
  const [selectedPin, setSelectedPin] = React.useState(null);

  const roles = ["SOMMELIER", "MIXOLOGIST", "CHEF DE RANG", "RUNNER", "HOSTESS"];

  const talents = [
  { id: 1, init: "GR", name: "Giulia Romano", role: "Sommelier", rating: 4.9, badges: ["VINO", "GENTILE"], avail: "Sab", x: 28, y: 32, tone: 4 },
  { id: 2, init: "FT", name: "Federico Turi", role: "Sommelier · AIS", rating: 4.8, badges: ["VINO", "CORTESE"], avail: "Oggi", x: 58, y: 22, tone: 1 },
  { id: 3, init: "LM", name: "Lucia Marchi", role: "Sommelier", rating: 4.7, badges: ["VINO", "EVENTI"], avail: "Lun", x: 72, y: 48, tone: 5 },
  { id: 4, init: "DS", name: "Davide Stoppa", role: "Sommelier", rating: 4.7, badges: ["VINO"], avail: "Mer", x: 40, y: 64, tone: 3 },
  { id: 5, init: "EC", name: "Elisa Conte", role: "Sommelier · AIS", rating: 4.9, badges: ["VINO", "MULTI"], avail: "Ven", x: 22, y: 76, tone: 0 },
  { id: 6, init: "PA", name: "Paolo Amato", role: "Sommelier", rating: 4.6, badges: ["VINO"], avail: "Sab", x: 64, y: 78, tone: 2 }];


  return (
    <div className="screen-enter" style={{ color: "var(--t-1)" }}>
      {/* Header */}
      <div style={{ padding: "8px 20px 14px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 0 18px" }}>
          <div>
            <div className="mono" style={{ marginBottom: 2 }}>Mercato Talenti</div>
            <div className="serif" style={{ fontSize: 26, letterSpacing: "-0.02em", fontFamily: "Inter" }}>Scopri</div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setView(view === "mappa" ? "lista" : "mappa")} className="btn-ghost" style={{ padding: "8px 14px", fontSize: 11.5 }}>
              {view === "mappa" ? "Lista" : "Mappa"}
            </button>
            <button onClick={() => showToast("Filtri avanzati", "filter")} style={iconBtn}><Icon name="filter" size={20} color="var(--t-2)" /></button>
          </div>
        </div>

        {/* Location */}
        <div style={{
          display: "flex", alignItems: "center", gap: 8, padding: "10px 14px",
          background: "var(--bg-1)", border: "1px solid var(--hair)", borderRadius: 14, marginBottom: 12
        }}>
          <Icon name="pin" size={16} color="var(--gold)" />
          <span style={{ fontSize: 13, color: "var(--t-2)" }}>Vicino a</span>
          <span style={{ fontSize: 14, fontWeight: 600, color: "var(--t-1)" }}>{city}</span>
          <span className="mono" style={{ marginLeft: "auto" }}>15 KM</span>
        </div>

        {/* Role chips */}
        <div className="scroll" style={{ display: "flex", gap: 8, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20, paddingBottom: 4 }}>
          {roles.map((r) =>
          <Pill key={r} active={role === r} gold={role === r} onClick={() => setRole(r)}>{r}</Pill>
          )}
        </div>
      </div>

      {view === "mappa" &&
      <MapView talents={talents} selected={selectedPin} onSelect={setSelectedPin} role={role} />
      }
      {view === "lista" &&
      <div style={{ padding: "0 20px 130px" }}>
          <div className="mono" style={{ marginBottom: 12 }}>{talents.length} talenti · {role} · {city}</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {talents.map((t) => <TalentCard key={t.id} t={t} onClick={() => onOpenTalent(t)} />)}
          </div>
        </div>
      }
    </div>);

};

const MapView = ({ talents, selected, onSelect, role }) =>
<div style={{ position: "relative", margin: "0 20px 130px", height: 460, borderRadius: 22, overflow: "hidden", border: "1px solid var(--hair)" }}>
    {/* Abstract city map background */}
    <div style={{
    position: "absolute", inset: 0,
    background: "linear-gradient(180deg, oklch(0.22 0.014 65), oklch(0.16 0.012 60))"
  }} />
    <svg viewBox="0 0 320 460" width="100%" height="100%" style={{ position: "absolute", inset: 0 }} preserveAspectRatio="none">
      {/* streets */}
      <g stroke="rgba(255,240,220,0.06)" strokeWidth="1.2" fill="none">
        <path d="M0 80 L320 100" />
        <path d="M0 180 L320 200" />
        <path d="M0 290 L320 270" />
        <path d="M0 380 L320 400" />
        <path d="M70 0 L80 460" />
        <path d="M150 0 L170 460" />
        <path d="M240 0 L230 460" />
      </g>
      <g stroke="rgba(255,240,220,0.04)" strokeWidth="0.8" fill="none">
        <path d="M0 40 L320 50" />
        <path d="M0 130 L320 140" />
        <path d="M0 230 L320 220" />
        <path d="M0 340 L320 350" />
        <path d="M30 0 L40 460" />
        <path d="M110 0 L120 460" />
        <path d="M200 0 L210 460" />
        <path d="M280 0 L290 460" />
      </g>
      {/* park */}
      <rect x="180" y="240" width="80" height="60" rx="8" fill="rgba(120, 180, 100, 0.04)" stroke="rgba(120, 180, 100, 0.10)" />
      <text x="220" y="275" textAnchor="middle" fontSize="9" fill="rgba(255,240,220,0.18)" fontFamily="var(--f-mono)" letterSpacing="2">PARCO</text>
    </svg>

    {/* User location */}
    <div style={{
    position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)",
    width: 16, height: 16, borderRadius: 999, background: "var(--gold)",
    border: "3px solid var(--bg-1)", boxShadow: "0 0 0 8px oklch(0.81 0.115 82 / 0.18)", zIndex: 4
  }} />

    {/* Pins */}
    {talents.map((t) =>
  <button key={t.id} onClick={() => onSelect(t.id === selected ? null : t.id)}
  style={{
    position: "absolute", left: `${t.x}%`, top: `${t.y}%`,
    transform: `translate(-50%, -100%) ${selected === t.id ? "scale(1.1)" : "scale(1)"}`,
    background: "transparent", border: 0, cursor: "pointer", zIndex: selected === t.id ? 10 : 5,
    transition: "transform .15s ease"
  }}>
        <div style={{
      background: "var(--bg-2)", border: `1.5px solid ${selected === t.id ? "var(--gold)" : "var(--hair-2)"}`,
      borderRadius: 999, padding: "5px 5px 5px 5px",
      display: "flex", alignItems: "center", gap: 7, paddingRight: 12,
      boxShadow: "0 8px 20px rgba(0,0,0,0.45)",
      minWidth: selected === t.id ? 0 : "auto"
    }}>
          <Avatar initials={t.init} size={28} tone={t.tone} />
          <span style={{ fontSize: 11.5, fontWeight: 600, color: "var(--t-1)", display: "flex", alignItems: "center", gap: 4 }}>
            <Icon name="star" size={11} color="var(--gold)" />{t.rating}
          </span>
        </div>
        <div style={{
      width: 2, height: 8, background: selected === t.id ? "var(--gold)" : "var(--hair-2)",
      margin: "0 auto"
    }} />
      </button>
  )}

    {/* Selected pin card */}
    {selected && (() => {
    const t = talents.find((x) => x.id === selected);
    return (
      <div className="modal-enter" style={{
        position: "absolute", left: 12, right: 12, bottom: 12, zIndex: 20,
        background: "var(--bg-1)", border: "1px solid var(--hair-2)", borderRadius: 18,
        padding: 14, display: "flex", alignItems: "center", gap: 12,
        boxShadow: "0 16px 36px rgba(0,0,0,0.5)"
      }}>
          <Avatar initials={t.init} size={48} tone={t.tone} ring />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontSize: 14.5, fontWeight: 600 }}>{t.name}</span>
              <Verified size={12} />
            </div>
            <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{t.role} · disp. {t.avail}</div>
            <div style={{ display: "flex", gap: 4, marginTop: 6 }}>
              {t.badges.map((b) => <Pill key={b} small active>{b}</Pill>)}
            </div>
          </div>
          <button onClick={() => showToast(`Richiesta inviata a ${t.name.split(" ")[0]}`, "send")} className="btn-gold" style={{ padding: "10px 14px", fontSize: 12 }}>Contatta</button>
        </div>);

  })()}

    {/* count overlay top-left */}
    <div style={{
    position: "absolute", top: 12, left: 12,
    background: "rgba(20, 16, 12, 0.78)",
    backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
    border: "1px solid var(--hair-2)", borderRadius: 999,
    padding: "7px 13px"
  }}>
      <span className="mono" style={{ color: "var(--gold)" }}>{talents.length} talenti</span>
      <span className="mono" style={{ color: "var(--t-3)", marginLeft: 6 }}>· certificati</span>
    </div>
  </div>;


const TalentCard = ({ t, onClick }) =>
<div onClick={onClick} className="card tap" style={{ padding: 14, display: "flex", alignItems: "center", gap: 12 }}>
    <Avatar initials={t.init} size={52} tone={t.tone} ring />
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{ fontSize: 14.5, fontWeight: 600 }}>{t.name}</span>
        <Verified size={12} />
      </div>
      <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{t.role}</div>
      <div style={{ display: "flex", gap: 4, marginTop: 8 }}>
        {t.badges.map((b) => <Pill key={b} small active>{b}</Pill>)}
      </div>
    </div>
    <div style={{ textAlign: "right" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 3, justifyContent: "flex-end" }}>
        <Icon name="star" size={12} color="var(--gold)" />
        <span style={{ fontSize: 13.5, fontWeight: 700 }}>{t.rating}</span>
      </div>
      <div className="mono" style={{ marginTop: 4 }}>disp. {t.avail}</div>
    </div>
  </div>;


// ─────────────────────────────────────────────────────────────
// SCREEN 5 — PIANI PRO
// ─────────────────────────────────────────────────────────────
const ScreenPiani = () => {
  const [side, setSide] = React.useState("pro"); // pro | resto
  const [billing, setBilling] = React.useState("year"); // month | year

  const proPlans = [
  {
    id: "base", name: "Base", priceM: "0", priceY: "0", free: true,
    tagline: "Costruisci la tua reputazione. Gratis, per sempre.",
    features: [
    ["Profilo Living Resume", true],
    ["Recensioni verificate via scontrino", true],
    ["3 Badge di merito", true],
    ["Candidature ai turni aperti", true],
    ["Partite intelligenti (matching)", false],
    ["Analisi performance", false],
    ["Profilo prioritario in ricerca", false]],

    cta: "Piano attuale", current: true
  },
  {
    id: "pro", name: "Pro", priceM: "9,90", priceY: "7,90", yearNote: "94,80 €/anno", featured: true,
    tagline: "Per chi vuole scalare nel settore.",
    features: [
    ["Tutto del piano Base", true],
    ["Recensioni e badge illimitati", true],
    ["Partite intelligenti (matching turni)", true],
    ["Analisi performance dettagliate", true],
    ["Profilo prioritario in ricerca", true],
    ["Prelievo istantaneo a tariffa ridotta", true]],

    cta: "Passa a Pro"
  },
  {
    id: "elite", name: "Elite", priceM: "24,90", priceY: "19,90", yearNote: "238,80 €/anno",
    tagline: "Per i top performer del settore.",
    features: [
    ["Tutto del piano Pro", true],
    ["Mentor 1:1 ogni mese", true],
    ["Eventi privati & top hotel", true],
    ["Prelievi istantanei sempre gratis", true],
    ["Concierge fiscale dedicato", true]],

    cta: "Diventa Elite"
  }];


  const restoPlans = [
  {
    id: "starter", name: "Starter", priceM: "0", priceY: "0", free: true,
    tagline: "Pubblica e ricevi candidature. Gratis.",
    features: [
    ["1 annuncio attivo", true],
    ["Ricezione candidature", true],
    ["QR recensioni clienti", true],
    ["Commissione servizio 10% sui turni", true],
    ["Accesso ai Top Talenti", false],
    ["Analisi sala in tempo reale", false]],

    cta: "Piano attuale", current: true
  },
  {
    id: "business", name: "Business", priceM: "49", priceY: "39", yearNote: "468 €/anno", featured: true,
    tagline: "Lo standard per locali professionali.",
    features: [
    ["Annunci illimitati", true],
    ["Commissione servizio ridotta al 6%", true],
    ["Accesso diretto ai Top Talenti", true],
    ["Gestione avanzata staff", true],
    ["Analisi sala in tempo reale", true],
    ["Verifica documenti automatica", true]],

    cta: "Passa a Business"
  },
  {
    id: "group", name: "Group", custom: true, priceM: "Su misura",
    tagline: "Per catene e gruppi.",
    features: [
    ["Tutto di Business", true],
    ["Commissione negoziata", true],
    ["Multi-locale (fino a 12)", true],
    ["Account Manager dedicato", true],
    ["API & integrazioni gestionali", true]],

    cta: "Contattaci"
  }];


  const plans = side === "pro" ? proPlans : restoPlans;

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ padding: "4px 0 20px", textAlign: "center" }}>
        <div className="mono" style={{ marginBottom: 6 }}>Piani Aura · 2026</div>
        <div className="serif" style={{ fontSize: 30, lineHeight: 1.1, letterSpacing: "-0.02em" }}>
          Trasforma il tuo lavoro<br />in un <em style={{ color: "var(--gold)", fontStyle: "italic" }}>asset.</em>
        </div>
      </div>

      {/* Audience toggle */}
      <div style={{
        display: "flex", gap: 4, padding: 4, background: "rgba(255,255,255,0.04)",
        borderRadius: 14, marginBottom: 12, border: "1px solid var(--hair)"
      }}>
        {[
        { id: "pro", label: "Professionista" },
        { id: "resto", label: "Ristoratore" }].
        map((t) =>
        <button key={t.id} onClick={() => setSide(t.id)} style={{
          flex: 1, padding: "11px 8px",
          background: side === t.id ? "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))" : "transparent",
          color: side === t.id ? "#1a1206" : "var(--t-3)",
          border: 0, borderRadius: 10, fontSize: 13, fontWeight: 600,
          fontFamily: "var(--f-ui)", cursor: "pointer", transition: "all .15s ease"
        }}>{t.label}</button>
        )}
      </div>

      {/* Billing period toggle */}
      <div style={{ display: "flex", justifyContent: "center", marginBottom: 20 }}>
        <div style={{ display: "inline-flex", gap: 4, padding: 4, background: "rgba(255,255,255,0.04)", borderRadius: 999, border: "1px solid var(--hair)" }}>
          {[
          { id: "month", label: "Mensile" },
          { id: "year", label: "Annuale" }].
          map((b) =>
          <button key={b.id} onClick={() => setBilling(b.id)} style={{
            display: "inline-flex", alignItems: "center", gap: 7,
            padding: "8px 16px", borderRadius: 999, border: 0, cursor: "pointer",
            fontFamily: "var(--f-ui)", fontSize: 12.5, fontWeight: 600,
            background: billing === b.id ? "rgba(255,255,255,0.10)" : "transparent",
            color: billing === b.id ? "var(--t-1)" : "var(--t-3)", transition: "all .15s ease"
          }}>
            {b.label}
            {b.id === "year" &&
            <span className="mono" style={{ fontSize: 8.5, padding: "2px 6px", borderRadius: 999, background: "oklch(0.80 0.140 150 / 0.16)", color: "var(--pos)", letterSpacing: "0.06em" }}>−20%</span>
            }
          </button>
          )}
        </div>
      </div>

      {/* Plan cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {plans.map((p) => <PlanCard key={p.id} p={p} billing={billing} />)}
      </div>

      {/* How Aura earns — transparency */}
      <div style={{
        marginTop: 22, padding: "16px 18px", borderRadius: 16,
        background: "linear-gradient(135deg, oklch(0.22 0.018 75) 0%, oklch(0.17 0.012 65) 100%)",
        border: "1px solid oklch(0.81 0.115 82 / 0.30)"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
          <Icon name="receipt" size={18} color="var(--gold)" />
          <div style={{ fontSize: 13, fontWeight: 600 }}>Come guadagna Aura</div>
        </div>
        <div style={{ fontSize: 12, color: "var(--t-2)", lineHeight: 1.55 }}>
          Oltre agli abbonamenti, applichiamo una piccola commissione di servizio solo sui turni effettivamente coperti. Così la <span style={{ color: "var(--t-1)" }}>reputazione resta gratis</span> e nessuno paga per ciò che non usa.
        </div>
      </div>

      {/* Guarantee strip */}
      <div style={{
        marginTop: 12, padding: "14px 18px", borderRadius: 16,
        background: "var(--bg-1)", border: "1px solid var(--hair)",
        display: "flex", alignItems: "center", gap: 12
      }}>
        <Icon name="shield2" size={22} color="var(--pos)" />
        <div style={{ fontSize: 12.5, color: "var(--t-2)", lineHeight: 1.5 }}>
          Cancelli quando vuoi. <span style={{ color: "var(--t-1)" }}>Garanzia 30 giorni</span>: rimborso completo se non sei soddisfatto.
        </div>
      </div>
    </div>);

};

const PlanCard = ({ p, billing }) => {
  const fc = p.featured ? "var(--gold)" : p.current ? "var(--hair-2)" : "var(--hair)";
  const annual = billing === "year";
  const priceVal = p.custom ? p.priceM : (annual ? p.priceY : p.priceM);
  const showEuro = !p.custom;
  return (
    <div className="card" style={{
      padding: "20px 20px 18px", borderColor: fc,
      borderWidth: p.featured ? 1.5 : 1,
      position: "relative", overflow: "hidden",
      background: p.featured ?
      "linear-gradient(180deg, oklch(0.23 0.022 72) 0%, oklch(0.17 0.013 65) 70%)" :
      "var(--bg-1)"
    }}>
      {p.featured &&
      <div style={{ position: "absolute", inset: 0, pointerEvents: "none", background: "radial-gradient(ellipse 70% 50% at 100% -10%, var(--gold-glow), transparent 60%)" }} />
      }
      <div style={{ position: "relative" }}>
        {p.featured &&
        <div style={{
          position: "absolute", top: -2, right: -2,
          padding: "4px 10px", borderRadius: 999,
          background: "var(--gold)", color: "#1a1206",
          fontFamily: "var(--f-mono)", fontSize: 9, letterSpacing: "0.12em", fontWeight: 700
        }}>PIÙ SCELTO</div>
        }
        <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em", marginBottom: 6 }}>{p.name}</div>

        <div style={{ display: "flex", alignItems: "baseline", gap: 4 }}>
          <span className={p.featured ? "gold-shimmer numeric" : "numeric"} style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: p.custom ? 24 : 32, letterSpacing: "-0.025em", color: p.featured ? undefined : "var(--t-1)" }}>
            {showEuro ? `€ ${priceVal}` : priceVal}
          </span>
          {showEuro && <span style={{ fontSize: 13, color: "var(--t-3)" }}>/mese</span>}
        </div>
        {!p.custom && !p.free && annual ?
        <div className="mono" style={{ marginTop: 4, color: "var(--pos)" }}>Fatturato {p.yearNote} · 2 mesi in regalo</div> :
        <div style={{ height: 15, marginTop: 4 }} />
        }

        <div style={{ fontSize: 13, color: "var(--t-2)", margin: "10px 0 16px" }}>{p.tagline}</div>

        <div style={{ display: "flex", flexDirection: "column", gap: 9, marginBottom: 18 }}>
          {p.features.map(([txt, on], i) =>
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 9, fontSize: 13, color: on ? "var(--t-1)" : "var(--t-4)" }}>
              <Icon name={on ? "check" : "close"} size={15} color={on ? p.featured ? "var(--gold)" : "var(--t-1)" : "var(--t-4)"} strokeWidth={on ? 2 : 1.6} />
              <span>{txt}</span>
            </div>
          )}
        </div>

        {p.current ?
        <button disabled style={{
          width: "100%", background: "transparent", border: "1px solid var(--hair-2)",
          color: "var(--t-3)", borderRadius: 999, padding: "12px",
          fontSize: 13, fontWeight: 500, cursor: "not-allowed"
        }}>{p.cta}</button> :

        <button onClick={() => showToast(p.custom ? "Richiesta inviata · ti contattiamo" : `Hai scelto il piano ${p.name}`, "check")} className={p.featured ? "btn-gold" : "btn-ghost"} style={{ width: "100%", padding: "13px" }}>
            {p.cta}
          </button>
        }
      </div>
    </div>);

};

// ─────────────────────────────────────────────────────────────
// SCREEN 6 — IMPOSTAZIONI
// ─────────────────────────────────────────────────────────────
const ScreenImpostazioni = ({ onBack, userRole = "waiter", onSwitchRole, onReplayOnboarding, onLogout }) => {
  const [push, setPush] = React.useState(true);
  const [biometric, setBiometric] = React.useState(true);
  const [autoshift, setAutoshift] = React.useState(false);

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "4px 0 22px" }}>
        <button onClick={onBack} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
        <div>
          <div className="mono">Account</div>
          <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Impostazioni</div>
        </div>
      </div>

      {/* Account card */}
      <div className="card" style={{ padding: 16, marginBottom: 18, display: "flex", alignItems: "center", gap: 14 }}>
        <Avatar initials="MR" size={52} ring tone={0} />
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 15, fontWeight: 600 }}>Marco Rossi</span>
            <Verified size={13} />
          </div>
          <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>marco.rossi@aura.app</div>
          <div className="mono" style={{ marginTop: 6, color: "var(--gold)" }}>Pro · scadenza 14/03/2026</div>
        </div>
      </div>

      <SettingGroup title="Modalità account">
        <div style={{ padding: "14px 16px" }}>
          <div style={{ fontSize: 13.5, fontWeight: 500, marginBottom: 4 }}>Visualizza Aura come</div>
          <div style={{ fontSize: 11.5, color: "var(--t-3)", marginBottom: 12 }}>Cambia tra profilo Cameriere e profilo Ristoratore</div>
          <div style={{ display: "flex", gap: 4, padding: 4, background: "rgba(255,255,255,0.04)", borderRadius: 12, border: "1px solid var(--hair)" }}>
            {[["waiter", "Cameriere"], ["manager", "Ristoratore"]].map(([id, lbl]) =>
            <button key={id} onClick={() => userRole !== id && onSwitchRole && onSwitchRole()} style={{
              flex: 1, padding: "10px 8px",
              background: userRole === id ? "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))" : "transparent",
              color: userRole === id ? "#1a1206" : "var(--t-2)",
              border: 0, borderRadius: 9, fontSize: 12.5, fontWeight: 600,
              fontFamily: "var(--f-ui)", cursor: "pointer", transition: "all .15s ease"
            }}>{lbl}</button>
            )}
          </div>
        </div>
      </SettingGroup>

      <SettingGroup title="Profilo">
        <SettingRow icon="user" label="Dati personali" detail="Marco Rossi · Milano" />
        <SettingRow icon="shield" label="Verifica identità" detail="Documento approvato" gold />
        <SettingRow icon="doc" label="Documenti professionali" detail="HACCP · Antincendio" />
        <SettingRow icon="lang" label="Lingua app" detail="Italiano" last />
      </SettingGroup>

      <SettingGroup title="Lavoro">
        <SettingRow icon="calendar" label="Disponibilità" detail="Lun–Sab · 17:00–01:00" />
        <SettingRow icon="euro" label="Compensi & fatturazione" detail="Iban verificato" />
        <SettingToggle label="Partite intelligenti" sub="Ricevi turni adatti al tuo profilo" value={autoshift} onChange={setAutoshift} />
        <SettingRow icon="receipt" label="Cronologia turni" last />
      </SettingGroup>

      <SettingGroup title="App">
        <SettingToggle label="Notifiche push" sub="Turni, recensioni, messaggi" value={push} onChange={setPush} />
        <SettingToggle label="Face ID / Touch ID" sub="Accesso protetto" value={biometric} onChange={setBiometric} last />
      </SettingGroup>

      <SettingGroup title="Supporto">
        <SettingRow icon="spark" label="Assistenza dedicata" detail="Riposta entro 2h · Pro" gold />
        <div onClick={() => window.open("Come Funziona.html", "_blank")} className="tap" style={{
          display: "flex", alignItems: "center", gap: 12, padding: "13px 16px", borderBottom: "1px solid var(--hair)",
        }}>
          <div style={{ width: 30, height: 30, borderRadius: 8, background: "rgba(255,255,255,0.04)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="shield2" size={16} color="var(--gold)"/>
          </div>
          <span style={{ flex: 1, fontSize: 14, color: "var(--t-1)" }}>Come funziona la verifica</span>
          <span style={{ fontSize: 11.5, color: "var(--t-3)", marginRight: 4 }}>Pagina</span>
          <Icon name="chevR" size={16} color="var(--t-4)"/>
        </div>
        <SettingRow icon="doc" label="Termini & Privacy" />
        <div onClick={onReplayOnboarding} className="tap" style={{
          display: "flex", alignItems: "center", gap: 12, padding: "13px 16px", borderBottom: "1px solid var(--hair)",
        }}>
          <div style={{ width: 30, height: 30, borderRadius: 8, background: "rgba(255,255,255,0.04)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="logo" size={16} color="var(--t-2)"/>
          </div>
          <span style={{ flex: 1, fontSize: 14, color: "var(--t-1)" }}>Rivedi onboarding</span>
          <Icon name="chevR" size={16} color="var(--t-4)"/>
        </div>
        <SettingRow icon="bell" label="Comunicazioni Aura" detail="2 nuove" last />
      </SettingGroup>

      <button onClick={onLogout} style={{
        width: "100%", marginTop: 14, padding: "14px",
        background: "transparent", color: "var(--neg)",
        border: "1px solid var(--hair)", borderRadius: 999,
        fontSize: 14, fontWeight: 500, cursor: "pointer"
      }}>Esci dall'account</button>

      <div className="mono" style={{ textAlign: "center", marginTop: 20, color: "var(--t-4)" }}>
        Aura v 2.4.1 · build 1872
      </div>
    </div>);

};

const SettingGroup = ({ title, children }) =>
<>
    <div className="mono" style={{ marginBottom: 8, marginTop: 4 }}>{title}</div>
    <div className="card" style={{ marginBottom: 16, overflow: "hidden" }}>{children}</div>
  </>;


const SettingRow = ({ icon, label, detail, last, gold }) =>
<div className="tap" style={{
  display: "flex", alignItems: "center", gap: 12, padding: "13px 16px",
  borderBottom: last ? "none" : "1px solid var(--hair)"
}}>
    <div style={{
    width: 30, height: 30, borderRadius: 8, background: "rgba(255,255,255,0.04)",
    display: "flex", alignItems: "center", justifyContent: "center"
  }}>
      <Icon name={icon} size={16} color={gold ? "var(--gold)" : "var(--t-2)"} />
    </div>
    <span style={{ flex: 1, fontSize: 14, color: "var(--t-1)" }}>{label}</span>
    {detail && <span style={{ fontSize: 12.5, color: gold ? "var(--gold)" : "var(--t-3)", marginRight: 4 }}>{detail}</span>}
    <Icon name="chevR" size={16} color="var(--t-4)" />
  </div>;


const SettingToggle = ({ label, sub, value, onChange, last }) =>
<div style={{
  display: "flex", alignItems: "center", gap: 12, padding: "13px 16px",
  borderBottom: last ? "none" : "1px solid var(--hair)"
}}>
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 14, color: "var(--t-1)" }}>{label}</div>
      {sub && <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>{sub}</div>}
    </div>
    <button onClick={() => onChange(!value)} style={{
    width: 46, height: 28, borderRadius: 999,
    background: value ? "var(--gold)" : "rgba(255,255,255,0.10)",
    border: 0, padding: 0, cursor: "pointer", position: "relative",
    transition: "background .18s ease"
  }}>
      <div style={{
      position: "absolute", top: 3, left: value ? 21 : 3,
      width: 22, height: 22, borderRadius: 999, background: "#fff",
      transition: "left .18s ease",
      boxShadow: "0 2px 4px rgba(0,0,0,0.3)"
    }} />
    </button>
  </div>;


// ─────────────────────────────────────────────────────────────
// SCREEN 7 — RECENSIONE CLIENTE (post-scontrino, QR-driven)
// ─────────────────────────────────────────────────────────────
const ScreenRecensione = ({ onClose }) => {
  const [stars, setStars] = React.useState(0);
  const [hover, setHover] = React.useState(0);
  const [chips, setChips] = React.useState(new Set());
  const [submitted, setSubmitted] = React.useState(false);

  const chipsList = ["GENTILE", "VELOCE", "CORTESE", "CONOSCENZA VINI", "MULTILINGUE", "ATTENZIONE"];

  const toggle = (c) => {
    const n = new Set(chips);
    if (n.has(c)) n.delete(c);else n.add(c);
    setChips(n);
  };

  if (submitted) {
    return (
      <div className="screen-enter" style={{
        height: "100%", padding: "8px 20px", color: "var(--t-1)",
        display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center"
      }}>
        <div style={{
          width: 110, height: 110, borderRadius: 999,
          background: "radial-gradient(circle, var(--gold-glow), transparent 70%)",
          display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 28
        }}>
          <div style={{
            width: 80, height: 80, borderRadius: 999,
            background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))",
            display: "flex", alignItems: "center", justifyContent: "center"
          }}>
            <Icon name="check" size={42} color="#1a1206" strokeWidth={2.4} />
          </div>
        </div>
        <div className="mono" style={{ marginBottom: 10, color: "var(--gold)" }}>Recensione verificata</div>
        <div className="serif" style={{ fontSize: 28, letterSpacing: "-0.02em", marginBottom: 12, maxWidth: 280 }}>
          Grazie. Marco riceverà<br />il tuo feedback.
        </div>
        <div style={{ fontSize: 13.5, color: "var(--t-3)", maxWidth: 280, lineHeight: 1.5, marginBottom: 32 }}>
          La tua recensione è collegata allo scontrino <span style={{ color: "var(--gold)" }} className="mono">#4821</span> e contribuisce all'Aura del professionista.
        </div>
        <button onClick={onClose} className="btn-ghost" style={{ padding: "13px 28px" }}>Chiudi</button>
      </div>);

  }

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 130px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 0 18px" }}>
        <button onClick={onClose} style={iconBtn}><Icon name="close" size={18} color="var(--t-2)" /></button>
        <div className="mono">Recensione · Anteprima cliente</div>
        <div style={{ width: 40 }} />
      </div>

      {/* Receipt-style header */}
      <div style={{
        position: "relative", marginBottom: 22, padding: "18px 20px",
        background: "var(--bg-1)", borderRadius: 18, border: "1px solid var(--hair)",
        overflow: "hidden"
      }}>
        {/* perforation */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 6, background:
          "radial-gradient(circle at 8px 6px, var(--bg-0) 4px, transparent 4.5px) repeat-x",
          backgroundSize: "16px 8px"
        }} />
        <div className="mono" style={{ marginTop: 6, marginBottom: 6 }}>SCONTRINO · #4821</div>
        <div className="serif" style={{ fontSize: 18, marginBottom: 2 }}>Trattoria da Gino</div>
        <div style={{ fontSize: 12.5, color: "var(--t-3)" }}>Tavolo 12 · Mar 11/11 · 21:42</div>
        <div className="hr" style={{ margin: "12px 0" }} />
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Avatar initials="MR" size={44} ring tone={0} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>Servito da Marco Rossi</div>
            <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2, display: "flex", alignItems: "center", gap: 5 }}>
              <Verified size={11} /> Chef de Rang verificato
            </div>
          </div>
          <div style={{
            display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
            padding: 8, background: "rgba(255,255,255,0.04)", borderRadius: 8
          }}>
            <Icon name="qr" size={26} color="var(--t-1)" />
            <span className="mono" style={{ fontSize: 8 }}>SCAN</span>
          </div>
        </div>
      </div>

      {/* Star input */}
      <div style={{ textAlign: "center", marginBottom: 22 }}>
        <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em", marginBottom: 4 }}>
          Hai apprezzato il servizio?
        </div>
        <div style={{ fontSize: 12.5, color: "var(--t-3)", marginBottom: 18 }}>
          Tocca le stelle per votare
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: 8 }}>
          {[1, 2, 3, 4, 5].map((i) =>
          <button key={i}
          onMouseEnter={() => setHover(i)}
          onMouseLeave={() => setHover(0)}
          onClick={() => setStars(i)}
          style={{ background: "transparent", border: 0, padding: 4, cursor: "pointer", transition: "transform .12s" }}>
              <Icon name={(hover || stars) >= i ? "star" : "starO"} size={38}
            color={(hover || stars) >= i ? "var(--gold)" : "var(--t-4)"} strokeWidth={1.4} />
            </button>
          )}
        </div>
      </div>

      {/* Chips */}
      {stars > 0 &&
      <div className="fade-in">
          <div className="mono" style={{ textAlign: "center", marginBottom: 14 }}>Cosa hai apprezzato?</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", marginBottom: 22 }}>
            {chipsList.map((c) =>
          <Pill key={c} active={chips.has(c)} gold={chips.has(c)} onClick={() => toggle(c)}>{c}</Pill>
          )}
          </div>
        </div>
      }

      {/* Verification */}
      <div className="card" style={{
        padding: 14, display: "flex", alignItems: "center", gap: 12, marginBottom: 16
      }}>
        <div style={{
          width: 38, height: 38, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center",
          background: "rgba(255,200,90,0.08)", border: "1px solid var(--gold)"
        }}>
          <Icon name="shield" size={18} color="var(--gold)" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>Recensione certificata</div>
          <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 2 }}>
            Legata allo scontrino. Niente recensioni false.
          </div>
        </div>
        <Verified size={20} />
      </div>

      <button
        onClick={() => stars > 0 && setSubmitted(true)}
        className={stars > 0 ? "btn-gold" : "btn-ghost"}
        style={{ width: "100%", padding: 16, fontSize: 15, opacity: stars > 0 ? 1 : 0.5 }}>
        {stars > 0 ? "Invia recensione verificata" : "Seleziona un punteggio"}
      </button>
    </div>);

};

Object.assign(window, {
  ScreenMercato, ScreenPiani, ScreenImpostazioni, ScreenRecensione
});