// Aura — main app shell

const { useState, useEffect } = React;

const ScreenChat = ({ convo, onBack }) => {
  const [msg, setMsg] = useState("");
  const [shift, setShift] = useState("idle"); // idle | accepted | declined
  const [messages, setMessages] = useState([
    { from: "them", txt: "Marco, confermi sabato 19:00?", t: "20:58" },
    { from: "them", txt: "Coperti previsti 48, due tavoli da 8 al privé.", t: "20:58" },
    { from: "me", txt: "Confermo. Arrivo alle 18:40 per il brief.", t: "21:01" },
    { from: "them", txt: "Perfetto. Divisa nera e cravatta bordeaux.", t: "21:02" },
    { from: "them", txt: "Sara fa il pre-servizio vini.", t: "21:04" },
  ]);

  const send = () => {
    if (!msg.trim()) return;
    setMessages([...messages, { from: "me", txt: msg, t: "21:18" }]);
    setMsg("");
  };

  return (
    <div className="screen-enter" style={{ height: "100%", display: "flex", flexDirection: "column", color: "var(--t-1)" }}>
      {/* header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 12,
        padding: "8px 20px 14px", borderBottom: "1px solid var(--hair)",
      }}>
        <button onClick={onBack} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)"/></button>
        <Avatar initials={convo?.initials || "TG"} size={36} tone={convo?.tone || 0}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {convo?.name || "Trattoria da Gino · Coord."}
          </div>
          <div style={{ fontSize: 11, color: "var(--gold)", marginTop: 2 }}>● online · 3 persone</div>
        </div>
      </div>

      {/* messages */}
      <div className="scroll" style={{ flex: 1, overflowY: "auto", padding: "16px 20px 12px", display: "flex", flexDirection: "column", gap: 8 }}>
        <div className="mono" style={{ textAlign: "center", margin: "4px 0 12px", color: "var(--t-4)" }}>
          Oggi · Mer 12 Nov
        </div>
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.from === "me" ? "flex-end" : "flex-start" }}>
            <div style={{
              maxWidth: "76%",
              background: m.from === "me" ? "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))" : "var(--bg-2)",
              color: m.from === "me" ? "#1a1206" : "var(--t-1)",
              padding: "10px 14px",
              borderRadius: 18,
              borderBottomRightRadius: m.from === "me" ? 6 : 18,
              borderBottomLeftRadius: m.from === "me" ? 18 : 6,
              border: m.from === "me" ? "none" : "1px solid var(--hair)",
              fontSize: 14, lineHeight: 1.4,
            }}>
              {m.txt}
              <div style={{ fontSize: 9.5, marginTop: 4, opacity: 0.55, textAlign: "right", fontFamily: "var(--f-mono)", letterSpacing: "0.1em" }}>
                {m.t}
              </div>
            </div>
          </div>
        ))}
        {/* shift summary card inside chat */}
        <div className="card-2" style={{
          alignSelf: "flex-start", maxWidth: "82%", padding: 14, marginTop: 6, borderColor: "var(--hair-2)",
        }}>
          <div className="mono" style={{ marginBottom: 8, color: "var(--gold)" }}>Turno proposto</div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Sab 15 Nov · 19:00 – 00:30</div>
          <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 3 }}>Trattoria da Gino · Chef de Rang</div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12, alignItems: "center" }}>
            <span className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 17, color: "var(--gold)", letterSpacing: "-0.01em" }}>€ 165</span>
            {shift === "idle" ?
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => { setShift("declined"); showToast("Turno rifiutato", "close"); }} className="btn-ghost" style={{ padding: "7px 12px", fontSize: 11 }}>Rifiuta</button>
              <button onClick={() => { setShift("accepted"); showToast("Turno accettato · aggiunto all'agenda", "check"); }} className="btn-gold" style={{ padding: "7px 14px", fontSize: 11 }}>Accetta</button>
            </div> :
            <span className="mono" style={{
              padding: "5px 10px", borderRadius: 999,
              background: shift === "accepted" ? "oklch(0.80 0.140 150 / 0.12)" : "rgba(255,255,255,0.06)",
              color: shift === "accepted" ? "var(--pos)" : "var(--t-3)",
              border: `1px solid ${shift === "accepted" ? "oklch(0.80 0.140 150 / 0.40)" : "var(--hair-2)"}`,
            }}>{shift === "accepted" ? "✓ ACCETTATO" : "RIFIUTATO"}</span>
            }
          </div>
        </div>
      </div>

      {/* composer */}
      <div style={{ padding: "10px 14px 12px", borderTop: "1px solid var(--hair)", display: "flex", gap: 8, alignItems: "center" }}>
        <button onClick={() => showToast("Allega file", "plus")} style={iconBtn}><Icon name="plus" size={20} color="var(--t-3)"/></button>
        <input value={msg} onChange={e => setMsg(e.target.value)} onKeyDown={e => e.key === "Enter" && send()}
          placeholder="Scrivi un messaggio…"
          style={{
            flex: 1, background: "var(--bg-1)", border: "1px solid var(--hair)",
            borderRadius: 999, padding: "11px 16px", color: "var(--t-1)", fontSize: 13.5,
            outline: "none", fontFamily: "var(--f-ui)",
          }}/>
        <button onClick={send} style={{
          width: 40, height: 40, borderRadius: 999,
          background: msg.trim() ? "var(--gold)" : "rgba(255,255,255,0.06)",
          border: 0, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
          transition: "background .15s",
        }}>
          <Icon name="send" size={18} color={msg.trim() ? "#1a1206" : "var(--t-3)"}/>
        </button>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// Talent detail modal
// ─────────────────────────────────────────────────────────────
const TalentModal = ({ t, onClose, onOpenProfile }) => {
  if (!t) return null;
  return (
    <div style={{
      position: "absolute", inset: 0, zIndex: 200,
      background: "rgba(8, 6, 4, 0.65)",
      backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)",
      display: "flex", alignItems: "flex-end",
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} className="modal-enter scroll" style={{
        width: "100%", background: "var(--bg-1)",
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        padding: "12px 22px 36px", borderTop: "1px solid var(--hair-2)",
        maxHeight: "85%", overflowY: "auto",
      }}>
        <div style={{ width: 38, height: 4, background: "var(--hair-2)", borderRadius: 99, margin: "0 auto 16px" }}/>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
          <Avatar initials={t.init} size={64} ring tone={t.tone}/>
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span className="serif" style={{ fontSize: 22 }}>{t.name}</span>
              <Verified size={15}/>
            </div>
            <div style={{ fontSize: 13, color: "var(--t-2)", marginTop: 2 }}>{t.role}</div>
            <div style={{ fontSize: 11.5, color: "var(--t-3)", marginTop: 4, display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
                <Icon name="star" size={11} color="var(--gold)"/> {t.rating}
              </span>
              <span>· 96 recensioni</span>
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 18 }}>
          {[...t.badges, "EVENTI", "MULTI"].map(b => <Pill key={b} small active>{b}</Pill>)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 18 }}>
          <StatCell value="6 anni" sub="esperienza"/>
          <StatCell value="98%" sub="puntualità"/>
          <StatCell value="0" sub="reclami"/>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => onOpenProfile && onOpenProfile(t)} className="btn-ghost" style={{ flex: 1, padding: 14 }}>Profilo completo</button>
          <button onClick={() => { showToast(`Richiesta turno inviata a ${t.name.split(" ")[0]}`, "send"); onClose(); }} className="btn-gold" style={{ flex: 1, padding: 14 }}>Proponi turno</button>
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// ROOT APP
// ─────────────────────────────────────────────────────────────
function App() {
  const [tab, setTab] = useState("home");
  const [overlay, setOverlay] = useState(null);
  const [userRole, setUserRole] = useState("waiter"); // 'waiter' | 'manager'
  const [onboarded, setOnboarded] = useState(() => {
    try { return localStorage.getItem("aura_onboarded") === "1"; } catch (e) { return false; }
  });
  const [fresh, setFresh] = useState(false);
  const [applied, setApplied] = useState([]); // turni a cui il cameriere si è candidato in sessione
  const applyToShift = (s) => setApplied(a => a.find(x => x.id === s.id) ? a : [...a, s]);
  const switchRole = () => { setUserRole(r => r === "waiter" ? "manager" : "waiter"); setOverlay(null); setTab("home"); };
  const completeOnboarding = (role, isFresh = true) => {
    setUserRole(role === "manager" ? "manager" : "waiter");
    try { localStorage.setItem("aura_onboarded", "1"); } catch (e) {}
    setOnboarded(true); setFresh(isFresh); setTab("home"); setOverlay(null);
  };
  const replayOnboarding = () => { setOverlay(null); setOnboarded(false); };
  const notifNav = (target) => {
    setOverlay(null);
    switch (target) {
      case "wallet": setOverlay("wallet"); break;
      case "chat": setTab("messaggi"); break;
      case "profilo-recensioni": setTab("profilo"); break;
      case "certificazioni": setOverlay("certificazioni"); break;
      case "impostazioni": setOverlay("settings"); break;
      case "annunci": setOverlay("annunci"); break;
      case "turnario": setOverlay("turnario"); break;
      case "collaborazioni": setOverlay("collaborazioni"); break;
      case "valuta": setOverlay("valuta"); break;
      case "mie-candidature": setOverlay("mie-candidature"); break;
      case "agenda": setOverlay("agenda"); break;
      default: showToast("Notifica aperta");
    }
  };
  const logout = () => {
    try { localStorage.removeItem("aura_onboarded"); } catch (e) {}
    setOverlay(null); setOnboarded(false);
  };

  const FRAME_W = 402;
  const FRAME_H = 868;

  const goTab = (t) => { setOverlay(null); setTab(t); };

  // Lato cameriere — mercato: candidature inviate in sessione
  const appliedIds = new Set(applied.map(s => s.id));
  const extraApps = applied.map(s => ({
    id: s.id, venue: s.venue, init: s.init, tone: s.tone, role: s.role,
    day: s.day, time: s.time, pay: s.pay, status: "pending", when: "Inviata ora",
  }));
  const basePending = ((window.AURA && window.AURA.applications) || []).filter(a => a.status === "pending").length;
  const pendingCount = basePending + applied.length;

  // Scale frame to fit viewport
  const wrapRef = React.useRef(null);
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const fit = () => {
      const vw = window.innerWidth, vh = window.innerHeight;
      const s = Math.min(1, (vh - 48) / FRAME_H, (vw - 48) / FRAME_W);
      setScale(s);
    };
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  const renderScreen = () => {
    if (overlay === "settings") return <ScreenImpostazioni onBack={() => setOverlay(null)} userRole={userRole} onSwitchRole={switchRole} onReplayOnboarding={replayOnboarding} onLogout={logout}/>;
    if (overlay === "review") return <ScreenRecensione onClose={() => setOverlay(null)}/>;
    if (overlay === "wallet") return <ScreenWallet onClose={() => setOverlay(null)}/>;
    if (overlay === "qr") return <ScreenQRPro onClose={() => setOverlay(null)}/>;
    if (overlay === "certificazioni") return <ScreenCertificazioni onClose={() => setOverlay(null)}/>;
    if (overlay === "callextra") return <ScreenCallExtra onClose={() => setOverlay(null)}/>;
    if (overlay === "notifiche") return <ScreenNotifiche onClose={() => setOverlay(null)} userRole={userRole} onNavigate={notifNav}/>;
    if (overlay && overlay.type === "turno") return <ScreenTurno shift={overlay.shift} onClose={() => setOverlay(null)} onOpenQR={() => setOverlay("qr")}/>;
    if (overlay === "pubblica") return <ScreenPubblicaTurno onClose={() => setOverlay(null)} onPublished={() => setOverlay("annunci")}/>;
    if (overlay === "annunci") return <ScreenAnnunci onClose={() => setOverlay(null)} onPubblica={() => setOverlay("pubblica")} onOpenCandidature={(post) => setOverlay({ type: "candidature", post })}/>;
    if (overlay && overlay.type === "candidature") return <ScreenCandidature post={overlay.post} onClose={() => setOverlay("annunci")} onOpenTalent={t => setOverlay({ type: "talent", t })}/>;
    if (overlay === "turnario") return <ScreenTurnario onClose={() => setOverlay(null)} onOpenTalent={t => setOverlay({ type: "talent", t })} onPubblica={() => setOverlay("pubblica")}/>;
    if (overlay === "collaborazioni") return <ScreenCollaborazioni onClose={() => setOverlay(null)} onOpenDetail={(c) => setOverlay({ type: "collabDetail", collab: c })} onPubblica={() => setOverlay("pubblica")}/>;
    if (overlay === "staff") return <ScreenStaff onClose={() => setOverlay(null)} onPubblica={() => setOverlay("pubblica")}/>;
    if (overlay && overlay.type === "collabDetail") return <ScreenCollaboraDetail collab={overlay.collab} onClose={() => setOverlay("collaborazioni")} onOpenTalent={t => setOverlay({ type: "talent", t })}/>;
    if (overlay && overlay.type === "profiloPubblico") return <ScreenProfiloPubblico talent={overlay.talent} onClose={() => setOverlay(null)}/>;
    if (overlay === "agenda") return <ScreenAgenda onClose={() => setOverlay(null)} onOpenTurno={(shift) => setOverlay({ type: "turno", shift })}/>;
    if (overlay === "mie-candidature") return <ScreenMieCandidature onClose={() => setOverlay(null)} extraApps={extraApps} onOpenAgenda={() => setOverlay("agenda")}/>;
    if (overlay === "valuta") return <ScreenValutaCameriere onClose={() => setOverlay(null)}/>;
    if (overlay && overlay.type === "contest") return <ScreenContestazione review={overlay.review} onClose={() => setOverlay(null)}/>;
    if (overlay && overlay.type === "chat") return <ScreenChat convo={overlay.convo} onBack={() => setOverlay(null)}/>;

    switch (tab) {
      case "home":
        return userRole === "manager"
          ? <ScreenManagerDashboard
              onSwitchRole={switchRole}
              onOpenSettings={() => setOverlay("settings")}
              onOpenCallExtra={() => setOverlay("callextra")}
              onOpenTalent={t => setOverlay({ type: "talent", t })}
              onOpenNotifiche={() => setOverlay("notifiche")}
              onSeeAll={() => setTab("talenti")}
              onPubblica={() => setOverlay("pubblica")}
              onOpenAnnunci={() => setOverlay("annunci")}
              onOpenTurnario={() => setOverlay("turnario")}
              onOpenCollaborazioni={() => setOverlay("collaborazioni")}
              onOpenStaff={() => setOverlay("staff")}
              fresh={fresh}
              onPopulate={() => setFresh(false)}/>
          : <ScreenDashboard
              onOpenReview={() => setOverlay("review")}
              onOpenSettings={() => setOverlay("settings")}
              onSwitchRole={switchRole}
              onOpenWallet={() => setOverlay("wallet")}
              onOpenQR={() => setOverlay("qr")}
              onOpenNotifiche={() => setOverlay("notifiche")}
              onOpenTurno={(shift) => setOverlay({ type: "turno", shift })}
              onOpenAgenda={() => setOverlay("agenda")}
              onOpenTurni={() => goTab("talenti")}
              fresh={fresh}
              onPopulate={() => setFresh(false)}/>;
      case "talenti": return userRole === "manager"
        ? <ScreenMercato onOpenTalent={t => setOverlay({ type: "talent", t })}/>
        : <ScreenTrovaTurni appliedIds={appliedIds} onApply={applyToShift} onOpenMie={() => setOverlay("mie-candidature")} pendingCount={pendingCount}/>;
      case "messaggi": return <ScreenMessaggi onOpenChat={(c) => setOverlay({ type: "chat", convo: c })}/>;
      case "pro": return <ScreenPiani/>;
      case "profilo": return <ScreenProfilo
        onOpenSettings={() => setOverlay("settings")}
        onOpenContest={(r) => setOverlay({ type: "contest", review: r })}
        onOpenCertificazioni={() => setOverlay("certificazioni")}
        fresh={fresh}
        onPopulate={() => setFresh(false)}
        onOpenQR={() => setOverlay("qr")}/>;
      default: return null;
    }
  };

  const hideTabs = overlay === "review" || overlay === "wallet" || overlay === "qr" || overlay === "certificazioni" || overlay === "callextra" || overlay === "notifiche" || overlay === "pubblica" || overlay === "annunci" || overlay === "turnario" || overlay === "collaborazioni" || overlay === "staff" || overlay === "agenda" || overlay === "mie-candidature" || overlay === "valuta" || (overlay && (overlay.type === "chat" || overlay.type === "contest" || overlay.type === "turno" || overlay.type === "candidature" || overlay.type === "collabDetail" || overlay.type === "profiloPubblico"));
  const showFAB = userRole === "waiter" && !overlay && tab !== "messaggi";

  return (
    <div style={{
      minHeight: "100vh", width: "100vw",
      display: "flex", alignItems: "center", justifyContent: "center",
      background: "radial-gradient(ellipse at 50% 0%, oklch(0.20 0.014 65) 0%, #0a0907 60%)",
      overflow: "hidden",
    }}>
      <div ref={wrapRef} style={{
        width: FRAME_W, height: FRAME_H,
        transform: `scale(${scale})`, transformOrigin: "center",
      }}>
        {/* Device frame */}
        <div style={{
          width: "100%", height: "100%",
          borderRadius: 56, overflow: "hidden", position: "relative",
          background: "var(--bg-0)",
          boxShadow: "0 60px 120px rgba(0,0,0,0.55), 0 0 0 12px #1a1611, 0 0 0 13px rgba(255,240,220,0.08)",
        }}>
          <DynamicIsland/>
          <StatusBar time="21:18"/>
          {!onboarded ? (
            <div style={{
              position: "absolute", inset: "48px 0 0 0", height: "calc(100% - 48px)",
            }}>
              <OnboardingFlow onComplete={completeOnboarding}/>
            </div>
          ) : (
          <React.Fragment>
          <div className="scroll" style={{
            position: "absolute", inset: "48px 0 0 0",
            overflowY: "auto",
            color: "var(--t-1)",
            height: "calc(100% - 48px)",
          }} key={overlay ? (typeof overlay === "string" ? overlay : overlay.type) : tab + userRole}>
            {renderScreen()}
          </div>
          {!hideTabs && <TabBar active={tab} onChange={goTab} userRole={userRole}/>}
          {showFAB && <QRGeneratorFAB onClick={() => setOverlay("qr")}/>}
          {overlay && overlay.type === "talent" && <TalentModal t={overlay.t} onClose={() => setOverlay(null)} onOpenProfile={(tl) => setOverlay({ type: "profiloPubblico", talent: tl })}/>}
          </React.Fragment>
          )}
          <ToastHost/>
          <HomeIndicator/>
        </div>

        {/* Caption below */}
        <div style={{
          position: "absolute", bottom: -36, left: 0, right: 0, textAlign: "center",
          color: "var(--t-4)", fontFamily: "var(--f-mono)", fontSize: 10, letterSpacing: "0.2em", textTransform: "uppercase",
        }}>
          Aura · prototipo · {onboarded ? labelFor(tab, overlay, userRole) : "Onboarding"}
        </div>
      </div>
    </div>
  );
}

function labelFor(tab, overlay, userRole) {
  if (overlay === "settings") return "Impostazioni";
  if (overlay === "review") return "Recensione verificata";
  if (overlay === "wallet") return "Wallet Stripe";
  if (overlay === "qr") return "Il tuo QR";
  if (overlay === "certificazioni") return "Certificazioni";
  if (overlay === "callextra") return "Chiamata extra";
  if (overlay === "notifiche") return "Notifiche";
  if (overlay && overlay.type === "turno") return "Turno in corso";
  if (overlay === "pubblica") return "Pubblica turno";
  if (overlay === "annunci") return "I miei annunci";
  if (overlay && overlay.type === "candidature") return "Candidature";
  if (overlay === "turnario") return "Turnario";
  if (overlay === "collaborazioni") return "Collaborazioni";
  if (overlay === "staff") return "Il mio staff";
  if (overlay && overlay.type === "collabDetail") return "Collaborazione";
  if (overlay && overlay.type === "profiloPubblico") return "Profilo pubblico";
  if (overlay === "agenda") return "Agenda";
  if (overlay === "mie-candidature") return "Le mie candidature";
  if (overlay === "valuta") return "Valuta il professionista";
  if (overlay && overlay.type === "contest") return "Centro Risoluzioni";
  if (overlay && overlay.type === "chat") return "Conversazione";
  return ({ home: "Dashboard", talenti: userRole === "manager" ? "Mercato talenti" : "Trova turni", messaggi: "Messaggi", pro: "Piani", profilo: "Profilo pro" })[tab];
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
