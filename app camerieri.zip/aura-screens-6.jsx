// Aura — Screen: Turnario settimanale (manager weekly roster)

const ScreenTurnario = ({ onClose, onOpenTalent, onPubblica }) => {
  const days = [
    { key: "lun", label: "LUN", date: "10" },
    { key: "mar", label: "MAR", date: "11" },
    { key: "mer", label: "MER", date: "12", today: true },
    { key: "gio", label: "GIO", date: "13" },
    { key: "ven", label: "VEN", date: "14" },
    { key: "sab", label: "SAB", date: "15" },
    { key: "dom", label: "DOM", date: "16" },
  ];

  // staff roster: who works which days + slot
  const staff = [
    { init: "MR", name: "Marco Rossi", role: "Chef de Rang", tone: 0, shifts: { mer: "S", gio: "S", ven: "S", sab: "D" } },
    { init: "EC", name: "Elisa Conte", role: "Sommelier", tone: 4, shifts: { mer: "S", ven: "S", sab: "S" } },
    { init: "LT", name: "Luca Trapani", role: "Cameriere", tone: 2, shifts: { mar: "S", mer: "S", gio: "D", sab: "S", dom: "D" } },
    { init: "GR", name: "Giulia Romano", role: "Hostess", tone: 5, shifts: { mer: "S", sab: "S", dom: "P" } },
    { init: "FT", name: "Federico Turi", role: "Runner", tone: 1, shifts: { gio: "S", ven: "S", sab: "S" } },
  ];

  // slot legend: S = sera/cena, D = doppio (pranzo+cena), P = pranzo
  const slotColor = {
    S: { bg: "rgba(255,200,90,0.12)", bd: "oklch(0.81 0.115 82 / 0.4)", tx: "var(--gold)" },
    D: { bg: "oklch(0.80 0.140 150 / 0.12)", bd: "oklch(0.80 0.140 150 / 0.4)", tx: "var(--pos)" },
    P: { bg: "rgba(255,255,255,0.06)", bd: "var(--hair-2)", tx: "var(--t-2)" },
  };

  // coverage target per day (how many staff needed)
  const need = { lun: 3, mar: 3, mer: 5, gio: 4, ven: 5, sab: 6, dom: 4 };

  const [selectedDay, setSelectedDay] = React.useState("sab");

  const countDay = (k) => staff.filter(s => s.shifts[k]).length;

  const dayStaff = staff.filter(s => s.shifts[selectedDay]);
  const sel = days.find(d => d.key === selectedDay);
  const covered = countDay(selectedDay);
  const needed = need[selectedDay];
  const gap = needed - covered;

  return (
    <div className="screen-enter" style={{ padding: "8px 20px 40px", color: "var(--t-1)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 0 18px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={onClose} style={iconBtn}><Icon name="chevL" size={20} color="var(--t-2)" /></button>
          <div>
            <div className="mono">Trattoria da Gino</div>
            <div className="serif" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>Turnario</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <button onClick={() => showToast("Settimana precedente", "chevL")} style={iconBtn}><Icon name="chevL" size={18} color="var(--t-3)"/></button>
          <button onClick={() => showToast("Settimana successiva", "chevR")} style={iconBtn}><Icon name="chevR" size={18} color="var(--t-3)"/></button>
        </div>
      </div>

      <div className="mono" style={{ marginBottom: 12 }}>Settimana 10–16 Nov · 5 in organico</div>

      {/* Week strip — coverage per day */}
      <div className="scroll" style={{ display: "flex", gap: 7, overflowX: "auto", marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20, marginBottom: 20 }}>
        {days.map(d => {
          const c = countDay(d.key);
          const n = need[d.key];
          const short = c < n;
          const on = selectedDay === d.key;
          return (
            <button key={d.key} onClick={() => setSelectedDay(d.key)} style={{
              flexShrink: 0, width: 58, padding: "10px 0 9px", borderRadius: 14, cursor: "pointer",
              background: on ? "linear-gradient(180deg, oklch(0.24 0.020 75), oklch(0.18 0.014 65))" : "var(--bg-1)",
              border: `1px solid ${on ? "var(--gold)" : "var(--hair)"}`,
              display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
              position: "relative", fontFamily: "var(--f-ui)",
            }}>
              <span className="mono" style={{ fontSize: 8.5, color: d.today ? "var(--gold)" : "var(--t-3)" }}>{d.label}</span>
              <span className="numeric" style={{ fontWeight: 700, fontSize: 18, color: "var(--t-1)" }}>{d.date}</span>
              <span style={{
                fontFamily: "var(--f-mono)", fontSize: 9, marginTop: 2,
                color: short ? "var(--warn)" : "var(--pos)",
              }}>{c}/{n}</span>
              {d.today && <span style={{ position: "absolute", top: 6, right: 6, width: 5, height: 5, borderRadius: 99, background: "var(--gold)" }}/>}
            </button>
          );
        })}
      </div>

      {/* Selected day detail */}
      <div className="card" style={{
        padding: "16px 18px", marginBottom: 14,
        borderColor: gap > 0 ? "oklch(0.78 0.140 50 / 0.4)" : "oklch(0.80 0.140 150 / 0.4)",
        background: gap > 0 ? "oklch(0.78 0.140 50 / 0.05)" : "var(--bg-1)",
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div className="serif" style={{ fontSize: 18 }}>{sel.label === "SAB" ? "Sabato" : sel.label} {sel.date} novembre</div>
            <div style={{ fontSize: 12.5, color: gap > 0 ? "var(--warn)" : "var(--pos)", marginTop: 3, fontWeight: 500 }}>
              {gap > 0 ? `Manca${gap > 1 ? "no" : ""} ${gap} ${gap > 1 ? "persone" : "persona"} sul previsto` : "Copertura completa"}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div className="numeric" style={{ fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 24, color: gap > 0 ? "var(--warn)" : "var(--pos)" }}>{covered}<span style={{ color: "var(--t-4)", fontWeight: 500, fontSize: 16 }}>/{needed}</span></div>
            <div className="mono" style={{ marginTop: 2 }}>in turno</div>
          </div>
        </div>
        {gap > 0 && (
          <button onClick={onPubblica} className="btn-gold" style={{ width: "100%", padding: 12, fontSize: 13, marginTop: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 7 }}>
            <Icon name="plus" size={15} color="#1a1206" strokeWidth={2.2}/> Pubblica turno per coprire
          </button>
        )}
      </div>

      {/* Staff scheduled this day */}
      <div className="mono" style={{ marginBottom: 10 }}>In turno · {sel.label} {sel.date}</div>
      <div className="card" style={{ overflow: "hidden", marginBottom: 22 }}>
        {dayStaff.length === 0 ? (
          <div style={{ padding: "24px 16px", textAlign: "center" }}>
            <div className="mono" style={{ color: "var(--t-4)" }}>Nessuno in turno questo giorno</div>
          </div>
        ) : dayStaff.map((s, i) => {
          const slot = s.shifts[selectedDay];
          const sc = slotColor[slot];
          const slotLabel = { S: "Cena · 19:00", D: "Doppio · 12:00 & 19:00", P: "Pranzo · 12:00" }[slot];
          return (
            <div key={s.init} onClick={() => onOpenTalent({ id: i, init: s.init, name: s.name, role: s.role, rating: 4.7, badges: ["VELOCE", "CORTESE"], avail: "In organico", tone: s.tone })}
              className="tap" style={{
              display: "flex", alignItems: "center", gap: 12, padding: "13px 16px",
              borderBottom: i === dayStaff.length - 1 ? "none" : "1px solid var(--hair)",
            }}>
              <Avatar initials={s.init} size={42} tone={s.tone}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{s.name}</div>
                <div style={{ fontSize: 12, color: "var(--t-3)", marginTop: 2 }}>{s.role} · {slotLabel}</div>
              </div>
              <span style={{
                fontFamily: "var(--f-mono)", fontSize: 9, letterSpacing: "0.1em",
                padding: "4px 9px", borderRadius: 999,
                background: sc.bg, border: `1px solid ${sc.bd}`, color: sc.tx,
              }}>{slot === "S" ? "CENA" : slot === "D" ? "DOPPIO" : "PRANZO"}</span>
            </div>
          );
        })}
      </div>

      {/* Full grid — staff × days */}
      <div className="mono" style={{ marginBottom: 10 }}>Vista settimana</div>
      <div className="card scroll" style={{ overflow: "auto", padding: 0 }}>
        <div style={{ minWidth: 460 }}>
          {/* header row */}
          <div style={{ display: "grid", gridTemplateColumns: "110px repeat(7, 1fr)", borderBottom: "1px solid var(--hair)" }}>
            <div style={{ padding: "10px 12px" }} />
            {days.map(d => (
              <div key={d.key} style={{ padding: "10px 0", textAlign: "center", background: d.today ? "rgba(255,200,90,0.04)" : "transparent" }}>
                <div className="mono" style={{ fontSize: 8, color: d.today ? "var(--gold)" : "var(--t-4)" }}>{d.label}</div>
                <div className="numeric" style={{ fontSize: 12, fontWeight: 600, marginTop: 2 }}>{d.date}</div>
              </div>
            ))}
          </div>
          {/* staff rows */}
          {staff.map((s, ri) => (
            <div key={s.init} style={{ display: "grid", gridTemplateColumns: "110px repeat(7, 1fr)", borderBottom: ri === staff.length - 1 ? "none" : "1px solid var(--hair)" }}>
              <div style={{ padding: "11px 12px", display: "flex", alignItems: "center", gap: 8, minWidth: 0 }}>
                <Avatar initials={s.init} size={26} tone={s.tone}/>
                <span style={{ fontSize: 11.5, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.name.split(" ")[0]}</span>
              </div>
              {days.map(d => {
                const slot = s.shifts[d.key];
                const sc = slot ? slotColor[slot] : null;
                return (
                  <div key={d.key} style={{ padding: "8px 4px", display: "flex", alignItems: "center", justifyContent: "center", background: d.today ? "rgba(255,200,90,0.04)" : "transparent" }}>
                    {slot ? (
                      <span style={{
                        width: 26, height: 26, borderRadius: 8,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        background: sc.bg, border: `1px solid ${sc.bd}`, color: sc.tx,
                        fontFamily: "var(--f-mono)", fontSize: 10, fontWeight: 600,
                      }}>{slot}</span>
                    ) : (
                      <span style={{ width: 4, height: 4, borderRadius: 99, background: "var(--hair-2)" }}/>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div style={{ display: "flex", gap: 16, marginTop: 14, justifyContent: "center", flexWrap: "wrap" }}>
        {[["S", "Cena", slotColor.S], ["D", "Doppio", slotColor.D], ["P", "Pranzo", slotColor.P]].map(([k, lbl, sc]) => (
          <div key={k} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ width: 16, height: 16, borderRadius: 5, background: sc.bg, border: `1px solid ${sc.bd}`, color: sc.tx, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--f-mono)", fontSize: 8, fontWeight: 600 }}>{k}</span>
            <span className="mono" style={{ color: "var(--t-3)" }}>{lbl}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { ScreenTurnario });
