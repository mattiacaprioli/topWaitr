// Aura — shared components & icons
// Loaded after React/Babel, before screens.

// ─────────────────────────────────────────────────────────────
// Icons (24x24 default)
// ─────────────────────────────────────────────────────────────
const Icon = ({ name, size = 22, color = "currentColor", strokeWidth = 1.6 }) => {
  const s = { width: size, height: size, flexShrink: 0 };
  const p = { fill: "none", stroke: color, strokeWidth, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "home":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M3 11l9-7 9 7v9a2 2 0 0 1-2 2h-4v-7h-6v7H5a2 2 0 0 1-2-2v-9z"/></svg>;
    case "search":
      return <svg viewBox="0 0 24 24" style={s}><circle {...p} cx="11" cy="11" r="7"/><path {...p} d="M20 20l-3.5-3.5"/></svg>;
    case "chat":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M21 12a8 8 0 1 1-3-6.2L21 5l-1 3.6A8 8 0 0 1 21 12z"/></svg>;
    case "spark":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></svg>;
    case "user":
      return <svg viewBox="0 0 24 24" style={s}><circle {...p} cx="12" cy="8" r="4"/><path {...p} d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg>;
    case "gear":
      return <svg viewBox="0 0 24 24" style={s}><circle {...p} cx="12" cy="12" r="3"/><path {...p} d="M19.4 14.6a1.7 1.7 0 0 0 .4 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.4 1.7 1.7 0 0 0-1 1.6V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.4l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .4-1.9 1.7 1.7 0 0 0-1.6-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.4-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.4h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.4l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.4 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1.1z"/></svg>;
    case "bell":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9z"/><path {...p} d="M10 21a2 2 0 0 0 4 0"/></svg>;
    case "check":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M5 12l5 5 9-10"/></svg>;
    case "checkSeal":
      return <svg viewBox="0 0 24 24" style={s}>
        <path {...p} d="M12 2l2.4 1.7 2.9-.3 1.2 2.6 2.6 1.2-.3 2.9L22 12l-1.7 2.4.3 2.9-2.6 1.2-1.2 2.6-2.9-.3L12 22l-2.4-1.7-2.9.3-1.2-2.6-2.6-1.2.3-2.9L2 12l1.7-2.4-.3-2.9 2.6-1.2 1.2-2.6 2.9.3z" fill="none"/>
        <path {...p} d="M8 12l3 3 5-6"/>
      </svg>;
    case "arrowUp":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 19V5M5 12l7-7 7 7"/></svg>;
    case "arrowRight":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M5 12h14M13 5l7 7-7 7"/></svg>;
    case "chevR":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M9 6l6 6-6 6"/></svg>;
    case "chevL":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M15 6l-6 6 6 6"/></svg>;
    case "chevD":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M6 9l6 6 6-6"/></svg>;
    case "plus":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 5v14M5 12h14"/></svg>;
    case "close":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M6 6l12 12M18 6L6 18"/></svg>;
    case "calendar":
      return <svg viewBox="0 0 24 24" style={s}><rect {...p} x="3" y="5" width="18" height="16" rx="2"/><path {...p} d="M3 10h18M8 3v4M16 3v4"/></svg>;
    case "clock":
      return <svg viewBox="0 0 24 24" style={s}><circle {...p} cx="12" cy="12" r="9"/><path {...p} d="M12 7v5l3 2"/></svg>;
    case "euro":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M18 6.5A8 8 0 0 0 6.4 12 8 8 0 0 0 18 17.5M4 10h11M4 14h11"/></svg>;
    case "qr":
      return <svg viewBox="0 0 24 24" style={s}>
        <path {...p} d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h3v3h-3zM18 14h3M14 18v3M21 18v3M18 21h3"/>
      </svg>;
    case "filter":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M4 5h16M7 12h10M10 19h4"/></svg>;
    case "pin":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 21s-7-6.5-7-12a7 7 0 1 1 14 0c0 5.5-7 12-7 12z"/><circle {...p} cx="12" cy="9" r="2.5"/></svg>;
    case "star":
      return <svg viewBox="0 0 24 24" style={s}><path d="M12 3.2l2.6 5.6 6.1.7-4.5 4.2 1.2 6-5.4-3-5.4 3 1.2-6-4.5-4.2 6.1-.7z" fill={color} stroke="none"/></svg>;
    case "starO":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 3.2l2.6 5.6 6.1.7-4.5 4.2 1.2 6-5.4-3-5.4 3 1.2-6-4.5-4.2 6.1-.7z"/></svg>;
    case "wine":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M7 3h10v4a5 5 0 0 1-10 0V3zM12 12v8M8 20h8"/></svg>;
    case "lang":
      return <svg viewBox="0 0 24 24" style={s}><circle {...p} cx="12" cy="12" r="9"/><path {...p} d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>;
    case "shield":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6l8-3z"/></svg>;
    case "receipt":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M6 3h12v18l-3-2-3 2-3-2-3 2V3zM9 8h6M9 12h6M9 16h4"/></svg>;
    case "doc":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M6 3h9l4 4v14H6zM14 3v5h5"/></svg>;
    case "send":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M3 12l18-8-7 18-3-7-8-3z"/></svg>;
    case "wallet":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M3 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2H6a2 2 0 0 0 0 4h13v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/><circle cx="17" cy="11" r="1" fill={color}/></svg>;
    case "shield2":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6l8-3z"/><path {...p} d="M9 12l2 2 4-4"/></svg>;
    case "upload":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 16V4M6 10l6-6 6 6M4 20h16"/></svg>;
    case "alert":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 3l10 18H2L12 3zM12 10v5M12 18v.1"/></svg>;
    case "flame":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M12 3s4 5 4 9a4 4 0 1 1-8 0c0-1 .5-2 1-2.5C9 11 9 8 12 3z"/></svg>;
    case "users":
      return <svg viewBox="0 0 24 24" style={s}><circle {...p} cx="9" cy="8" r="3.5"/><path {...p} d="M2 21c0-3.9 3.1-7 7-7s7 3.1 7 7"/><circle {...p} cx="17" cy="7" r="2.5"/><path {...p} d="M22 18c0-2.5-2-4.5-4.5-4.5"/></svg>;
    case "broadcast":
      return <svg viewBox="0 0 24 24" style={s}><circle {...p} cx="12" cy="12" r="2"/><path {...p} d="M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14"/></svg>;
    case "lightning":
      return <svg viewBox="0 0 24 24" style={s}><path {...p} d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/></svg>;
    case "logo":
      // Aura mark — concentric arcs with a dot
      return <svg viewBox="0 0 24 24" style={s}>
        <circle cx="12" cy="12" r="3.5" fill={color}/>
        <path d="M12 4a8 8 0 0 1 8 8" stroke={color} strokeWidth={1.6} fill="none" strokeLinecap="round"/>
        <path d="M5 12a7 7 0 0 1 1.4-4.2" stroke={color} strokeWidth={1.6} fill="none" strokeLinecap="round" opacity="0.55"/>
      </svg>;
    default: return null;
  }
};

// ─────────────────────────────────────────────────────────────
// Status bar (Aura dark theme)
// ─────────────────────────────────────────────────────────────
const StatusBar = ({ time = "21:18" }) => (
  <div style={{
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "16px 28px 8px", height: 48, boxSizing: "border-box",
    color: "var(--t-1)", fontFamily: "-apple-system, system-ui",
    fontWeight: 600, fontSize: 16, position: "relative", zIndex: 5,
  }}>
    <span style={{ paddingLeft: 4 }}>{time}</span>
    <div style={{ width: 126 }} />
    <div style={{ display: "flex", gap: 6, alignItems: "center", paddingRight: 2 }}>
      <svg width="17" height="11" viewBox="0 0 17 11"><g fill="currentColor">
        <rect x="0" y="7" width="3" height="4" rx="0.6"/>
        <rect x="4.5" y="4.5" width="3" height="6.5" rx="0.6"/>
        <rect x="9" y="2" width="3" height="9" rx="0.6"/>
        <rect x="13.5" y="0" width="3" height="11" rx="0.6"/>
      </g></svg>
      <svg width="15" height="11" viewBox="0 0 16 11" fill="currentColor">
        <path d="M8 2.8c2 0 3.9.8 5.3 2.2l1-1A8.4 8.4 0 0 0 8 1.3 8.4 8.4 0 0 0 1.7 4l1 1A7.4 7.4 0 0 1 8 2.8z"/>
        <path d="M8 6c1.2 0 2.3.5 3.1 1.3l1-1A6.1 6.1 0 0 0 8 4.5a6.1 6.1 0 0 0-4.1 1.8l1 1A4.4 4.4 0 0 1 8 6z"/>
        <circle cx="8" cy="9.3" r="1.4"/>
      </svg>
      <svg width="25" height="11" viewBox="0 0 25 11">
        <rect x="0.5" y="0.5" width="21" height="10" rx="3" stroke="currentColor" strokeOpacity="0.45" fill="none"/>
        <rect x="2" y="2" width="14" height="7" rx="1.5" fill="var(--gold)"/>
        <path d="M23 3.5v4c.7-.3 1.2-1 1.2-2s-.5-1.7-1.2-2z" fill="currentColor" opacity="0.55"/>
      </svg>
    </div>
  </div>
);

// Dynamic Island
const DynamicIsland = () => (
  <div style={{
    position: "absolute", top: 10, left: "50%", transform: "translateX(-50%)",
    width: 122, height: 36, borderRadius: 22, background: "#000",
    zIndex: 100,
  }} />
);

// Home indicator
const HomeIndicator = ({ color = "rgba(255,255,255,0.55)" }) => (
  <div style={{
    position: "absolute", bottom: 8, left: 0, right: 0,
    display: "flex", justifyContent: "center", pointerEvents: "none", zIndex: 90,
  }}>
    <div style={{ width: 134, height: 5, borderRadius: 100, background: color }} />
  </div>
);

// ─────────────────────────────────────────────────────────────
// Bottom tab bar
// ─────────────────────────────────────────────────────────────
const TabBar = ({ active, onChange, userRole = "waiter" }) => {
  const tabs = [
    { id: "home", label: "Home", icon: "home" },
    userRole === "manager"
      ? { id: "talenti", label: "Talenti", icon: "search" }
      : { id: "talenti", label: "Turni", icon: "search" },
    { id: "messaggi", label: "Messaggi", icon: "chat" },
    { id: "pro", label: "Pro", icon: "spark" },
    { id: "profilo", label: "Profilo", icon: "user" },
  ];
  return (
    <div style={{
      position: "absolute", left: 12, right: 12, bottom: 26,
      background: "rgba(20, 16, 12, 0.78)",
      backdropFilter: "blur(28px) saturate(140%)",
      WebkitBackdropFilter: "blur(28px) saturate(140%)",
      border: "1px solid var(--hair-2)",
      borderRadius: 28, padding: "8px 6px",
      display: "flex", justifyContent: "space-around",
      zIndex: 80,
      boxShadow: "0 12px 30px rgba(0,0,0,0.5)",
    }}>
      {tabs.map(t => {
        const on = t.id === active;
        return (
          <button key={t.id} onClick={() => onChange(t.id)}
            style={{
              flex: 1, background: "transparent", border: 0, padding: "8px 0 6px",
              display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
              cursor: "pointer", color: on ? "var(--gold)" : "var(--t-3)",
              fontFamily: "var(--f-mono)", fontSize: 9, letterSpacing: "0.14em",
              transition: "color .15s ease",
            }}>
            <Icon name={t.icon} size={22} strokeWidth={on ? 2 : 1.6}/>
            <span style={{ textTransform: "uppercase" }}>{t.label}</span>
          </button>
        );
      })}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// Avatar (placeholder w/ initials + gold ring optional)
// ─────────────────────────────────────────────────────────────
const Avatar = ({ initials = "MR", size = 44, ring = false, tone = 0, src = null }) => {
  const tones = [
    "linear-gradient(135deg, oklch(0.55 0.08 60), oklch(0.32 0.04 50))",
    "linear-gradient(135deg, oklch(0.50 0.07 30), oklch(0.30 0.04 25))",
    "linear-gradient(135deg, oklch(0.52 0.06 200), oklch(0.30 0.03 200))",
    "linear-gradient(135deg, oklch(0.50 0.07 140), oklch(0.30 0.04 130))",
    "linear-gradient(135deg, oklch(0.55 0.07 320), oklch(0.32 0.04 310))",
    "linear-gradient(135deg, oklch(0.55 0.08 90), oklch(0.32 0.05 80))",
  ];
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: tones[tone % tones.length],
      display: "flex", alignItems: "center", justifyContent: "center",
      color: "rgba(255,250,240,0.92)", fontWeight: 600, fontSize: size * 0.36,
      letterSpacing: "0.02em", flexShrink: 0,
      border: ring ? "1.5px solid var(--gold)" : "none",
      boxShadow: ring ? "0 0 0 3px rgba(0,0,0,0.7), 0 0 18px var(--gold-glow)" : "none",
      fontFamily: "var(--f-ui)",
    }}>
      {initials}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// Verified badge inline
// ─────────────────────────────────────────────────────────────
const Verified = ({ size = 14 }) => (
  <span style={{ display: "inline-flex", color: "var(--gold)" }}>
    <Icon name="checkSeal" size={size}/>
  </span>
);

// Badge ring — supports status: 'active' (gold), 'pending' (pulsing gold), 'inactive' (grey)
const Badge = ({ label, size = 56, active = true, status }) => {
  const st = status || (active ? "active" : "inactive");
  const isActive = st === "active";
  const isPending = st === "pending";
  const isInactive = st === "inactive";
  const borderColor = isInactive ? "var(--hair-2)" : "var(--gold)";
  const textColor = isInactive ? "var(--t-4)" : "var(--gold)";
  return (
    <div className={isPending ? "gold-pulse" : ""} style={{
      width: size, height: size, borderRadius: "50%",
      border: `1.5px ${isPending ? "dashed" : "solid"} ${borderColor}`,
      display: "flex", alignItems: "center", justifyContent: "center",
      flexShrink: 0,
      background: isInactive ? "transparent" : "radial-gradient(circle at 50% 30%, oklch(0.81 0.115 82 / 0.10), transparent 70%)",
      fontFamily: "var(--f-mono)",
      fontSize: size <= 48 ? 8 : 9,
      letterSpacing: "0.14em",
      color: textColor,
      textAlign: "center", lineHeight: 1.1,
      position: "relative",
    }}>
      {label}
      {isPending && (
        <span style={{
          position: "absolute", top: -4, right: -4,
          width: 14, height: 14, borderRadius: 999,
          background: "var(--gold)", color: "#1a1206",
          fontSize: 8, fontWeight: 800,
          display: "flex", alignItems: "center", justifyContent: "center",
          border: "2px solid var(--bg-0)",
        }}>⋯</span>
      )}
    </div>
  );
};

// QR Generator FAB — floating action button for waiters
const QRGeneratorFAB = ({ onClick }) => (
  <button onClick={onClick} aria-label="Apri il tuo QR" style={{
    position: "absolute", right: 18, bottom: 108, zIndex: 75,
    width: 58, height: 58, borderRadius: 999,
    background: "linear-gradient(180deg, oklch(0.88 0.115 85), oklch(0.70 0.130 75))",
    border: 0, cursor: "pointer",
    display: "flex", alignItems: "center", justifyContent: "center",
    boxShadow: "0 10px 30px var(--gold-glow), 0 6px 16px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.18) inset",
    transition: "transform .14s ease",
  }}
  onMouseDown={e => e.currentTarget.style.transform = "scale(0.94)"}
  onMouseUp={e => e.currentTarget.style.transform = "scale(1)"}
  onMouseLeave={e => e.currentTarget.style.transform = "scale(1)"}>
    <Icon name="qr" size={28} color="#1a1206" strokeWidth={2}/>
  </button>
);

// Contest badge — pill near a review with state
const ContestBadge = ({ state = "idle", onClick }) => {
  // idle | pending | resolved
  if (state === "pending") {
    return (
      <span className="mono" style={{
        display: "inline-flex", alignItems: "center", gap: 5,
        padding: "4px 9px", borderRadius: 999,
        background: "oklch(0.78 0.140 50 / 0.10)",
        border: "1px solid oklch(0.78 0.140 50 / 0.40)",
        color: "var(--warn)", fontSize: 9,
      }}>
        <span className="warn-pulse" style={{ width: 6, height: 6, borderRadius: 99, background: "var(--warn)" }}/>
        IN CONTESTAZIONE
      </span>
    );
  }
  if (state === "resolved") {
    return (
      <span className="mono" style={{
        padding: "4px 9px", borderRadius: 999,
        background: "oklch(0.80 0.140 150 / 0.10)",
        border: "1px solid oklch(0.80 0.140 150 / 0.35)",
        color: "var(--pos)", fontSize: 9,
      }}>RIMOSSA</span>
    );
  }
  return (
    <button onClick={onClick} style={{
      background: "transparent", border: 0, padding: 0, cursor: "pointer",
      fontFamily: "var(--f-mono)", fontSize: 9.5, letterSpacing: "0.14em",
      textTransform: "uppercase", color: "var(--t-3)",
      display: "inline-flex", alignItems: "center", gap: 4,
    }}>
      <Icon name="alert" size={11} color="var(--t-3)"/>
      Segnala o contesta
    </button>
  );
};

// Upload slot — drag/drop / tap area for documents
const UploadSlot = ({ label, hint, status = "empty", filename, onClick }) => {
  // status: empty | uploading | uploaded | verified
  const colors = {
    empty: { border: "var(--hair-2)", bg: "transparent", text: "var(--t-3)", icon: "upload", iconColor: "var(--t-3)" },
    uploading: { border: "var(--gold)", bg: "rgba(255,200,90,0.05)", text: "var(--gold)", icon: "upload", iconColor: "var(--gold)" },
    uploaded: { border: "var(--gold)", bg: "rgba(255,200,90,0.06)", text: "var(--gold)", icon: "doc", iconColor: "var(--gold)" },
    verified: { border: "oklch(0.80 0.140 150 / 0.5)", bg: "oklch(0.80 0.140 150 / 0.05)", text: "var(--pos)", icon: "checkSeal", iconColor: "var(--pos)" },
  };
  const c = colors[status];
  return (
    <button onClick={onClick} disabled={status === "uploading"} style={{
      width: "100%", padding: "14px 16px",
      background: c.bg,
      border: `1px ${status === "empty" ? "dashed" : "solid"} ${c.border}`,
      borderRadius: 14, cursor: status === "uploading" ? "wait" : "pointer",
      display: "flex", alignItems: "center", gap: 12,
      textAlign: "left",
      transition: "all .18s ease",
      fontFamily: "var(--f-ui)",
    }}>
      <div style={{
        width: 34, height: 34, borderRadius: 9,
        background: "rgba(255,255,255,0.04)",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        {status === "uploading"
          ? <div className="spin" style={{
              width: 16, height: 16, borderRadius: 99,
              border: "2px solid rgba(255,200,90,0.2)", borderTopColor: "var(--gold)",
            }}/>
          : <Icon name={c.icon} size={17} color={c.iconColor}/>}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13.5, fontWeight: 500, color: "var(--t-1)" }}>{label}</div>
        <div style={{ fontSize: 11.5, color: c.text, marginTop: 2,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>
          {status === "empty" && (hint || "Tocca per caricare · PDF o JPG")}
          {status === "uploading" && "Caricamento in corso…"}
          {status === "uploaded" && (filename || "Documento caricato · in verifica")}
          {status === "verified" && "Verificato dal team Aura"}
        </div>
      </div>
      {status === "uploaded" && (
        <span className="mono gold-pulse" style={{
          padding: "3px 7px", borderRadius: 4, fontSize: 8,
          background: "rgba(255,200,90,0.10)", color: "var(--gold)",
          border: "1px solid var(--gold)",
        }}>PENDING</span>
      )}
      {status === "verified" && <Icon name="check" size={16} color="var(--pos)" strokeWidth={2.2}/>}
    </button>
  );
};

// Wallet card — Stripe Connect style quick-view
const WalletCard = ({ balance = "€ 850", pending = "€ 185", iban = "•••• 7421", onTransfer, onOpen, compact = false }) => (
  <div onClick={onOpen} className={onOpen ? "tap" : ""} style={{
    background: "var(--bg-1)", border: "1px solid var(--hair)", borderRadius: 22,
    padding: compact ? "16px 18px" : "18px 20px 16px",
    position: "relative", overflow: "hidden",
    cursor: onOpen ? "pointer" : "default",
  }}>
    <div style={{
      position: "absolute", inset: 0, pointerEvents: "none",
      background: "radial-gradient(ellipse at 110% 110%, var(--gold-glow), transparent 50%)",
    }}/>
    <div style={{ position: "relative", display: "flex", alignItems: "flex-start", gap: 14 }}>
      <div style={{
        width: 38, height: 38, borderRadius: 10, flexShrink: 0,
        background: "linear-gradient(135deg, oklch(0.30 0.04 60), oklch(0.18 0.03 50))",
        border: "1px solid var(--hair-2)",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <Icon name="wallet" size={18} color="var(--gold)"/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="mono" style={{ marginBottom: 4 }}>Wallet · disponibile ora</div>
        <div className="gold-shimmer numeric" style={{
          fontFamily: "var(--f-ui)", fontWeight: 700, fontSize: 28, letterSpacing: "-0.025em", lineHeight: 1,
        }}>{balance}</div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8, fontSize: 11.5, color: "var(--t-3)" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
            <Icon name="clock" size={11} color="var(--t-3)"/> {pending} in arrivo 48h
          </span>
          <span>·</span>
          <span>IBAN {iban}</span>
        </div>
      </div>
    </div>
    <button onClick={(e) => { e.stopPropagation(); onTransfer && onTransfer(); }} style={{
      position: "relative", marginTop: 14, width: "100%",
      padding: "11px 14px", borderRadius: 12,
      background: "rgba(255,200,90,0.10)",
      border: "1px solid oklch(0.81 0.115 82 / 0.40)",
      color: "var(--gold)", fontFamily: "var(--f-ui)", fontSize: 13, fontWeight: 600,
      cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
      transition: "background .14s",
    }}>
      <Icon name="arrowUp" size={14} color="var(--gold)" strokeWidth={2.2}/>
      Trasferisci sul conto
    </button>
  </div>
);

// Role switcher chip (top of dashboard, swap personality)
const RoleChip = ({ role, onSwitch }) => (
  <button onClick={onSwitch} className="tap" style={{
    display: "inline-flex", alignItems: "center", gap: 6,
    padding: "5px 10px 5px 6px", borderRadius: 999,
    background: "rgba(255,255,255,0.04)", border: "1px solid var(--hair)",
    cursor: "pointer", fontFamily: "var(--f-mono)", fontSize: 9.5, letterSpacing: "0.14em",
    color: "var(--t-3)", textTransform: "uppercase",
  }}>
    <span style={{
      width: 18, height: 18, borderRadius: 99,
      background: role === "manager" ? "var(--gold)" : "rgba(255,255,255,0.10)",
      color: role === "manager" ? "#1a1206" : "var(--t-2)",
      display: "flex", alignItems: "center", justifyContent: "center",
      fontSize: 9, fontWeight: 700, fontFamily: "var(--f-ui)",
    }}>{role === "manager" ? "M" : "C"}</span>
    {role === "manager" ? "Ristoratore" : "Cameriere"}
    <Icon name="chevD" size={11} color="var(--t-3)"/>
  </button>
);

// Toast helper — dispatch a global event any component can fire
const showToast = (msg, icon = "check") => {
  try { window.dispatchEvent(new CustomEvent("aura-toast", { detail: { msg, icon } })); } catch (e) {}
};

// Toast renderer — mount once inside the frame
const ToastHost = () => {
  const [toast, setToast] = React.useState(null);
  React.useEffect(() => {
    let timer;
    const onToast = (e) => {
      setToast({ ...e.detail, id: Date.now() });
      clearTimeout(timer);
      timer = setTimeout(() => setToast(null), 2400);
    };
    window.addEventListener("aura-toast", onToast);
    return () => { window.removeEventListener("aura-toast", onToast); clearTimeout(timer); };
  }, []);
  if (!toast) return null;
  return (
    <div key={toast.id} style={{
      position: "absolute", left: 20, right: 20, bottom: 104, zIndex: 400,
      display: "flex", justifyContent: "center", pointerEvents: "none",
    }}>
      <div className="modal-enter" style={{
        display: "inline-flex", alignItems: "center", gap: 10,
        maxWidth: "100%",
        background: "rgba(28, 22, 16, 0.94)",
        backdropFilter: "blur(24px) saturate(140%)", WebkitBackdropFilter: "blur(24px) saturate(140%)",
        border: "1px solid var(--hair-2)", borderRadius: 14,
        padding: "12px 16px", boxShadow: "0 16px 36px rgba(0,0,0,0.55)",
      }}>
        <span style={{
          width: 22, height: 22, borderRadius: 999, flexShrink: 0,
          background: "linear-gradient(180deg, oklch(0.86 0.115 85), oklch(0.72 0.130 75))",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Icon name={toast.icon} size={13} color="#1a1206" strokeWidth={2.6}/>
        </span>
        <span style={{ fontSize: 13.5, fontWeight: 500, color: "var(--t-1)" }}>{toast.msg}</span>
      </div>
    </div>
  );
};

// Empty state block — icon, title, body, optional CTA
const EmptyState = ({ icon = "spark", title, body, cta, onCta, compact = false }) => (
  <div className="card" style={{
    padding: compact ? "26px 22px" : "36px 26px", textAlign: "center",
    display: "flex", flexDirection: "column", alignItems: "center",
    borderStyle: "dashed", borderColor: "var(--hair-2)",
  }}>
    <div style={{
      width: 56, height: 56, borderRadius: 16, marginBottom: 16,
      background: "radial-gradient(circle at 50% 30%, oklch(0.81 0.115 82 / 0.10), transparent 70%)",
      border: "1px solid var(--hair-2)",
      display: "flex", alignItems: "center", justifyContent: "center",
    }}>
      <Icon name={icon} size={26} color="var(--gold)"/>
    </div>
    <div className="serif" style={{ fontSize: 19, letterSpacing: "-0.01em", marginBottom: 8 }}>{title}</div>
    <div style={{ fontSize: 13, color: "var(--t-3)", lineHeight: 1.55, maxWidth: 280 }}>{body}</div>
    {cta && (
      <button onClick={onCta} className="btn-gold" style={{ marginTop: 18, padding: "12px 22px", fontSize: 13.5 }}>{cta}</button>
    )}
  </div>
);

// Fresh-profile banner — lets the user toggle to populated demo data
const FreshBanner = ({ onPopulate }) => (
  <div className="card" style={{
    padding: "12px 14px", marginBottom: 16, display: "flex", alignItems: "center", gap: 12,
    background: "linear-gradient(135deg, oklch(0.22 0.018 75) 0%, oklch(0.17 0.012 65) 100%)",
    borderColor: "var(--gold)",
  }}>
    <Icon name="spark" size={18} color="var(--gold)"/>
    <div style={{ flex: 1, fontSize: 12, color: "var(--t-2)", lineHeight: 1.4 }}>
      <strong style={{ color: "var(--t-1)" }}>Profilo nuovo.</strong> Vuoi vedere com'è a regime?
    </div>
    <button onClick={onPopulate} className="btn-gold" style={{ padding: "7px 12px", fontSize: 11 }}>Dati demo</button>
  </div>
);

Object.assign(window, { EmptyState, FreshBanner });

Object.assign(window, {
  QRGeneratorFAB, ContestBadge, UploadSlot, WalletCard, RoleChip, showToast, ToastHost,
});

// Pill
const Pill = ({ children, active = false, gold = false, small = false, onClick }) => (
  <button onClick={onClick} style={{
    background: active ? (gold ? "var(--gold)" : "rgba(255,255,255,0.08)") : "transparent",
    color: active ? (gold ? "#1a1206" : "var(--t-1)") : "var(--t-2)",
    border: `1px solid ${active ? (gold ? "var(--gold)" : "var(--hair-2)") : "var(--hair)"}`,
    borderRadius: 999,
    padding: small ? "6px 11px" : "9px 14px",
    fontFamily: "var(--f-mono)",
    fontSize: small ? 9.5 : 10.5,
    letterSpacing: "0.14em",
    textTransform: "uppercase",
    cursor: "pointer",
    transition: "background .12s, border-color .12s, color .12s",
    whiteSpace: "nowrap",
  }}>
    {children}
  </button>
);

// Section header (used inside screens)
const SectionHeader = ({ eyebrow, title, action }) => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 12 }}>
    <div>
      {eyebrow && <div className="mono" style={{ marginBottom: 6 }}>{eyebrow}</div>}
      {title && <div className="serif" style={{ fontSize: 22, fontWeight: 400, color: "var(--t-1)" }}>{title}</div>}
    </div>
    {action}
  </div>
);

Object.assign(window, {
  Icon, StatusBar, DynamicIsland, HomeIndicator, TabBar,
  Avatar, Verified, Badge, Pill, SectionHeader,
});
